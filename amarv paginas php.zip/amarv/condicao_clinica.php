<?php
require_once "conexao.php";

$mensagem = "";
$erro = "";

/*
|--------------------------------------------------------------------------
| EXCLUIR CONDIÇÃO
|--------------------------------------------------------------------------
*/
if (isset($_GET["excluir"])) {

    $id = (int)$_GET["excluir"];

    if ($id > 0) {
        try {

            $stmt = $pdo->prepare(
                "DELETE FROM condicao_clinica WHERE Id = :Id"
            );

            $stmt->execute([
                ":Id" => $id
            ]);

            header("Location: condicao_clinica.php?deletado=1");
            exit;

        } catch (PDOException $e) {

            $erro = "Não foi possível excluir a condição: " . $e->getMessage();
        }
    }
}


/*
|--------------------------------------------------------------------------
| CADASTRAR / EDITAR
|--------------------------------------------------------------------------
*/
if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $acao = $_POST["acao"] ?? "";

    $id = (int)($_POST["Id"] ?? 0);
    $pacienteId = (int)($_POST["PacienteId"] ?? 0);

    $descricao = trim($_POST["Descricao"] ?? "");
    $observacao = trim($_POST["Observacao"] ?? "");

    $alergia = isset($_POST["Alergia"]) ? 1 : 0;
    $imunodeprimido = isset($_POST["Imunodeprimido"]) ? 1 : 0;


    if ($pacienteId <= 0) {

        $erro = "Selecione um paciente.";

    } elseif ($descricao === "") {

        $erro = "Informe a descrição da condição clínica.";

    } else {

        try {

            /*
             * Confirma se o paciente existe.
             */
            $stmtPaciente = $pdo->prepare(
                "SELECT Id, Nome
                 FROM paciente
                 WHERE Id = :Id"
            );

            $stmtPaciente->execute([
                ":Id" => $pacienteId
            ]);

            $paciente = $stmtPaciente->fetch(PDO::FETCH_ASSOC);

            if (!$paciente) {

                $erro = "Paciente não encontrado.";

            } else {

                /*
                 * CADASTRAR
                 */
                if ($acao === "cadastrar") {

                    $sql = "INSERT INTO condicao_clinica
                            (
                                PacienteId,
                                Descricao,
                                Alergia,
                                Imunodeprimido,
                                Observacao
                            )
                            VALUES
                            (
                                :PacienteId,
                                :Descricao,
                                :Alergia,
                                :Imunodeprimido,
                                :Observacao
                            )";

                    $stmt = $pdo->prepare($sql);

                    $stmt->execute([
                        ":PacienteId" => $pacienteId,
                        ":Descricao" => $descricao,
                        ":Alergia" => $alergia,
                        ":Imunodeprimido" => $imunodeprimido,
                        ":Observacao" => $observacao !== "" ? $observacao : null
                    ]);

                    header("Location: condicao_clinica.php?sucesso=1");
                    exit;
                }


                /*
                 * EDITAR
                 */
                if ($acao === "editar") {

                    if ($id <= 0) {

                        $erro = "Condição clínica inválida.";

                    } else {

                        $sql = "UPDATE condicao_clinica
                                SET PacienteId = :PacienteId,
                                    Descricao = :Descricao,
                                    Alergia = :Alergia,
                                    Imunodeprimido = :Imunodeprimido,
                                    Observacao = :Observacao
                                WHERE Id = :Id";

                        $stmt = $pdo->prepare($sql);

                        $stmt->execute([
                            ":PacienteId" => $pacienteId,
                            ":Descricao" => $descricao,
                            ":Alergia" => $alergia,
                            ":Imunodeprimido" => $imunodeprimido,
                            ":Observacao" => $observacao !== "" ? $observacao : null,
                            ":Id" => $id
                        ]);

                        header("Location: condicao_clinica.php?editado=1");
                        exit;
                    }
                }
            }

        } catch (PDOException $e) {

            $erro = "Erro ao salvar: " . $e->getMessage();
        }
    }
}


/*
|--------------------------------------------------------------------------
| MENSAGENS
|--------------------------------------------------------------------------
*/
if (isset($_GET["sucesso"])) {
    $mensagem = "Condição clínica cadastrada com sucesso.";
}

if (isset($_GET["editado"])) {
    $mensagem = "Condição clínica atualizada com sucesso.";
}

if (isset($_GET["deletado"])) {
    $mensagem = "Condição clínica excluída com sucesso.";
}


/*
|--------------------------------------------------------------------------
| BUSCAR CONDIÇÃO PARA EDIÇÃO
|--------------------------------------------------------------------------
*/
$condicaoEdicao = null;

if (isset($_GET["editar"])) {

    $id = (int)$_GET["editar"];

    if ($id > 0) {

        $stmt = $pdo->prepare(
            "SELECT *
             FROM condicao_clinica
             WHERE Id = :Id"
        );

        $stmt->execute([
            ":Id" => $id
        ]);

        $condicaoEdicao = $stmt->fetch(PDO::FETCH_ASSOC);
    }
}


/*
|--------------------------------------------------------------------------
| PESQUISA
|--------------------------------------------------------------------------
*/
$busca = trim($_GET["busca"] ?? "");

if ($busca !== "") {

    $stmt = $pdo->prepare(
        "SELECT
            c.Id,
            c.PacienteId,
            c.Descricao,
            c.Alergia,
            c.Imunodeprimido,
            c.Observacao,
            p.Nome AS NomePaciente
         FROM condicao_clinica c
         INNER JOIN paciente p
             ON p.Id = c.PacienteId
         WHERE p.Nome LIKE :busca
            OR c.Descricao LIKE :busca
            OR c.Observacao LIKE :busca
         ORDER BY p.Nome ASC, c.Id DESC"
    );

    $stmt->execute([
        ":busca" => "%$busca%"
    ]);

    $condicoes = $stmt->fetchAll(PDO::FETCH_ASSOC);

} else {

    $stmt = $pdo->query(
        "SELECT
            c.Id,
            c.PacienteId,
            c.Descricao,
            c.Alergia,
            c.Imunodeprimido,
            c.Observacao,
            p.Nome AS NomePaciente
         FROM condicao_clinica c
         INNER JOIN paciente p
             ON p.Id = c.PacienteId
         ORDER BY p.Nome ASC, c.Id DESC"
    );

    $condicoes = $stmt->fetchAll(PDO::FETCH_ASSOC);
}


/*
|--------------------------------------------------------------------------
| LISTA DE PACIENTES
|--------------------------------------------------------------------------
*/
$stmt = $pdo->query(
    "SELECT Id, Nome, Cpf
     FROM paciente
     ORDER BY Nome ASC"
);

$pacientes = $stmt->fetchAll(PDO::FETCH_ASSOC);

?>
<!DOCTYPE html>
<html lang="pt-BR">

<head>

    <meta charset="UTF-8">

    <meta name="viewport"
          content="width=device-width, initial-scale=1.0">

    <title>Amar V - Condições Clínicas</title>

    <link rel="stylesheet" href="css/estilo.css">

    <style>

        body {
            font-family: Arial, sans-serif;
            background: #f5f5f5;
            margin: 0;
            padding: 0;
        }

        header {
            background: #0b6e69;
            color: white;
            padding: 20px;
            text-align: center;
        }

        header h1 {
            margin: 0;
            font-size: 28px;
        }

        header p {
            margin: 5px 0 0;
        }

        .container {
            max-width: 1200px;
            margin: 25px auto;
            padding: 0 15px;
        }

        .card {
            background: white;
            padding: 20px;
            margin-bottom: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 6px rgba(0,0,0,0.12);
        }

        .card h2 {
            color: #0b6e69;
            margin-top: 0;
        }

        label {
            display: block;
            margin-top: 12px;
            margin-bottom: 5px;
            font-weight: bold;
        }

        input,
        select,
        textarea {
            width: 100%;
            box-sizing: border-box;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        textarea {
            min-height: 90px;
            resize: vertical;
        }

        .checkbox {
            display: flex;
            align-items: center;
            gap: 8px;
            margin-top: 15px;
        }

        .checkbox input {
            width: auto;
        }

        button,
        .btn {
            display: inline-block;
            border: none;
            padding: 10px 16px;
            border-radius: 5px;
            cursor: pointer;
            text-decoration: none;
            color: white;
            margin-top: 15px;
        }

        .btn-salvar {
            background: #0b6e69;
        }

        .btn-editar {
            background: #607d8b;
        }

        .btn-excluir {
            background: #d9534f;
        }

        .btn-cancelar {
            background: #777;
        }

        .mensagem {
            background: #dff0d8;
            color: #3c763d;
            padding: 12px;
            border-radius: 5px;
            margin-bottom: 15px;
        }

        .erro {
            background: #f2dede;
            color: #a94442;
            padding: 12px;
            border-radius: 5px;
            margin-bottom: 15px;
        }

        .pesquisa {
            display: flex;
            gap: 10px;
        }

        .pesquisa input {
            flex: 1;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 15px;
        }

        th,
        td {
            padding: 10px;
            border-bottom: 1px solid #ddd;
            text-align: left;
        }

        th {
            background: #0b6e69;
            color: white;
        }

        .sim {
            color: #0b6e69;
            font-weight: bold;
        }

        .nao {
            color: #777;
        }

        @media (max-width: 800px) {

            table {
                font-size: 13px;
            }

            .pesquisa {
                flex-direction: column;
            }
        }

    </style>

</head>

<body>

<header>

    <h1>AMAR V</h1>

    <p>Gerenciamento de Condições Clínicas</p>

</header>


<div class="container">

    <?php if ($mensagem !== ""): ?>

        <div class="mensagem">
            <?= htmlspecialchars($mensagem) ?>
        </div>

    <?php endif; ?>


    <?php if ($erro !== ""): ?>

        <div class="erro">
            <?= htmlspecialchars($erro) ?>
        </div>

    <?php endif; ?>


    <!-- FORMULÁRIO -->

    <div class="card">

        <h2>
            <?= $condicaoEdicao
                ? "Editar Condição Clínica"
                : "Cadastrar Condição Clínica" ?>
        </h2>

        <form method="post">

            <input type="hidden"
                   name="acao"
                   value="<?= $condicaoEdicao ? 'editar' : 'cadastrar' ?>">

            <?php if ($condicaoEdicao): ?>

                <input type="hidden"
                       name="Id"
                       value="<?= (int)$condicaoEdicao["Id"] ?>">

            <?php endif; ?>


            <label for="PacienteId">
                Paciente
            </label>

            <select name="PacienteId"
                    id="PacienteId"
                    required>

                <option value="">
                    -- Selecione o paciente --
                </option>

                <?php foreach ($pacientes as $paciente): ?>

                    <option
                        value="<?= (int)$paciente["Id"] ?>"
                        <?= (
                            $condicaoEdicao &&
                            (int)$condicaoEdicao["PacienteId"] === (int)$paciente["Id"]
                        )
                            ? "selected"
                            : "" ?>>

                        <?= htmlspecialchars($paciente["Nome"]) ?>

                        <?php if (!empty($paciente["Cpf"])): ?>

                            - CPF:
                            <?= htmlspecialchars($paciente["Cpf"]) ?>

                        <?php endif; ?>

                    </option>

                <?php endforeach; ?>

            </select>


            <label for="Descricao">
                Descrição da condição
            </label>

            <input type="text"
                   name="Descricao"
                   id="Descricao"
                   required
                   value="<?= htmlspecialchars($condicaoEdicao["Descricao"] ?? "") ?>"
                   placeholder="Ex.: Gestação, HIV, imunossupressão...">


            <div class="checkbox">

                <input type="checkbox"
                       name="Alergia"
                       id="Alergia"
                       <?= (
                           $condicaoEdicao &&
                           (int)$condicaoEdicao["Alergia"] === 1
                       )
                           ? "checked"
                           : "" ?>>

                <label for="Alergia">
                    Paciente possui alergia
                </label>

            </div>


            <div class="checkbox">

                <input type="checkbox"
                       name="Imunodeprimido"
                       id="Imunodeprimido"
                       <?= (
                           $condicaoEdicao &&
                           (int)$condicaoEdicao["Imunodeprimido"] === 1
                       )
                           ? "checked"
                           : "" ?>>

                <label for="Imunodeprimido">
                    Paciente imunodeprimido
                </label>

            </div>


            <label for="Observacao">
                Observação
            </label>

            <textarea
                name="Observacao"
                id="Observacao"
                placeholder="Digite informações adicionais..."><?= htmlspecialchars($condicaoEdicao["Observacao"] ?? "") ?></textarea>


            <button type="submit"
                    class="btn btn-salvar">

                <?= $condicaoEdicao
                    ? "Atualizar"
                    : "Cadastrar" ?>

            </button>


            <?php if ($condicaoEdicao): ?>

                <a href="condicao_clinica.php"
                   class="btn btn-cancelar">

                    Cancelar

                </a>

            <?php endif; ?>

        </form>

    </div>


    <!-- PESQUISA -->

    <div class="card">

        <h2>Pesquisar Condições Clínicas</h2>

        <form method="get"
              class="pesquisa">

            <input type="text"
                   name="busca"
                   value="<?= htmlspecialchars($busca) ?>"
                   placeholder="Nome do paciente ou condição...">

            <button type="submit"
                    class="btn btn-salvar">

                Pesquisar

            </button>

            <a href="condicao_clinica.php"
               class="btn btn-cancelar">

                Limpar

            </a>

        </form>

    </div>


    <!-- LISTAGEM -->

    <div class="card">

        <h2>Condições Cadastradas</h2>

        <table>

            <thead>

                <tr>

                    <th>ID</th>

                    <th>Paciente</th>

                    <th>Condição</th>

                    <th>Alergia</th>

                    <th>Imunodeprimido</th>

                    <th>Observação</th>

                    <th>Ações</th>

                </tr>

            </thead>

            <tbody>

            <?php if (count($condicoes) > 0): ?>

                <?php foreach ($condicoes as $condicao): ?>

                    <tr>

                        <td>
                            <?= (int)$condicao["Id"] ?>
                        </td>

                        <td>

                            <?= htmlspecialchars(
                                $condicao["NomePaciente"]
                            ) ?>

                        </td>

                        <td>

                            <?= htmlspecialchars(
                                $condicao["Descricao"]
                            ) ?>

                        </td>

                        <td>

                            <?php if ((int)$condicao["Alergia"] === 1): ?>

                                <span class="sim">Sim</span>

                            <?php else: ?>

                                <span class="nao">Não</span>

                            <?php endif; ?>

                        </td>

                        <td>

                            <?php if ((int)$condicao["Imunodeprimido"] === 1): ?>

                                <span class="sim">Sim</span>

                            <?php else: ?>

                                <span class="nao">Não</span>

                            <?php endif; ?>

                        </td>

                        <td>

                            <?= htmlspecialchars(
                                $condicao["Observacao"] ?? ""
                            ) ?>

                        </td>

                        <td>

                            <a
                                href="condicao_clinica.php?editar=<?= (int)$condicao["Id"] ?>"
                                class="btn btn-editar">

                                Editar

                            </a>

                            <a
                                href="condicao_clinica.php?excluir=<?= (int)$condicao["Id"] ?>"
                                class="btn btn-excluir"
                                onclick="return confirm('Deseja realmente excluir esta condição clínica?');">

                                Excluir

                            </a>

                        </td>

                    </tr>

                <?php endforeach; ?>

            <?php else: ?>

                <tr>

                    <td colspan="7">
                        Nenhuma condição clínica cadastrada.
                    </td>

                </tr>

            <?php endif; ?>

            </tbody>

        </table>

    </div>

</div>

</body>

</html>