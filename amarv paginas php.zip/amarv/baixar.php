<?php

$pasta = "C:/Users/jesui/Downloads/AmarV/";

if (!isset($_GET["arquivo"])) {
    die("Nenhum arquivo informado.");
}

$nomeArquivo = basename($_GET["arquivo"]);

$caminho = $pasta . $nomeArquivo;

if (!file_exists($caminho)) {
    die("Arquivo não encontrado.");
}

header("Content-Type: application/json");
header(
    'Content-Disposition: attachment; filename="' .
    $nomeArquivo .
    '"'
);
header("Content-Length: " . filesize($caminho));

readfile($caminho);

exit;

?>