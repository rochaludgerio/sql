<?php

require_once "conexao.php";

$mensagem = "";
$erro = "";

/* =========================================================
   EXCLUIR REGRA
   ========================================================= */

if (isset($_GET["excluir"])) {

    $id = (int) $_GET["excluir"];

    try {

        $sql = "DELETE FROM regra_vacinal WHERE Id = ?";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$id]);

        header("Location: regra_vacinal.php?sucesso=excluido");
        exit;

    } catch (PDOException $e) {

        $erro = "Não foi possível excluir a regra: " . $e->getMessage();
    }
}


/* =========================================================
   EDITAR / CADASTRAR
   ========================================================= */

$regraEditar = null;

if (isset($_GET["editar"])) {

    $id = (int) $_GET["editar"];

    $stmt = $pdo->prepare(
        "SELECT * FROM regra_vacinal WHERE Id = ?"
    );

    $stmt->execute([$id]);

    $regraEditar = $stmt->fetch();

    if (!$regraEditar) {
        $erro = "Regra vacinal não encontrada.";
    }
}


/* =========================================================
   SALVAR
   ========================================================= */

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $id = !empty($_POST["Id"])
        ? (int) $_POST["Id"]
        : null;

    $NomeVacina = trim($_POST["NomeVacina"] ?? "");
    $Fabricante = trim($_POST["Fabricante"] ?? "");
    $TipoVacina = trim($_POST["TipoVacina"] ?? "");

    $IdadeMinimaMeses =
        $_POST["IdadeMinimaMeses"] !== ""
        ? (int) $_POST["IdadeMinimaMeses"]
        : null;

    $IdadeMaximaMeses =
        $_POST["IdadeMaximaMeses"] !== ""
        ? (int) $_POST["IdadeMaximaMeses"]
        : null;

    $IntervaloEntreDoses =
        trim($_POST["IntervaloEntreDoses"] ?? "");

    $ViaAdministracao =
        trim($_POST["ViaAdministracao"] ?? "");

    $LocalAplicacao =
        trim($_POST["LocalAplicacao"] ?? "");

    $TipoCalendario =
        trim($_POST["TipoCalendario"] ?? "");

    $Indicacao =
        trim($_POST["Indicacao"] ?? "");

    $Contraindicacao =
        trim($_POST["Contraindicacao"] ?? "");

    $EventosAdversos =
        trim($_POST["EventosAdversos"] ?? "");

    $Observacao =
        trim($_POST["Observacao"] ?? "");

    $DosesNecessariasCrianca =
        $_POST["DosesNecessariasCrianca"] !== ""
        ? (int) $_POST["DosesNecessariasCrianca"]
        : 0;

    $DosesNecessariasAdulto =
        $_POST["DosesNecessariasAdulto"] !== ""
        ? (int) $_POST["DosesNecessariasAdulto"]
        : 0;


    if ($NomeVacina === "") {

        $erro = "Informe o nome da vacina.";

    } else {

        try {

            if ($id) {

                /* =========================================
                   ATUALIZAR
                   ========================================= */

                $sql = "
                    UPDATE regra_vacinal SET
                        NomeVacina = ?,
                        Fabricante = ?,
                        TipoVacina = ?,
                        IdadeMinimaMeses = ?,
                        IdadeMaximaMeses = ?,
                        IntervaloEntreDoses = ?,
                        ViaAdministracao = ?,
                        LocalAplicacao = ?,
                        TipoCalendario = ?,
                        Indicacao = ?,
                        Contraindicacao = ?,
                        EventosAdversos = ?,
                        Observacao = ?,
                        DosesNecessariasCrianca = ?,
                        DosesNecessariasAdulto = ?
                    WHERE Id = ?
                ";

                $stmt = $pdo->prepare($sql);

                $stmt->execute([
                    $NomeVacina,
                    $Fabricante !== "" ? $Fabricante : null,
                    $TipoVacina !== "" ? $TipoVacina : null,
                    $IdadeMinimaMeses,
                    $IdadeMaximaMeses,
                    $IntervaloEntreDoses !== "" ? $IntervaloEntreDoses : null,
                    $ViaAdministracao !== "" ? $ViaAdministracao : null,
                    $LocalAplicacao !== "" ? $LocalAplicacao : null,
                    $TipoCalendario !== "" ? $TipoCalendario : null,
                    $Indicacao !== "" ? $Indicacao : null,
                    $Contraindicacao !== "" ? $Contraindicacao : null,
                    $EventosAdversos !== "" ? $EventosAdversos : null,
                    $Observacao !== "" ? $Observacao : null,
                    $DosesNecessariasCrianca,
                    $DosesNecessariasAdulto,
                    $id
                ]);

                header("Location: regra_vacinal.php?sucesso=alterado");
                exit;

            } else {

                /* =========================================
                   NOVO CADASTRO
                   ========================================= */

                $sql = "
                    INSERT INTO regra_vacinal (
                        NomeVacina,
                        Fabricante,
                        TipoVacina,
                        IdadeMinimaMeses,
                        IdadeMaximaMeses,
                        IntervaloEntreDoses,
                        ViaAdministracao,
                        LocalAplicacao,
                        TipoCalendario,
                        Indicacao,
                        Contraindicacao,
                        EventosAdversos,
                        Observacao,
                        DosesNecessariasCrianca,
                        DosesNecessariasAdulto
                    )
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ";

                $stmt = $pdo->prepare($sql);

                $stmt->execute([
                    $NomeVacina,
                    $Fabricante !== "" ? $Fabricante : null,
                    $TipoVacina !== "" ? $TipoVacina : null,
                    $IdadeMinimaMeses,
                    $IdadeMaximaMeses,
                    $IntervaloEntreDoses !== "" ? $IntervaloEntreDoses : null,
                    $ViaAdministracao !== "" ? $ViaAdministracao : null,
                    $LocalAplicacao !== "" ? $LocalAplicacao : null,
                    $TipoCalendario !== "" ? $TipoCalendario : null,
                    $Indicacao !== "" ? $Indicacao : null,
                    $Contraindicacao !== "" ? $Contraindicacao : null,
                    $EventosAdversos !== "" ? $EventosAdversos : null,
                    $Observacao !== "" ? $Observacao : null,
                    $DosesNecessariasCrianca,
                    $DosesNecessariasAdulto
                ]);

                header("Location: regra_vacinal.php?sucesso=cadastrado");
                exit;
            }

        } catch (PDOException $e) {

            $erro = "Erro ao salvar a regra vacinal: " . $e->getMessage();
        }
    }
}


/* =========================================================
   MENSAGENS
   ========================================================= */

if (isset($_GET["sucesso"])) {

    switch ($_GET["sucesso"]) {

        case "cadastrado":
            $mensagem = "Regra vacinal cadastrada com sucesso.";
            break;

        case "alterado":
            $mensagem = "Regra vacinal alterada com sucesso.";
            break;

        case "excluido":
            $mensagem = "Regra vacinal excluída com sucesso.";
            break;
    }
}


/* =========================================================
   LISTAR REGRAS
   ========================================================= */

$stmt = $pdo->query("
    SELECT *
    FROM regra_vacinal
    ORDER BY NomeVacina ASC
");

$regras = $stmt->fetchAll();

?>
<!DOCTYPE html>

<html lang="pt-BR">

<head>

    <meta charset="UTF-8">

    <meta name="viewport"
          content="width=device-width, initial-scale=1.0">

    <title>Amar V - Regras Vacinais</title>

    <link rel="stylesheet"
          href="css/estilo.css">

    <style>

        .formulario {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 15px;
        }

        .campo {
            display: flex;
            flex-direction: column;
        }

        .campo-completo {
            grid-column: 1 / -1;
        }

        .campo label {
            font-weight: bold;
            margin-bottom: 6px;
        }

        .campo input,
        .campo select,
        .campo textarea {
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 6px;
            font-size: 14px;
            width: 100%;
            box-sizing: border-box;
        }

        .campo textarea {
            min-height: 90px;
            resize: vertical;
        }

        .botoes {
            grid-column: 1 / -1;
            display: flex;
            gap: 10px;
            margin-top: 10px;
        }

        .botao-form {
            padding: 11px 20px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            text-decoration: none;
            display: inline-block;
        }

        .botao-salvar {
            background: #0B3C49;
            color: white;
        }

        .botao-cancelar {
            background: #777;
            color: white;
        }

        .tabela-container {
            overflow-x: auto;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 15px;
        }

        th,
        td {
            padding: 10px;
            border-bottom: 1px solid #ddd;
            text-align: left;
            vertical-align: top;
        }

        th {
            background: #0B3C49;
            color: white;
        }

        .acoes {
            white-space: nowrap;
        }

        .botao-editar {
            background: #4fb3bf;
            color: white;
            padding: 7px 10px;
            border-radius: 5px;
            text-decoration: none;
        }

        .botao-excluir {
            background: #b33a3a;
            color: white;
            padding: 7px 10px;
            border-radius: 5px;
            text-decoration: none;
        }

        .mensagem {
            padding: 12px;
            margin-bottom: 15px;
            border-radius: 6px;
            background: #dff0d8;
            color: #245b2a;
        }

        .erro {
            padding: 12px;
            margin-bottom: 15px;
            border-radius: 6px;
            background: #f8d7da;
            color: #842029;
        }

        @media (max-width: 700px) {

            .formulario {
                grid-template-columns: 1fr;
            }

            .campo-completo {
                grid-column: auto;
            }

            .botoes {
                grid-column: auto;
            }

        }

    </style>

</head>

<body>


<header>

    <div class="logo">
        AMAR V
    </div>

    <div class="subtitulo">
        Servidor de Sincronização e Administração
    </div>

</header>


<main>


    <!-- ================================================= -->
    <!-- TÍTULO -->
    <!-- ================================================= -->

    <section class="card destaque">

        <h1>
            📋 Regras Vacinais
        </h1>

        <p>
            Cadastro e gerenciamento das regras utilizadas
            na análise do calendário vacinal.
        </p>

    </section>


    <?php if ($mensagem): ?>

        <div class="mensagem">
            <?= htmlspecialchars($mensagem) ?>
        </div>

    <?php endif; ?>


    <?php if ($erro): ?>

        <div class="erro">
            <?= htmlspecialchars($erro) ?>
        </div>

    <?php endif; ?>


    <!-- ================================================= -->
    <!-- FORMULÁRIO -->
    <!-- ================================================= -->

    <section class="card">

        <h2>

            <?= $regraEditar
                ? "✏️ Editar Regra Vacinal"
                : "➕ Nova Regra Vacinal"
            ?>

        </h2>


        <form method="POST"
              class="formulario">


            <input type="hidden"
                   name="Id"
                   value="<?= htmlspecialchars($regraEditar["Id"] ?? "") ?>">


            <div class="campo">

                <label>
                    Nome da Vacina *
                </label>

                <input type="text"
                       name="NomeVacina"
                       required
                       value="<?= htmlspecialchars($regraEditar["NomeVacina"] ?? "") ?>">

            </div>


            <div class="campo">

                <label>
                    Fabricante
                </label>

                <input type="text"
                       name="Fabricante"
                       value="<?= htmlspecialchars($regraEditar["Fabricante"] ?? "") ?>">

            </div>


            <div class="campo">

                <label>
                    Tipo da Vacina
                </label>

                <input type="text"
                       name="TipoVacina"
                       value="<?= htmlspecialchars($regraEditar["TipoVacina"] ?? "") ?>">

            </div>


            <div class="campo">

                <label>
                    Tipo de Calendário
                </label>

                <select name="TipoCalendario">

                    <option value="">
                        Selecione
                    </option>

                    <option value="SUS"
                        <?= (($regraEditar["TipoCalendario"] ?? "") === "SUS") ? "selected" : "" ?>>
                        SUS
                    </option>

                    <option value="Privado"
                        <?= (($regraEditar["TipoCalendario"] ?? "") === "Privado") ? "selected" : "" ?>>
                        Rede Privada
                    </option>

                    <option value="Ambos"
                        <?= (($regraEditar["TipoCalendario"] ?? "") === "Ambos") ? "selected" : "" ?>>
                        Ambos
                    </option>

                </select>

            </div>


            <div class="campo">

                <label>
                    Idade mínima (meses)
                </label>

                <input type="number"
                       min="0"
                       name="IdadeMinimaMeses"
                       value="<?= htmlspecialchars($regraEditar["IdadeMinimaMeses"] ?? "") ?>">

            </div>


            <div class="campo">

                <label>
                    Idade máxima (meses)
                </label>

                <input type="number"
                       min="0"
                       name="IdadeMaximaMeses"
                       value="<?= htmlspecialchars($regraEditar["IdadeMaximaMeses"] ?? "") ?>">

            </div>


            <div class="campo">

                <label>
                    Intervalo entre doses
                </label>

                <input type="text"
                       name="IntervaloEntreDoses"
                       placeholder="Ex.: 60 dias"
                       value="<?= htmlspecialchars($regraEditar["IntervaloEntreDoses"] ?? "") ?>">

            </div>


            <div class="campo">

                <label>
                    Via de administração
                </label>

                <input type="text"
                       name="ViaAdministracao"
                       placeholder="Ex.: Intramuscular"
                       value="<?= htmlspecialchars($regraEditar["ViaAdministracao"] ?? "") ?>">

            </div>


            <div class="campo">

                <label>
                    Local de aplicação
                </label>

                <input type="text"
                       name="LocalAplicacao"
                       placeholder="Ex.: Braço direito"
                       value="<?= htmlspecialchars($regraEditar["LocalAplicacao"] ?? "") ?>">

            </div>


            <div class="campo campo-completo">

                <label>
                    Indicação
                </label>

                <textarea name="Indicacao"><?= htmlspecialchars($regraEditar["Indicacao"] ?? "") ?></textarea>

            </div>


            <div class="campo campo-completo">

                <label>
                    Contraindicação
                </label>

                <textarea name="Contraindicacao"><?= htmlspecialchars($regraEditar["Contraindicacao"] ?? "") ?></textarea>

            </div>


            <div class="campo campo-completo">

                <label>
                    Eventos Adversos
                </label>

                <textarea name="EventosAdversos"><?= htmlspecialchars($regraEditar["EventosAdversos"] ?? "") ?></textarea>

            </div>


            <div class="campo campo-completo">

                <label>
                    Observação
                </label>

                <textarea name="Observacao"><?= htmlspecialchars($regraEditar["Observacao"] ?? "") ?></textarea>

            </div>


            <div class="campo">

                <label>
                    Doses necessárias - Criança
                </label>

                <input type="number"
                       min="0"
                       name="DosesNecessariasCrianca"
                       value="<?= htmlspecialchars($regraEditar["DosesNecessariasCrianca"] ?? "0") ?>">

            </div>


            <div class="campo">

                <label>
                    Doses necessárias - Adulto
                </label>

                <input type="number"
                       min="0"
                       name="DosesNecessariasAdulto"
                       value="<?= htmlspecialchars($regraEditar["DosesNecessariasAdulto"] ?? "0") ?>">

            </div>


            <div class="botoes">

                <button type="submit"
                        class="botao-form botao-salvar">

                    <?= $regraEditar
                        ? "Salvar Alterações"
                        : "Cadastrar Regra"
                    ?>

                </button>


                <?php if ($regraEditar): ?>

                    <a href="regra_vacinal.php"
                       class="botao-form botao-cancelar">

                        Cancelar

                    </a>

                <?php endif; ?>

            </div>


        </form>

    </section>


    <!-- ================================================= -->
    <!-- LISTAGEM -->
    <!-- ================================================= -->

    <section class="card">

        <h2>
            📋 Regras Cadastradas
        </h2>


        <div class="tabela-container">

            <table>

                <thead>

                    <tr>

                        <th>ID</th>
                        <th>Vacina</th>
                        <th>Calendário</th>
                        <th>Idade</th>
                        <th>Doses Criança</th>
                        <th>Doses Adulto</th>
                        <th>Observação</th>
                        <th>Ações</th>

                    </tr>

                </thead>


                <tbody>

                <?php if (count($regras) > 0): ?>

                    <?php foreach ($regras as $regra): ?>

                        <tr>

                            <td>
                                <?= htmlspecialchars($regra["Id"]) ?>
                            </td>

                            <td>
                                <strong>
                                    <?= htmlspecialchars($regra["NomeVacina"]) ?>
                                </strong>
                            </td>

                            <td>
                                <?= htmlspecialchars($regra["TipoCalendario"] ?? "") ?>
                            </td>

                            <td>

                                <?= htmlspecialchars($regra["IdadeMinimaMeses"] ?? "") ?>

                                até

                                <?= htmlspecialchars($regra["IdadeMaximaMeses"] ?? "") ?>

                                meses

                            </td>

                            <td>
                                <?= htmlspecialchars($regra["DosesNecessariasCrianca"] ?? "0") ?>
                            </td>

                            <td>
                                <?= htmlspecialchars($regra["DosesNecessariasAdulto"] ?? "0") ?>
                            </td>

                            <td>

                                <?= htmlspecialchars(
                                    $regra["Observacao"] ?? ""
                                ) ?>

                            </td>

                            <td class="acoes">

                                <a
                                    href="regra_vacinal.php?editar=<?= urlencode($regra["Id"]) ?>"
                                    class="botao-editar">

                                    Editar

                                </a>


                                <a
                                    href="regra_vacinal.php?excluir=<?= urlencode($regra["Id"]) ?>"
                                    class="botao-excluir"
                                    onclick="return confirm('Tem certeza que deseja excluir esta regra vacinal?');">

                                    Excluir

                                </a>

                            </td>

                        </tr>

                    <?php endforeach; ?>

                <?php else: ?>

                    <tr>

                        <td colspan="8">

                            Nenhuma regra vacinal cadastrada.

                        </td>

                    </tr>

                <?php endif; ?>

                </tbody>

            </table>

        </div>

    </section>


    <!-- ================================================= -->
    <!-- VOLTAR -->
    <!-- ================================================= -->

    <section class="card">

        <a href="index.php"
           class="botao-form botao-cancelar">

            ← Voltar ao painel

        </a>

    </section>


</main>


<footer>

    Amar V © <?= date("Y") ?>

</footer>


</body>

</html>