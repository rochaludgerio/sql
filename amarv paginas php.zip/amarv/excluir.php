<?php

$pasta = "C:/Users/jesui/Downloads/AmarV/";

if (!isset($_GET["arquivo"])) {
    die("Nenhum arquivo informado.");
}

$nomeArquivo = basename($_GET["arquivo"]);

$caminho = $pasta . $nomeArquivo;

if (!file_exists($caminho)) {
    die("Arquivo não encontrado.");
}

if (unlink($caminho)) {

    header("Location: arquivos.php");
    exit;

} else {

    die("Não foi possível excluir o arquivo.");

}

?>