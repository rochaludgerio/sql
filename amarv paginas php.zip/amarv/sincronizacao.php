<?php
require_once "conexao.php";

$mensagem = "";
$erro = "";

/* =========================
   EXCLUIR
========================= */
if (isset($_GET["excluir"])) {

    $id = (int) $_GET["excluir"];

    try {
        $stmt = $pdo->prepare("DELETE FROM sincronizacao WHERE Id = ?");
        $stmt->execute([$id]);

        header("Location: sincronizacao.php?sucesso=excluido");
        exit;

    } catch (PDOException $e) {
        $erro = "Erro ao excluir a sincronização: " . $e->getMessage();
    }
}

/* =========================
   EDITAR
========================= */
$registroEditar = null;

if (isset($_GET["editar"])) {

    $id = (int) $_GET["editar"];

    try {
        $stmt = $pdo->prepare("
            SELECT Id, DataSincronizacao, Status, QuantidadeRegistros
            FROM sincronizacao
            WHERE Id = ?
        ");

        $stmt->execute([$id]);
        $registroEditar = $stmt->fetch();

        if (!$registroEditar) {
            $erro = "Registro de sincronização não encontrado.";
        }

    } catch (PDOException $e) {
        $erro = "Erro ao carregar o registro: " . $e->getMessage();
    }
}

/* =========================
   SALVAR
========================= */
if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $id = isset($_POST["Id"]) ? (int) $_POST["Id"] : 0;

    $dataSincronizacao = trim($_POST["DataSincronizacao"] ?? "");
    $status = trim($_POST["Status"] ?? "");
    $quantidadeRegistros = trim($_POST["QuantidadeRegistros"] ?? "");

    if ($status === "") {
        $erro = "Informe o status da sincronização.";

    } else {

        if ($quantidadeRegistros === "") {
            $quantidadeRegistros = 0;
        }

        try {

            if ($id > 0) {

                $stmt = $pdo->prepare("
                    UPDATE sincronizacao
                    SET DataSincronizacao = ?,
                        Status = ?,
                        QuantidadeRegistros = ?
                    WHERE Id = ?
                ");

                $stmt->execute([
                    $dataSincronizacao !== "" ? $dataSincronizacao : null,
                    $status,
                    (int) $quantidadeRegistros,
                    $id
                ]);

                header("Location: sincronizacao.php?sucesso=alterado");
                exit;

            } else {

                if ($dataSincronizacao === "") {
                    $dataSincronizacao = date("Y-m-d H:i:s");
                }

                $stmt = $pdo->prepare("
                    INSERT INTO sincronizacao
                    (
                        DataSincronizacao,
                        Status,
                        QuantidadeRegistros
                    )
                    VALUES (?, ?, ?)
                ");

                $stmt->execute([
                    $dataSincronizacao,
                    $status,
                    (int) $quantidadeRegistros
                ]);

                header("Location: sincronizacao.php?sucesso=incluido");
                exit;
            }

        } catch (PDOException $e) {
            $erro = "Erro ao salvar a sincronização: " . $e->getMessage();
        }
    }
}

/* =========================
   MENSAGENS
========================= */
if (isset($_GET["sucesso"])) {

    switch ($_GET["sucesso"]) {

        case "incluido":
            $mensagem = "Sincronização registrada com sucesso.";
            break;

        case "alterado":
            $mensagem = "Sincronização alterada com sucesso.";
            break;

        case "excluido":
            $mensagem = "Sincronização excluída com sucesso.";
            break;
    }
}

/* =========================
   LISTAR
========================= */
try {

    $stmt = $pdo->query("
        SELECT
            Id,
            DataSincronizacao,
            Status,
            QuantidadeRegistros
        FROM sincronizacao
        ORDER BY DataSincronizacao DESC, Id DESC
    ");

    $sincronizacoes = $stmt->fetchAll();

} catch (PDOException $e) {

    $sincronizacoes = [];
    $erro = "Erro ao carregar as sincronizações: " . $e->getMessage();
}

?>
<!DOCTYPE html>
<html lang="pt-BR">

<head>

    <meta charset="UTF-8">

    <meta name="viewport"
          content="width=device-width, initial-scale=1.0">

    <title>Sincronização - Amar V</title>

    <link rel="stylesheet" href="css/estilo.css">

    <style>

        .formulario {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 15px;
        }

        .campo {
            display: flex;
            flex-direction: column;
        }

        .campo label {
            font-weight: bold;
            margin-bottom: 6px;
        }

        .campo input,
        .campo select {
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 6px;
            font-size: 15px;
        }

        .campo-completo {
            grid-column: 1 / -1;
        }

        .botoes {
            margin-top: 20px;
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
        }

        .btn {
            display: inline-block;
            padding: 10px 16px;
            border: none;
            border-radius: 6px;
            text-decoration: none;
            cursor: pointer;
            font-size: 14px;
            font-weight: bold;
        }

        .btn-salvar {
            background: #0B3C49;
            color: white;
        }

        .btn-salvar:hover {
            background: #082f39;
        }

        .btn-voltar {
            background: #777;
            color: white;
        }

        .btn-voltar:hover {
            background: #555;
        }

        .btn-editar {
            background: #4fb3bf;
            color: white;
        }

        .btn-excluir {
            background: #c0392b;
            color: white;
        }

        .mensagem {
            background: #d4edda;
            color: #155724;
            padding: 12px;
            border-radius: 6px;
            margin-bottom: 15px;
        }

        .erro {
            background: #f8d7da;
            color: #721c24;
            padding: 12px;
            border-radius: 6px;
            margin-bottom: 15px;
        }

        .tabela-container {
            overflow-x: auto;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 15px;
        }

        table th {
            background: #0B3C49;
            color: white;
            padding: 12px;
            text-align: left;
        }

        table td {
            padding: 10px;
            border-bottom: 1px solid #ddd;
        }

        table tr:hover {
            background: #f5f5f5;
        }

        .acoes {
            display: flex;
            gap: 6px;
            flex-wrap: wrap;
        }

        .status-sucesso {
            color: #198754;
            font-weight: bold;
        }

        .status-erro {
            color: #dc3545;
            font-weight: bold;
        }

        .status-outro {
            color: #856404;
            font-weight: bold;
        }

        @media (max-width: 700px) {

            .formulario {
                grid-template-columns: 1fr;
            }

            .campo-completo {
                grid-column: auto;
            }
        }

    </style>

</head>

<body>

<header>

    <div class="logo">
        AMAR V
    </div>

    <div class="subtitulo">
        Servidor de Sincronização e Administração
    </div>

</header>

<main>

    <!-- =========================
         TÍTULO
    ========================== -->

    <section class="card destaque">

        <h2>🔄 Sincronização</h2>

        <p>
            Cadastro e gerenciamento dos registros de sincronização
            entre o aplicativo Amar V e o servidor.
        </p>

    </section>


    <!-- =========================
         MENSAGENS
    ========================== -->

    <?php if ($mensagem): ?>

        <div class="mensagem">
            <?= htmlspecialchars($mensagem) ?>
        </div>

    <?php endif; ?>


    <?php if ($erro): ?>

        <div class="erro">
            <?= htmlspecialchars($erro) ?>
        </div>

    <?php endif; ?>


    <!-- =========================
         FORMULÁRIO
    ========================== -->

    <section class="card">

        <h3>
            <?= $registroEditar
                ? "✏️ Editar Sincronização"
                : "➕ Registrar Sincronização"
            ?>
        </h3>

        <form method="post">

            <?php if ($registroEditar): ?>

                <input
                    type="hidden"
                    name="Id"
                    value="<?= (int) $registroEditar["Id"] ?>"
                >

            <?php endif; ?>


            <div class="formulario">

                <div class="campo">

                    <label for="DataSincronizacao">
                        Data da Sincronização
                    </label>

                    <input
                        type="datetime-local"
                        id="DataSincronizacao"
                        name="DataSincronizacao"
                        value="<?=
                            $registroEditar
                            ? date(
                                "Y-m-d\TH:i",
                                strtotime(
                                    $registroEditar["DataSincronizacao"]
                                )
                            )
                            : date("Y-m-d\TH:i")
                        ?>"
                    >

                </div>


                <div class="campo">

                    <label for="Status">
                        Status
                    </label>

                    <select
                        id="Status"
                        name="Status"
                        required
                    >

                        <option value="">
                            Selecione
                        </option>

                        <option
                            value="Sincronizado"
                            <?= (
                                $registroEditar &&
                                $registroEditar["Status"] === "Sincronizado"
                            ) ? "selected" : "" ?>
                        >
                            Sincronizado
                        </option>

                        <option
                            value="Pendente"
                            <?= (
                                $registroEditar &&
                                $registroEditar["Status"] === "Pendente"
                            ) ? "selected" : "" ?>
                        >
                            Pendente
                        </option>

                        <option
                            value="Erro"
                            <?= (
                                $registroEditar &&
                                $registroEditar["Status"] === "Erro"
                            ) ? "selected" : "" ?>
                        >
                            Erro
                        </option>

                    </select>

                </div>


                <div class="campo">

                    <label for="QuantidadeRegistros">
                        Quantidade de Registros
                    </label>

                    <input
                        type="number"
                        id="QuantidadeRegistros"
                        name="QuantidadeRegistros"
                        min="0"
                        value="<?=
                            $registroEditar
                            ? (int) $registroEditar["QuantidadeRegistros"]
                            : 0
                        ?>"
                    >

                </div>

            </div>


            <div class="botoes">

                <button
                    type="submit"
                    class="btn btn-salvar"
                >
                    💾
                    <?= $registroEditar
                        ? "Atualizar"
                        : "Registrar"
                    ?>
                </button>


                <?php if ($registroEditar): ?>

                    <a
                        href="sincronizacao.php"
                        class="btn btn-voltar"
                    >
                        Cancelar
                    </a>

                <?php endif; ?>

            </div>

        </form>

    </section>


    <!-- =========================
         LISTAGEM
    ========================== -->

    <section class="card">

        <h3>📋 Histórico de Sincronizações</h3>

        <div class="tabela-container">

            <table>

                <thead>

                    <tr>

                        <th>ID</th>

                        <th>Data da Sincronização</th>

                        <th>Status</th>

                        <th>Quantidade de Registros</th>

                        <th>Ações</th>

                    </tr>

                </thead>

                <tbody>

                    <?php if (count($sincronizacoes) > 0): ?>

                        <?php foreach ($sincronizacoes as $registro): ?>

                            <?php

                            $status = $registro["Status"];

                            $classeStatus = "status-outro";

                            if ($status === "Sincronizado") {
                                $classeStatus = "status-sucesso";
                            } elseif ($status === "Erro") {
                                $classeStatus = "status-erro";
                            }

                            ?>

                            <tr>

                                <td>
                                    <?= (int) $registro["Id"] ?>
                                </td>

                                <td>

                                    <?=
                                        date(
                                            "d/m/Y H:i:s",
                                            strtotime(
                                                $registro["DataSincronizacao"]
                                            )
                                        )
                                    ?>

                                </td>

                                <td>

                                    <span class="<?= $classeStatus ?>">

                                        <?= htmlspecialchars($status) ?>

                                    </span>

                                </td>

                                <td>

                                    <?= (int) $registro["QuantidadeRegistros"] ?>

                                </td>

                                <td>

                                    <div class="acoes">

                                        <a
                                            href="sincronizacao.php?editar=<?= (int) $registro["Id"] ?>"
                                            class="btn btn-editar"
                                        >
                                            ✏️ Editar
                                        </a>


                                        <a
                                            href="sincronizacao.php?excluir=<?= (int) $registro["Id"] ?>"
                                            class="btn btn-excluir"
                                            onclick="return confirm('Tem certeza que deseja excluir este registro de sincronização?');"
                                        >
                                            🗑️ Excluir
                                        </a>

                                    </div>

                                </td>

                            </tr>

                        <?php endforeach; ?>

                    <?php else: ?>

                        <tr>

                            <td colspan="5">
                                Nenhum registro de sincronização encontrado.
                            </td>

                        </tr>

                    <?php endif; ?>

                </tbody>

            </table>

        </div>

    </section>


    <!-- =========================
         VOLTAR
    ========================== -->

    <section class="card">

        <a
            href="index.php"
            class="btn btn-voltar"
        >
            ← Voltar ao Painel
        </a>

    </section>

</main>


<footer>

    Amar V © <?= date("Y") ?>

</footer>

</body>

</html>