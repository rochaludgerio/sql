<?php
require_once "conexao.php";

$mensagem = "";

// REGISTRAR NOVA DOSE
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['acao']) && $_POST['acao'] === 'cadastrar') {
    $vacinaId = (int)($_POST['vacina_id'] ?? 0);
    $numeroDose = trim($_POST['numero_dose'] ?? '');
    $intervaloDias = (int)($_POST['intervalo_dias'] ?? 0);
    $faixaEtaria = trim($_POST['faixa_etaria'] ?? '');
    $reforco = isset($_POST['reforco']) ? 1 : 0;

    if ($vacinaId > 0 && !empty($numeroDose)) {
        $stmt = $pdo->prepare("
            INSERT INTO dose (VacinaId, NumeroDose, IntervaloDias, FaixaEtaria, Reforco) 
            VALUES (?, ?, ?, ?, ?)
        ");
        $stmt->execute([$vacinaId, $numeroDose, $intervaloDias, $faixaEtaria ?: null, $reforco]);
        header("Location: dose.php?sucesso=1");
        exit;
    } else {
        $mensagem = "Selecione a vacina e informe o número da dose.";
    }
}

// EXCLUIR DOSE
if (isset($_GET['excluir'])) {
    $idExcluir = (int)$_GET['excluir'];
    $stmt = $pdo->prepare("DELETE FROM dose WHERE Id = ?");
    $stmt->execute([$idExcluir]);
    header("Location: dose.php?deletado=1");
    exit;
}

// CONSULTA DE DOSES VINCULADAS ÀS VACINAS
$stmt = $pdo->query("
    SELECT d.Id, d.NumeroDose, d.IntervaloDias, d.FaixaEtaria, d.Reforco, v.Nome AS VacinaNome
    FROM dose d
    LEFT JOIN vacina v ON d.VacinaId = v.Id
    ORDER BY d.Id DESC
");
$doses = $stmt->fetchAll();

$vacinas = $pdo->query("SELECT Id, Nome FROM vacina ORDER BY Nome ASC")->fetchAll();
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gerenciamento de Doses - Amar V</title>
    <link rel="stylesheet" href="css/estilo.css">
    <style>
        .tabela-container { overflow-x: auto; margin-top: 20px; }
        table { width: 100%; border-collapse: collapse; margin-top: 10px; }
        th, td { padding: 12px 15px; text-align: left; border-bottom: 1px solid #e0e9eb; }
        th { background-color: #0b6e69; color: white; font-size: 14px; }
        tr:hover { background-color: #f5fbfa; }
        .form-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 15px; margin-bottom: 15px; }
        .form-grupo { display: flex; flex-direction: column; gap: 5px; }
        .form-grupo label { font-weight: bold; font-size: 13px; color: #193f40; }
        .form-grupo input, .form-grupo select { padding: 10px; border: 1px solid #c2d6d4; border-radius: 8px; font-size: 14px; }
        .checkbox-container { display: flex; align-items: center; gap: 8px; margin-top: 25px; }
        .btn-acao { display: inline-block; padding: 6px 12px; border-radius: 6px; text-decoration: none; font-size: 12px; font-weight: bold; color: white; border: none; }
        .btn-excluir { background-color: #d9534f; }
        .btn-voltar { background-color: #607d8b; color: white; padding: 10px 18px; border-radius: 8px; text-decoration: none; font-weight: bold; display: inline-block; margin-bottom: 20px; }
        .alerta { padding: 12px 16px; border-radius: 8px; margin-bottom: 20px; font-weight: bold; }
        .alerta-sucesso { background-color: #e8f6eb; color: #28783a; border: 1px solid #c9e8ce; }
        .alerta-erro { background-color: #fde8e8; color: #c53030; border: 1px solid #f8b4b4; }
    </style>
</head>
<body>

<header>
    <div class="logo">AMAR V</div>
    <div class="subtitulo">Gerenciamento de Doses</div>
</header>

<main>
    <a href="index.php" class="btn-voltar">← Voltar ao Início</a>

    <?php if (isset($_GET['sucesso'])): ?>
        <div class="alerta alerta-sucesso">Dose cadastrada com sucesso!</div>
    <?php endif; ?>

    <?php if (isset($_GET['deletado'])): ?>
        <div class="alerta alerta-sucesso">Dose excluída com sucesso!</div>
    <?php endif; ?>

    <?php if (!empty($mensagem)): ?>
        <div class="alerta alerta-erro"><?= htmlspecialchars($mensagem) ?></div>
    <?php endif; ?>

    <section class="card">
        <div class="titulo-secao">
            <div class="titulo-icone">💉</div>
            <div>
                <h2>Cadastrar Nova Dose</h2>
                <p>Configure os esquemas vacinais para cada vacina.</p>
            </div>
        </div>

        <form action="dose.php" method="POST">
            <input type="hidden" name="acao" value="cadastrar">
            
            <div class="form-grid">
                <div class="form-grupo">
                    <label>Vacina *</label>
                    <select name="vacina_id" required>
                        <option value="">-- Selecione a Vacina --</option>
                        <?php foreach ($vacinas as $v): ?>
                            <option value="<?= $v['Id'] ?>"><?= htmlspecialchars($v['Nome']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="form-grupo">
                    <label>Número/Identificação da Dose *</label>
                    <input type="text" name="numero_dose" placeholder="Ex: 1ª Dose, Reforço" required>
                </div>

                <div class="form-grupo">
                    <label>Intervalo (em dias)</label>
                    <input type="number" name="intervalo_dias" placeholder="Ex: 30, 60">
                </div>

                <div class="form-grupo">
                    <label>Faixa Etária</label>
                    <input type="text" name="faixa_etaria" placeholder="Ex: 2 meses, Adulto">
                </div>

                <div class="form-grupo checkbox-container">
                    <input type="checkbox" name="reforco" id="reforco" value="1">
                    <label for="reforco">É Dose de Reforço?</label>
                </div>
            </div>

            <button type="submit" class="botao">Salvar Dose</button>
        </form>
    </section>

    <section class="card">
        <div class="titulo-secao">
            <div class="titulo-icone">📋</div>
            <div>
                <h2>Doses Cadastradas</h2>
                <p>Lista de regras e intervalos de doses.</p>
            </div>
        </div>

        <div class="tabela-container">
            <table>
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Vacina</th>
                        <th>Dose</th>
                        <th>Intervalo</th>
                        <th>Faixa Etária</th>
                        <th>Reforço</th>
                        <th>Ações</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (count($doses) > 0): ?>
                        <?php $linha = 1; ?>
                        <?php foreach ($doses as $item): ?>
                            <tr>
                                <td><?= $linha++ ?></td>
                                <td><strong><?= htmlspecialchars($item['VacinaNome'] ?? 'Vacina não informada') ?></strong></td>
                                <td><?= htmlspecialchars($item['NumeroDose']) ?></td>
                                <td><?= $item['IntervaloDias'] ? htmlspecialchars($item['IntervaloDias']) . ' dias' : '-' ?></td>
                                <td><?= htmlspecialchars($item['FaixaEtaria'] ?? '-') ?></td>
                                <td><?= $item['Reforco'] ? 'Sim' : 'Não' ?></td>
                                <td>
                                    <a href="dose.php?excluir=<?= $item['Id'] ?>" class="btn-acao btn-excluir" onclick="return confirm('Deseja realmente excluir esta dose?')">Excluir</a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="7" style="text-align: center; color: #78909c;">Nenhuma dose cadastrada.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </section>
</main>

<footer>
    Amar V © <?= date("Y") ?>
</footer>

</body>
</html>>