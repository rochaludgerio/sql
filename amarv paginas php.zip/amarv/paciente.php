<?php
require_once "conexao.php";

$mensagem = "";
$erro = "";

/*
|--------------------------------------------------------------------------
| CADASTRAR / ATUALIZAR DADOS DO PACIENTE
|--------------------------------------------------------------------------
*/

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $acao = $_POST["acao"] ?? "";

    /*
    |--------------------------------------------------------------------------
    | SALVAR PACIENTE
    |--------------------------------------------------------------------------
    */

    if ($acao === "salvar_paciente") {

        $id = (int)($_POST["Id"] ?? 0);

        if ($id <= 0) {

            $erro = "Selecione uma pessoa válida.";

        } else {

            try {

                /*
                |--------------------------------------------------------------------------
                | LOCALIZA A PESSOA
                |--------------------------------------------------------------------------
                */

                $stmtPessoa = $pdo->prepare("
                    SELECT
                        Id,
                        Nome,
                        Cpf,
                        Telefone,
                        Endereco
                    FROM pessoa
                    WHERE Id = :Id
                    LIMIT 1
                ");

                $stmtPessoa->execute([
                    ":Id" => $id
                ]);

                $pessoa = $stmtPessoa->fetch(PDO::FETCH_ASSOC);

                if (!$pessoa) {

                    $erro = "A pessoa selecionada não foi encontrada.";

                } else {

                    /*
                    |--------------------------------------------------------------------------
                    | IMPEDIR USUÁRIO DO SISTEMA DE SER PACIENTE
                    |--------------------------------------------------------------------------
                    */

                    $stmtUsuario = $pdo->prepare("
                        SELECT Id
                        FROM usuario_do_sistema
                        WHERE Id = :Id
                        LIMIT 1
                    ");

                    $stmtUsuario->execute([
                        ":Id" => $id
                    ]);

                    $usuarioExiste = $stmtUsuario->fetch(PDO::FETCH_ASSOC);

                    if ($usuarioExiste) {

                        $erro = "Esta pessoa já está cadastrada como usuário do sistema e não pode ser cadastrada como paciente.";

                    } else {

                        /*
                        |--------------------------------------------------------------------------
                        | DADOS ESPECÍFICOS DO PACIENTE
                        |--------------------------------------------------------------------------
                        */

                        $dataNascimento = $_POST["DataNascimento"] ?? null;

                        $sexo = trim(
                            $_POST["Sexo"] ?? ""
                        );

                        $cartaoSUS = trim(
                            $_POST["CartaoSUS"] ?? ""
                        );

                        $nomeMae = trim(
                            $_POST["NomeMae"] ?? ""
                        );

                        $rua = trim(
                            $_POST["Rua"] ?? ""
                        );

                        $idadeAnos = (int)(
                            $_POST["IdadeAnos"] ?? 0
                        );

                        $idadeMesesAdicionais = (int)(
                            $_POST["IdadeMesesAdicionais"] ?? 0
                        );

                        $condicaoClinica = trim(
                            $_POST["CondicaoClinica"] ?? ""
                        );

                        $gestante = isset(
                            $_POST["Gestante"]
                        ) ? 1 : 0;

                        $semanasGestacao = (int)(
                            $_POST["SemanasGestacao"] ?? 0
                        );

                        $lactante = isset(
                            $_POST["Lactante"]
                        ) ? 1 : 0;

                        $criancaAmamentadaMenor6Meses =
                            isset(
                                $_POST["CriancaAmamentadaMenor6Meses"]
                            ) ? 1 : 0;

                        $imunossuprimido = isset(
                            $_POST["Imunossuprimido"]
                        ) ? 1 : 0;

                        $hiv = isset(
                            $_POST["HIV"]
                        ) ? 1 : 0;

                        $quimioterapia = isset(
                            $_POST["Quimioterapia"]
                        ) ? 1 : 0;

                        $transplantado = isset(
                            $_POST["Transplantado"]
                        ) ? 1 : 0;

                        $usoCorticoideOuImunobiologico =
                            isset(
                                $_POST["UsoCorticoideOuImunobiologico"]
                            ) ? 1 : 0;

                        $alergiaGrave = isset(
                            $_POST["AlergiaGrave"]
                        ) ? 1 : 0;

                        $febreOuDoencaAguda =
                            isset(
                                $_POST["FebreOuDoencaAguda"]
                            ) ? 1 : 0;

                        /*
                        |--------------------------------------------------------------------------
                        | VERIFICA SE JÁ EXISTE PACIENTE
                        |--------------------------------------------------------------------------
                        */

                        $stmtVerifica = $pdo->prepare("
                            SELECT Id
                            FROM paciente
                            WHERE Id = :Id
                            LIMIT 1
                        ");

                        $stmtVerifica->execute([
                            ":Id" => $id
                        ]);

                        $pacienteExiste =
                            $stmtVerifica->fetch(PDO::FETCH_ASSOC);

                        /*
                        |--------------------------------------------------------------------------
                        | TRANSAÇÃO
                        |--------------------------------------------------------------------------
                        */

                        $pdo->beginTransaction();

                        /*
                        |--------------------------------------------------------------------------
                        | ATUALIZAR PACIENTE
                        |--------------------------------------------------------------------------
                        */

                        if ($pacienteExiste) {

                            $sql = "
                                UPDATE paciente SET

                                    Nome = :Nome,
                                    Cpf = :Cpf,
                                    Telefone = :Telefone,
                                    Endereco = :Endereco,

                                    DataNascimento = :DataNascimento,
                                    Sexo = :Sexo,
                                    CartaoSUS = :CartaoSUS,
                                    NomeMae = :NomeMae,
                                    Rua = :Rua,

                                    IdadeAnos = :IdadeAnos,
                                    IdadeMesesAdicionais = :IdadeMesesAdicionais,

                                    CondicaoClinica = :CondicaoClinica,

                                    Gestante = :Gestante,
                                    SemanasGestacao = :SemanasGestacao,

                                    Lactante = :Lactante,
                                    CriancaAmamentadaMenor6Meses =
                                        :CriancaAmamentadaMenor6Meses,

                                    Imunossuprimido = :Imunossuprimido,
                                    HIV = :HIV,
                                    Quimioterapia = :Quimioterapia,
                                    Transplantado = :Transplantado,

                                    UsoCorticoideOuImunobiologico =
                                        :UsoCorticoideOuImunobiologico,

                                    AlergiaGrave = :AlergiaGrave,
                                    FebreOuDoencaAguda =
                                        :FebreOuDoencaAguda

                                WHERE Id = :Id
                            ";

                        } else {

                            /*
                            |--------------------------------------------------------------------------
                            | CADASTRAR PACIENTE
                            |--------------------------------------------------------------------------
                            */

                            $sql = "
                                INSERT INTO paciente (

                                    Id,

                                    Nome,
                                    Cpf,
                                    Telefone,
                                    Endereco,

                                    DataNascimento,
                                    Sexo,
                                    CartaoSUS,
                                    NomeMae,
                                    Rua,

                                    IdadeAnos,
                                    IdadeMesesAdicionais,

                                    CondicaoClinica,

                                    Gestante,
                                    SemanasGestacao,

                                    Lactante,
                                    CriancaAmamentadaMenor6Meses,

                                    Imunossuprimido,
                                    HIV,
                                    Quimioterapia,
                                    Transplantado,

                                    UsoCorticoideOuImunobiologico,

                                    AlergiaGrave,
                                    FebreOuDoencaAguda

                                ) VALUES (

                                    :Id,

                                    :Nome,
                                    :Cpf,
                                    :Telefone,
                                    :Endereco,

                                    :DataNascimento,
                                    :Sexo,
                                    :CartaoSUS,
                                    :NomeMae,
                                    :Rua,

                                    :IdadeAnos,
                                    :IdadeMesesAdicionais,

                                    :CondicaoClinica,

                                    :Gestante,
                                    :SemanasGestacao,

                                    :Lactante,
                                    :CriancaAmamentadaMenor6Meses,

                                    :Imunossuprimido,
                                    :HIV,
                                    :Quimioterapia,
                                    :Transplantado,

                                    :UsoCorticoideOuImunobiologico,

                                    :AlergiaGrave,
                                    :FebreOuDoencaAguda

                                )
                            ";
                        }

                        $stmt = $pdo->prepare($sql);

                        $stmt->execute([

                            ":Id" => $id,

                            ":Nome" =>
                                $pessoa["Nome"] ?? null,

                            ":Cpf" =>
                                !empty($pessoa["Cpf"])
                                    ? $pessoa["Cpf"]
                                    : null,

                            ":Telefone" =>
                                !empty($pessoa["Telefone"])
                                    ? $pessoa["Telefone"]
                                    : null,

                            ":Endereco" =>
                                !empty($pessoa["Endereco"])
                                    ? $pessoa["Endereco"]
                                    : null,

                            ":DataNascimento" =>
                                !empty($dataNascimento)
                                    ? $dataNascimento
                                    : null,

                            ":Sexo" =>
                                $sexo !== ""
                                    ? $sexo
                                    : null,

                            ":CartaoSUS" =>
                                $cartaoSUS !== ""
                                    ? $cartaoSUS
                                    : null,

                            ":NomeMae" =>
                                $nomeMae !== ""
                                    ? $nomeMae
                                    : null,

                            ":Rua" =>
                                $rua !== ""
                                    ? $rua
                                    : null,

                            ":IdadeAnos" =>
                                $idadeAnos,

                            ":IdadeMesesAdicionais" =>
                                $idadeMesesAdicionais,

                            ":CondicaoClinica" =>
                                $condicaoClinica !== ""
                                    ? $condicaoClinica
                                    : null,

                            ":Gestante" =>
                                $gestante,

                            ":SemanasGestacao" =>
                                $semanasGestacao,

                            ":Lactante" =>
                                $lactante,

                            ":CriancaAmamentadaMenor6Meses" =>
                                $criancaAmamentadaMenor6Meses,

                            ":Imunossuprimido" =>
                                $imunossuprimido,

                            ":HIV" =>
                                $hiv,

                            ":Quimioterapia" =>
                                $quimioterapia,

                            ":Transplantado" =>
                                $transplantado,

                            ":UsoCorticoideOuImunobiologico" =>
                                $usoCorticoideOuImunobiologico,

                            ":AlergiaGrave" =>
                                $alergiaGrave,

                            ":FebreOuDoencaAguda" =>
                                $febreOuDoencaAguda
                        ]);

                        $pdo->commit();

                        header(
                            "Location: paciente.php?sucesso=1"
                        );

                        exit;
                    }
                }

            } catch (PDOException $e) {

                if ($pdo->inTransaction()) {
                    $pdo->rollBack();
                }

                $erro =
                    "Erro ao salvar o paciente: "
                    . $e->getMessage();
            }
        }
    }


    /*
    |--------------------------------------------------------------------------
    | EXCLUIR PACIENTE
    |--------------------------------------------------------------------------
    */

    if ($acao === "excluir_paciente") {

        $id = (int)(
            $_POST["Id"] ?? 0
        );

        if ($id > 0) {

            try {

                /*
                |--------------------------------------------------------------------------
                | GARANTE QUE NÃO ESTÁ EXCLUINDO UM USUÁRIO DO SISTEMA
                |--------------------------------------------------------------------------
                */

                $stmtUsuario = $pdo->prepare("
                    SELECT Id
                    FROM usuario_do_sistema
                    WHERE Id = :Id
                    LIMIT 1
                ");

                $stmtUsuario->execute([
                    ":Id" => $id
                ]);

                if ($stmtUsuario->fetch(PDO::FETCH_ASSOC)) {

                    $erro =
                        "Este registro pertence a um usuário do sistema e não pode ser excluído como paciente.";

                } else {

                    $pdo->beginTransaction();

                    /*
                    |--------------------------------------------------------------------------
                    | EXCLUI HISTÓRICO VACINAL
                    |--------------------------------------------------------------------------
                    */

                    $stmtHistorico = $pdo->prepare("
                        DELETE FROM historico_vacinal
                        WHERE PacienteId = :PacienteId
                    ");

                    $stmtHistorico->execute([
                        ":PacienteId" => $id
                    ]);

                    /*
                    |--------------------------------------------------------------------------
                    | EXCLUI SOMENTE O PACIENTE
                    |--------------------------------------------------------------------------
                    */

                    $stmt = $pdo->prepare("
                        DELETE FROM paciente
                        WHERE Id = :Id
                    ");

                    $stmt->execute([
                        ":Id" => $id
                    ]);

                    $pdo->commit();

                    header(
                        "Location: paciente.php?deletado=1"
                    );

                    exit;
                }

            } catch (PDOException $e) {

                if ($pdo->inTransaction()) {
                    $pdo->rollBack();
                }

                $erro =
                    "Não foi possível excluir os dados do paciente. "
                    . "Verifique se existem registros relacionados. "
                    . $e->getMessage();
            }
        }
    }
}


/*
|--------------------------------------------------------------------------
| PESQUISA DE PESSOAS PARA CADASTRO DE PACIENTE
|--------------------------------------------------------------------------
|
| IMPORTANTE:
|
| A consulta começa pela tabela pessoa.
|
| Pessoas que já são usuários do sistema NÃO aparecem.
|
| Pessoas que já são pacientes aparecem como "Já cadastrado".
|
| Pessoas que ainda não são pacientes aparecem como "Não cadastrado".
|
|--------------------------------------------------------------------------
*/

$busca = trim(
    $_GET["busca"] ?? ""
);

$sql = "
    SELECT

        p.Id,
        p.Nome,
        p.Cpf,
        p.Telefone,
        p.Endereco,

        CASE
            WHEN pa.Id IS NOT NULL THEN 1
            ELSE 0
        END AS EhPaciente

    FROM pessoa p

    LEFT JOIN paciente pa
        ON pa.Id = p.Id

    WHERE NOT EXISTS (

        SELECT 1

        FROM usuario_do_sistema u

        WHERE u.Id = p.Id
    )
";

$params = [];

if ($busca !== "") {

    $sql .= "

        AND (

            p.Nome LIKE :busca

            OR p.Cpf LIKE :busca

            OR p.Telefone LIKE :busca

            OR p.Endereco LIKE :busca

        )
    ";

    $params[":busca"] = "%$busca%";
}

$sql .= "
    ORDER BY p.Nome ASC
";

$stmt = $pdo->prepare($sql);

$stmt->execute($params);

$pessoas =
    $stmt->fetchAll(PDO::FETCH_ASSOC);


/*
|--------------------------------------------------------------------------
| PACIENTE SELECIONADO
|--------------------------------------------------------------------------
*/

$pessoaSelecionada = null;
$pacienteSelecionado = null;

if (isset($_GET["pessoa"])) {

    $idPessoa = (int)(
        $_GET["pessoa"]
    );

    if ($idPessoa > 0) {

        /*
        |--------------------------------------------------------------------------
        | PRIMEIRO VERIFICA SE A PESSOA EXISTE
        |--------------------------------------------------------------------------
        */

        $stmtPessoa = $pdo->prepare("
            SELECT

                Id,
                Nome,
                Cpf,
                Telefone,
                Endereco

            FROM pessoa

            WHERE Id = :Id

            LIMIT 1
        ");

        $stmtPessoa->execute([
            ":Id" => $idPessoa
        ]);

        $pessoaSelecionada =
            $stmtPessoa->fetch(PDO::FETCH_ASSOC);


        /*
        |--------------------------------------------------------------------------
        | VERIFICA SE É USUÁRIO DO SISTEMA
        |--------------------------------------------------------------------------
        */

        if ($pessoaSelecionada) {

            $stmtUsuario = $pdo->prepare("
                SELECT Id
                FROM usuario_do_sistema
                WHERE Id = :Id
                LIMIT 1
            ");

            $stmtUsuario->execute([
                ":Id" => $idPessoa
            ]);

            if ($stmtUsuario->fetch(PDO::FETCH_ASSOC)) {

                $pessoaSelecionada = null;

                $erro =
                    "Esta pessoa é um usuário do sistema e não pode ser cadastrada como paciente.";

            } else {

                /*
                |--------------------------------------------------------------------------
                | CARREGA OS DADOS DO PACIENTE
                |--------------------------------------------------------------------------
                */

                $stmtPaciente = $pdo->prepare("
                    SELECT *
                    FROM paciente
                    WHERE Id = :Id
                    LIMIT 1
                ");

                $stmtPaciente->execute([
                    ":Id" => $idPessoa
                ]);

                $pacienteSelecionado =
                    $stmtPaciente->fetch(PDO::FETCH_ASSOC);
            }
        } else {

            $erro =
                "A pessoa selecionada não foi encontrada.";
        }
    }
}
?>

<!DOCTYPE html>

<html lang="pt-BR">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>
        Cadastro de Pacientes - Amar V
    </title>

    <link
        rel="stylesheet"
        href="css/estilo.css"
    >

    <style>

        .tabela-container {
            overflow-x: auto;
            margin-top: 20px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 10px;
        }

        th,
        td {
            padding: 12px 15px;
            text-align: left;
            border-bottom: 1px solid #e0e9eb;
        }

        th {
            background-color: #0b6e69;
            color: white;
            font-size: 14px;
        }

        tr:hover {
            background-color: #f5fbfa;
        }

        .form-grid {
            display: grid;
            grid-template-columns:
                repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
            margin-bottom: 15px;
        }

        .form-grupo {
            display: flex;
            flex-direction: column;
            gap: 5px;
        }

        .form-grupo label {
            font-weight: bold;
            font-size: 13px;
            color: #193f40;
        }

        .form-grupo input,
        .form-grupo select,
        .form-grupo textarea {
            padding: 10px;
            border: 1px solid #c2d6d4;
            border-radius: 8px;
            font-size: 14px;
        }

        .form-grupo textarea {
            resize: vertical;
            min-height: 80px;
        }

        .btn-acao {
            display: inline-block;
            padding: 6px 12px;
            border-radius: 6px;
            text-decoration: none;
            font-size: 12px;
            font-weight: bold;
            color: white;
            border: none;
            cursor: pointer;
        }

        .btn-editar {
            background-color: #0b6e69;
        }

        .btn-excluir {
            background-color: #d9534f;
        }

        .btn-cancelar {
            background-color: #607d8b;
            color: white;
            padding: 10px 18px;
            border-radius: 8px;
            text-decoration: none;
            font-weight: bold;
            display: inline-block;
        }

        .btn-voltar {
            background-color: #607d8b;
            color: white;
            padding: 10px 18px;
            border-radius: 8px;
            text-decoration: none;
            font-weight: bold;
            display: inline-block;
            margin-bottom: 20px;
        }

        .btn-selecionar {
            background-color: #0b6e69;
        }

        .alerta {
            padding: 12px 16px;
            border-radius: 8px;
            margin-bottom: 20px;
            font-weight: bold;
        }

        .alerta-sucesso {
            background-color: #e8f6eb;
            color: #28783a;
            border: 1px solid #c9e8ce;
        }

        .alerta-erro {
            background-color: #fde8e8;
            color: #c53030;
            border: 1px solid #f8b4b4;
        }

        .cabecalho-tabela {
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 10px;
        }

        .pesquisa-box {
            display: flex;
            gap: 10px;
            width: 100%;
            max-width: 450px;
        }

        .pesquisa-box input {
            flex: 1;
            padding: 8px 12px;
            border: 1px solid #c2d6d4;
            border-radius: 6px;
            font-size: 14px;
        }

        .acoes-col {
            white-space: nowrap;
        }

        .pessoa-selecionada {
            background-color: #f5fbfa;
            border: 1px solid #c2d6d4;
            border-radius: 10px;
            padding: 15px;
            margin-bottom: 20px;
        }

        .pessoa-selecionada strong {
            color: #0b6e69;
        }

        .grupo-condicoes {
            border: 1px solid #c2d6d4;
            border-radius: 10px;
            padding: 15px;
            margin-top: 15px;
            margin-bottom: 20px;
        }

        .grupo-condicoes h3 {
            margin-top: 0;
            color: #193f40;
        }

        .check-grid {
            display: grid;
            grid-template-columns:
                repeat(auto-fit, minmax(230px, 1fr));
            gap: 10px;
        }

        .check-item {
            display: flex;
            align-items: center;
            gap: 8px;
            padding: 8px;
            background-color: #f8fbfb;
            border-radius: 6px;
        }

        .check-item input {
            width: 18px;
            height: 18px;
        }

        .status-paciente {
            display: inline-block;
            padding: 4px 8px;
            border-radius: 5px;
            font-size: 11px;
            font-weight: bold;
        }

        .status-sim {
            background-color: #e8f6eb;
            color: #28783a;
        }

        .status-nao {
            background-color: #eef2f3;
            color: #607d8b;
        }

        .somente-leitura {
            background-color: #f2f5f5;
        }

    </style>

</head>

<body>

<header>

    <div class="logo">
        AMAR V
    </div>

    <div class="subtitulo">
        Gerenciamento de Pacientes
    </div>

</header>

<main>

    <a
        href="index.php"
        class="btn-voltar"
    >
        ← Voltar ao Início
    </a>


    <?php if (isset($_GET["sucesso"])): ?>

        <div class="alerta alerta-sucesso">

            Dados do paciente salvos com sucesso!

        </div>

    <?php endif; ?>


    <?php if (isset($_GET["deletado"])): ?>

        <div class="alerta alerta-sucesso">

            Dados do paciente excluídos com sucesso!

            A pessoa continua cadastrada.

        </div>

    <?php endif; ?>


    <?php if (!empty($erro)): ?>

        <div class="alerta alerta-erro">

            <?= htmlspecialchars($erro) ?>

        </div>

    <?php endif; ?>


    <!-- =========================================================
         PESQUISA DE PESSOAS
         ========================================================= -->

    <section class="card">

        <div class="cabecalho-tabela">

            <div
                class="titulo-secao"
                style="margin-bottom: 0;"
            >

                <div class="titulo-icone">
                    👤
                </div>

                <div>

                    <h2>
                        Localizar Pessoa
                    </h2>

                    <p>
                        Selecione uma pessoa já cadastrada para informar os dados do paciente.
                    </p>

                </div>

            </div>


            <form
                method="GET"
                class="pesquisa-box"
            >

                <input
                    type="text"
                    name="busca"
                    placeholder="Pesquisar por nome, CPF ou telefone..."
                    value="<?= htmlspecialchars($busca) ?>"
                >

                <button
                    type="submit"
                    class="btn-acao btn-editar"
                >
                    Buscar
                </button>


                <?php if ($busca !== ""): ?>

                    <a
                        href="paciente.php"
                        class="btn-acao btn-cancelar"
                        style="padding: 8px;"
                    >
                        Limpar
                    </a>

                <?php endif; ?>

            </form>

        </div>


        <div class="tabela-container">

            <table>

                <thead>

                    <tr>

                        <th>#</th>

                        <th>Nome</th>

                        <th>CPF</th>

                        <th>Telefone</th>

                        <th>Paciente</th>

                        <th>Ação</th>

                    </tr>

                </thead>


                <tbody>

                <?php if (count($pessoas) > 0): ?>

                    <?php $linha = 1; ?>

                    <?php foreach ($pessoas as $p): ?>

                        <tr>

                            <td>
                                <?= $linha++ ?>
                            </td>

                            <td>

                                <strong>
                                    <?= htmlspecialchars(
                                        $p["Nome"] ?? "-"
                                    ) ?>
                                </strong>

                            </td>

                            <td>
                                <?= htmlspecialchars(
                                    $p["Cpf"] ?? "-"
                                ) ?>
                            </td>

                            <td>
                                <?= htmlspecialchars(
                                    $p["Telefone"] ?? "-"
                                ) ?>
                            </td>

                            <td>

                                <?php if (
                                    (int)$p["EhPaciente"] === 1
                                ): ?>

                                    <span
                                        class="status-paciente status-sim"
                                    >
                                        Já cadastrado
                                    </span>

                                <?php else: ?>

                                    <span
                                        class="status-paciente status-nao"
                                    >
                                        Não cadastrado
                                    </span>

                                <?php endif; ?>

                            </td>

                            <td>

                                <a
                                    href="paciente.php?pessoa=<?= (int)$p["Id"] ?>"
                                    class="btn-acao btn-selecionar"
                                >

                                    <?= (
                                        (int)$p["EhPaciente"] === 1
                                    )
                                        ? "Editar Paciente"
                                        : "Cadastrar Paciente"
                                    ?>

                                </a>

                            </td>

                        </tr>

                    <?php endforeach; ?>

                <?php else: ?>

                    <tr>

                        <td
                            colspan="6"
                            style="
                                text-align:center;
                                color:#78909c;
                            "
                        >

                            Nenhuma pessoa disponível para cadastro de paciente.

                        </td>

                    </tr>

                <?php endif; ?>

                </tbody>

            </table>

        </div>

    </section>


    <!-- =========================================================
         FORMULÁRIO DO PACIENTE
         ========================================================= -->

    <?php if ($pessoaSelecionada): ?>

    <section class="card">

        <div class="titulo-secao">

            <div class="titulo-icone">
                🧑‍⚕️
            </div>

            <div>

                <h2>

                    <?= $pacienteSelecionado
                        ? "Editar Dados do Paciente"
                        : "Cadastrar Dados do Paciente"
                    ?>

                </h2>

                <p>
                    Informe os dados específicos do paciente.
                </p>

            </div>

        </div>


        <!-- DADOS DA PESSOA -->

        <div class="pessoa-selecionada">

            <strong>
                Pessoa selecionada:
            </strong>

            <?= htmlspecialchars(
                $pessoaSelecionada["Nome"] ?? "-"
            ) ?>

            <br>

            <strong>
                CPF:
            </strong>

            <?= htmlspecialchars(
                $pessoaSelecionada["Cpf"] ?? "-"
            ) ?>

            <br>

            <strong>
                Telefone:
            </strong>

            <?= htmlspecialchars(
                $pessoaSelecionada["Telefone"] ?? "-"
            ) ?>

            <br>

            <strong>
                Endereço:
            </strong>

            <?= htmlspecialchars(
                $pessoaSelecionada["Endereco"] ?? "-"
            ) ?>

            <br>

            <strong>
                ID:
            </strong>

            <?= (int)$pessoaSelecionada["Id"] ?>

        </div>


        <form
            action="paciente.php"
            method="POST"
        >

            <input
                type="hidden"
                name="acao"
                value="salvar_paciente"
            >

            <input
                type="hidden"
                name="Id"
                value="<?= (int)$pessoaSelecionada["Id"] ?>"
            >


            <!-- DADOS PESSOAIS -->

            <h3 style="color:#193f40;">
                Dados do Paciente
            </h3>


            <div class="form-grid">

                <div class="form-grupo">

                    <label>
                        Nome
                    </label>

                    <input
                        type="text"
                        class="somente-leitura"
                        value="<?= htmlspecialchars(
                            $pessoaSelecionada["Nome"] ?? ""
                        ) ?>"
                        readonly
                    >

                </div>


                <div class="form-grupo">

                    <label>
                        CPF
                    </label>

                    <input
                        type="text"
                        class="somente-leitura"
                        value="<?= htmlspecialchars(
                            $pessoaSelecionada["Cpf"] ?? ""
                        ) ?>"
                        readonly
                    >

                </div>


                <div class="form-grupo">

                    <label>
                        Data de Nascimento
                    </label>

                    <input
                        type="date"
                        name="DataNascimento"
                        value="<?=

                            !empty(
                                $pacienteSelecionado[
                                    "DataNascimento"
                                ]
                            )

                            ? date(
                                "Y-m-d",
                                strtotime(
                                    $pacienteSelecionado[
                                        "DataNascimento"
                                    ]
                                )
                            )

                            : ""

                        ?>"
                    >

                </div>


                <div class="form-grupo">

                    <label>
                        Sexo
                    </label>

                    <select name="Sexo">

                        <option value="">
                            Selecione
                        </option>

                        <option
                            value="Masculino"
                            <?= (
                                (
                                    $pacienteSelecionado[
                                        "Sexo"
                                    ] ?? ""
                                ) === "Masculino"
                            )
                                ? "selected"
                                : ""
                            ?>
                        >
                            Masculino
                        </option>

                        <option
                            value="Feminino"
                            <?= (
                                (
                                    $pacienteSelecionado[
                                        "Sexo"
                                    ] ?? ""
                                ) === "Feminino"
                            )
                                ? "selected"
                                : ""
                            ?>
                        >
                            Feminino
                        </option>

                        <option
                            value="Outro"
                            <?= (
                                (
                                    $pacienteSelecionado[
                                        "Sexo"
                                    ] ?? ""
                                ) === "Outro"
                            )
                                ? "selected"
                                : ""
                            ?>
                        >
                            Outro
                        </option>

                    </select>

                </div>


                <div class="form-grupo">

                    <label>
                        Cartão SUS
                    </label>

                    <input
                        type="text"
                        name="CartaoSUS"
                        placeholder="Número do Cartão SUS"
                        value="<?= htmlspecialchars(
                            $pacienteSelecionado[
                                "CartaoSUS"
                            ] ?? ""
                        ) ?>"
                    >

                </div>


                <div class="form-grupo">

                    <label>
                        Nome da Mãe
                    </label>

                    <input
                        type="text"
                        name="NomeMae"
                        placeholder="Nome completo da mãe"
                        value="<?= htmlspecialchars(
                            $pacienteSelecionado[
                                "NomeMae"
                            ] ?? ""
                        ) ?>"
                    >

                </div>


                <div class="form-grupo">

                    <label>
                        Rua
                    </label>

                    <input
                        type="text"
                        name="Rua"
                        placeholder="Rua"
                        value="<?= htmlspecialchars(
                            $pacienteSelecionado[
                                "Rua"
                            ] ?? ""
                        ) ?>"
                    >

                </div>

            </div>


            <!-- IDADE -->

            <h3 style="color:#193f40;">
                Idade
            </h3>


            <div class="form-grid">

                <div class="form-grupo">

                    <label>
                        Idade em anos
                    </label>

                    <input
                        type="number"
                        name="IdadeAnos"
                        min="0"
                        value="<?= (int)(
                            $pacienteSelecionado[
                                "IdadeAnos"
                            ] ?? 0
                        ) ?>"
                    >

                </div>


                <div class="form-grupo">

                    <label>
                        Meses adicionais
                    </label>

                    <input
                        type="number"
                        name="IdadeMesesAdicionais"
                        min="0"
                        max="11"
                        value="<?= (int)(
                            $pacienteSelecionado[
                                "IdadeMesesAdicionais"
                            ] ?? 0
                        ) ?>"
                    >

                </div>

            </div>


            <!-- CONDIÇÃO CLÍNICA -->

            <div class="grupo-condicoes">

                <h3>
                    Condição Clínica
                </h3>


                <div class="form-grupo">

                    <label>
                        Descrição da condição clínica
                    </label>

                    <textarea
                        name="CondicaoClinica"
                        placeholder="Informe alguma condição clínica relevante..."
                    ><?= htmlspecialchars(
                        $pacienteSelecionado[
                            "CondicaoClinica"
                        ] ?? ""
                    ) ?></textarea>

                </div>


                <div class="check-grid">

                    <label class="check-item">

                        <input
                            type="checkbox"
                            name="Gestante"
                            value="1"
                            <?= !empty(
                                $pacienteSelecionado[
                                    "Gestante"
                                ]
                            )
                                ? "checked"
                                : ""
                            ?>
                        >

                        Gestante

                    </label>


                    <label class="check-item">

                        <input
                            type="checkbox"
                            name="Lactante"
                            value="1"
                            <?= !empty(
                                $pacienteSelecionado[
                                    "Lactante"
                                ]
                            )
                                ? "checked"
                                : ""
                            ?>
                        >

                        Lactante

                    </label>


                    <label class="check-item">

                        <input
                            type="checkbox"
                            name="CriancaAmamentadaMenor6Meses"
                            value="1"
                            <?= !empty(
                                $pacienteSelecionado[
                                    "CriancaAmamentadaMenor6Meses"
                                ]
                            )
                                ? "checked"
                                : ""
                            ?>
                        >

                        Criança amamentada menor de 6 meses

                    </label>


                    <label class="check-item">

                        <input
                            type="checkbox"
                            name="Imunossuprimido"
                            value="1"
                            <?= !empty(
                                $pacienteSelecionado[
                                    "Imunossuprimido"
                                ]
                            )
                                ? "checked"
                                : ""
                            ?>
                        >

                        Imunossuprimido

                    </label>


                    <label class="check-item">

                        <input
                            type="checkbox"
                            name="HIV"
                            value="1"
                            <?= !empty(
                                $pacienteSelecionado[
                                    "HIV"
                                ]
                            )
                                ? "checked"
                                : ""
                            ?>
                        >

                        HIV

                    </label>


                    <label class="check-item">

                        <input
                            type="checkbox"
                            name="Quimioterapia"
                            value="1"
                            <?= !empty(
                                $pacienteSelecionado[
                                    "Quimioterapia"
                                ]
                            )
                                ? "checked"
                                : ""
                            ?>
                        >

                        Quimioterapia

                    </label>


                    <label class="check-item">

                        <input
                            type="checkbox"
                            name="Transplantado"
                            value="1"
                            <?= !empty(
                                $pacienteSelecionado[
                                    "Transplantado"
                                ]
                            )
                                ? "checked"
                                : ""
                            ?>
                        >

                        Transplantado

                    </label>


                    <label class="check-item">

                        <input
                            type="checkbox"
                            name="UsoCorticoideOuImunobiologico"
                            value="1"
                            <?= !empty(
                                $pacienteSelecionado[
                                    "UsoCorticoideOuImunobiologico"
                                ]
                            )
                                ? "checked"
                                : ""
                            ?>
                        >

                        Uso de corticoide ou imunobiológico

                    </label>


                    <label class="check-item">

                        <input
                            type="checkbox"
                            name="AlergiaGrave"
                            value="1"
                            <?= !empty(
                                $pacienteSelecionado[
                                    "AlergiaGrave"
                                ]
                            )
                                ? "checked"
                                : ""
                            ?>
                        >

                        Alergia grave

                    </label>


                    <label class="check-item">

                        <input
                            type="checkbox"
                            name="FebreOuDoencaAguda"
                            value="1"
                            <?= !empty(
                                $pacienteSelecionado[
                                    "FebreOuDoencaAguda"
                                ]
                            )
                                ? "checked"
                                : ""
                            ?>
                        >

                        Febre ou doença aguda

                    </label>

                </div>

            </div>


            <!-- GESTAÇÃO -->

            <div class="form-grid">

                <div class="form-grupo">

                    <label>
                        Semanas de gestação
                    </label>

                    <input
                        type="number"
                        name="SemanasGestacao"
                        min="0"
                        max="45"
                        value="<?= (int)(
                            $pacienteSelecionado[
                                "SemanasGestacao"
                            ] ?? 0
                        ) ?>"
                    >

                </div>

            </div>


            <!-- BOTÕES -->

            <div
                style="
                    display:flex;
                    gap:10px;
                    align-items:center;
                    flex-wrap:wrap;
                "
            >

                <button
                    type="submit"
                    class="botao"
                >

                    <?= $pacienteSelecionado
                        ? "Atualizar Dados do Paciente"
                        : "Salvar Dados do Paciente"
                    ?>

                </button>


                <a
                    href="paciente.php"
                    class="btn-cancelar"
                >
                    Cancelar
                </a>

            </div>

        </form>


        <!-- EXCLUIR PACIENTE -->

        <?php if ($pacienteSelecionado): ?>

            <hr
                style="
                    margin:25px 0;
                    border:0;
                    border-top:1px solid #e0e9eb;
                "
            >


            <form
                action="paciente.php"
                method="POST"
                onsubmit="return confirm(
                    'Deseja realmente excluir os dados de paciente? A pessoa continuará cadastrada.'
                );"
            >

                <input
                    type="hidden"
                    name="acao"
                    value="excluir_paciente"
                >

                <input
                    type="hidden"
                    name="Id"
                    value="<?= (int)(
                        $pessoaSelecionada["Id"]
                    ) ?>"
                >


                <button
                    type="submit"
                    class="btn-acao btn-excluir"
                >

                    🗑️ Excluir Dados de Paciente

                </button>

            </form>

        <?php endif; ?>

    </section>

    <?php endif; ?>

</main>


<footer>

    Amar V © <?= date("Y") ?>

</footer>


</body>

</html>