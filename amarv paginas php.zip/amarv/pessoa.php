<?php
require_once "conexao.php";

$mensagem = "";
$erro = "";

/*
|--------------------------------------------------------------------------
| CADASTRAR / EDITAR PESSOA
|--------------------------------------------------------------------------
*/
if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $acao = $_POST["acao"] ?? "";

    $nome = trim($_POST["Nome"] ?? "");
    $cpf = trim($_POST["Cpf"] ?? "");
    $telefone = trim($_POST["Telefone"] ?? "");
    $endereco = trim($_POST["Endereco"] ?? "");

    if ($nome === "") {
        $erro = "O nome da pessoa é obrigatório.";
    } else {

        try {

            /*
            |--------------------------------------------------------------------------
            | CADASTRAR
            |--------------------------------------------------------------------------
            */
            if ($acao === "cadastrar") {

                $sql = "INSERT INTO pessoa
                        (Nome, Cpf, Telefone, Endereco)
                        VALUES
                        (:Nome, :Cpf, :Telefone, :Endereco)";

                $stmt = $pdo->prepare($sql);

                $stmt->execute([
                    ":Nome" => $nome,
                    ":Cpf" => $cpf !== "" ? $cpf : null,
                    ":Telefone" => $telefone !== "" ? $telefone : null,
                    ":Endereco" => $endereco !== "" ? $endereco : null
                ]);

                header("Location: pessoa.php?sucesso=1");
                exit;
            }


            /*
            |--------------------------------------------------------------------------
            | EDITAR
            |--------------------------------------------------------------------------
            */
            if ($acao === "editar") {

                $id = (int)($_POST["Id"] ?? 0);

                if ($id <= 0) {

                    $erro = "Pessoa inválida.";

                } else {

                    $sql = "UPDATE pessoa
                            SET Nome = :Nome,
                                Cpf = :Cpf,
                                Telefone = :Telefone,
                                Endereco = :Endereco
                            WHERE Id = :Id";

                    $stmt = $pdo->prepare($sql);

                    $stmt->execute([
                        ":Nome" => $nome,
                        ":Cpf" => $cpf !== "" ? $cpf : null,
                        ":Telefone" => $telefone !== "" ? $telefone : null,
                        ":Endereco" => $endereco !== "" ? $endereco : null,
                        ":Id" => $id
                    ]);

                    header("Location: pessoa.php?editado=1");
                    exit;
                }
            }

        } catch (PDOException $e) {

            $erro = "Erro ao salvar: " . $e->getMessage();
        }
    }
}


/*
|--------------------------------------------------------------------------
| EXCLUIR PESSOA
|--------------------------------------------------------------------------
|
| A pessoa NÃO será excluída se estiver vinculada:
|
| - a um paciente
| - a um usuário do sistema
| - a histórico vacinal
|
| Isso evita apagar dados relacionados acidentalmente.
|--------------------------------------------------------------------------
*/
if (isset($_GET["excluir"])) {

    $id = (int)$_GET["excluir"];

    if ($id > 0) {

        try {

            /*
            |--------------------------------------------------------------------------
            | Verifica se existe usuário do sistema
            |--------------------------------------------------------------------------
            */
            $stmt = $pdo->prepare(
                "SELECT COUNT(*)
                 FROM usuario_do_sistema
                 WHERE Id = :Id"
            );

            $stmt->execute([
                ":Id" => $id
            ]);

            $temUsuario = (int)$stmt->fetchColumn();


            /*
            |--------------------------------------------------------------------------
            | Verifica se existe paciente
            |--------------------------------------------------------------------------
            */
            $stmt = $pdo->prepare(
                "SELECT COUNT(*)
                 FROM paciente
                 WHERE Id = :Id"
            );

            $stmt->execute([
                ":Id" => $id
            ]);

            $temPaciente = (int)$stmt->fetchColumn();


            /*
            |--------------------------------------------------------------------------
            | Verifica histórico vacinal
            |--------------------------------------------------------------------------
            */
            $temHistorico = 0;

            if ($temPaciente > 0) {

                $stmt = $pdo->prepare(
                    "SELECT COUNT(*)
                     FROM historico_vacinal
                     WHERE PacienteId = :PacienteId"
                );

                $stmt->execute([
                    ":PacienteId" => $id
                ]);

                $temHistorico = (int)$stmt->fetchColumn();
            }


            /*
            |--------------------------------------------------------------------------
            | Impede exclusão de pessoa vinculada
            |--------------------------------------------------------------------------
            */
            if ($temUsuario > 0) {

                $erro = "Não é possível excluir esta pessoa porque ela está vinculada a um usuário do sistema.";

            } elseif ($temHistorico > 0) {

                $erro = "Não é possível excluir esta pessoa porque ela possui histórico vacinal.";

            } elseif ($temPaciente > 0) {

                $erro = "Não é possível excluir esta pessoa porque ela está cadastrada como paciente.";

            } else {

                /*
                |--------------------------------------------------------------------------
                | Exclui somente a pessoa sem vínculos
                |--------------------------------------------------------------------------
                */
                $stmt = $pdo->prepare(
                    "DELETE FROM pessoa
                     WHERE Id = :Id"
                );

                $stmt->execute([
                    ":Id" => $id
                ]);

                header("Location: pessoa.php?deletado=1");
                exit;
            }

        } catch (PDOException $e) {

            $erro = "Não foi possível excluir a pessoa. Verifique os registros relacionados.";
        }
    }
}


/*
|--------------------------------------------------------------------------
| BUSCAR PESSOA PARA EDIÇÃO
|--------------------------------------------------------------------------
*/
$pessoaEdicao = null;

if (isset($_GET["editar"])) {

    $id = (int)$_GET["editar"];

    if ($id > 0) {

        $stmt = $pdo->prepare(
            "SELECT *
             FROM pessoa
             WHERE Id = :Id"
        );

        $stmt->execute([
            ":Id" => $id
        ]);

        $pessoaEdicao = $stmt->fetch();
    }
}


/*
|--------------------------------------------------------------------------
| PESQUISA / CONSULTA
|--------------------------------------------------------------------------
*/
$busca = trim($_GET["busca"] ?? "");

if ($busca !== "") {

    $stmt = $pdo->prepare(
        "SELECT
            Id,
            Nome,
            Cpf,
            Telefone,
            Endereco
         FROM pessoa
         WHERE Nome LIKE :busca
            OR Cpf LIKE :busca
            OR Telefone LIKE :busca
            OR Endereco LIKE :busca
         ORDER BY Nome ASC"
    );

    $stmt->execute([
        ":busca" => "%$busca%"
    ]);

    $pessoas = $stmt->fetchAll();

} else {

    $stmt = $pdo->query(
        "SELECT
            Id,
            Nome,
            Cpf,
            Telefone,
            Endereco
         FROM pessoa
         ORDER BY Nome ASC"
    );

    $pessoas = $stmt->fetchAll();
}

?>
<!DOCTYPE html>
<html lang="pt-BR">

<head>

    <meta charset="UTF-8">

    <meta name="viewport"
          content="width=device-width, initial-scale=1.0">

    <title>Cadastro de Pessoas - Amar V</title>

    <link rel="stylesheet" href="css/estilo.css">

    <style>

        .tabela-container {
            overflow-x: auto;
            margin-top: 20px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 10px;
        }

        th,
        td {
            padding: 12px 15px;
            text-align: left;
            border-bottom: 1px solid #e0e9eb;
        }

        th {
            background-color: #0b6e69;
            color: white;
            font-size: 14px;
        }

        tr:hover {
            background-color: #f5fbfa;
        }

        .form-grid {
            display: grid;
            grid-template-columns: repeat(
                auto-fit,
                minmax(200px, 1fr)
            );

            gap: 15px;
            margin-bottom: 15px;
        }

        .form-grupo {
            display: flex;
            flex-direction: column;
            gap: 5px;
        }

        .form-grupo label {
            font-weight: bold;
            font-size: 13px;
            color: #193f40;
        }

        .form-grupo input {
            padding: 10px;
            border: 1px solid #c2d6d4;
            border-radius: 8px;
            font-size: 14px;
        }

        .btn-acao {
            display: inline-block;
            padding: 6px 12px;
            border-radius: 6px;
            text-decoration: none;
            font-size: 12px;
            font-weight: bold;
            color: white;
            border: none;
            cursor: pointer;
        }

        .btn-editar {
            background-color: #0b6e69;
        }

        .btn-excluir {
            background-color: #d9534f;
        }

        .btn-cancelar {
            background-color: #607d8b;
            color: white;
            padding: 10px 18px;
            border-radius: 8px;
            text-decoration: none;
            font-weight: bold;
            display: inline-block;
        }

        .btn-voltar {
            background-color: #607d8b;
            color: white;
            padding: 10px 18px;
            border-radius: 8px;
            text-decoration: none;
            font-weight: bold;
            display: inline-block;
            margin-bottom: 20px;
        }

        .alerta {
            padding: 12px 16px;
            border-radius: 8px;
            margin-bottom: 20px;
            font-weight: bold;
        }

        .alerta-sucesso {
            background-color: #e8f6eb;
            color: #28783a;
            border: 1px solid #c9e8ce;
        }

        .alerta-erro {
            background-color: #fde8e8;
            color: #c53030;
            border: 1px solid #f8b4b4;
        }

        .cabecalho-tabela {
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 10px;
        }

        .pesquisa-box {
            display: flex;
            gap: 10px;
            width: 100%;
            max-width: 400px;
        }

        .pesquisa-box input {
            flex: 1;
            padding: 8px 12px;
            border: 1px solid #c2d6d4;
            border-radius: 6px;
            font-size: 14px;
        }

        .acoes-col {
            white-space: nowrap;
            display: flex;
            gap: 6px;
        }

    </style>

</head>

<body>

<header>

    <div class="logo">
        AMAR V
    </div>

    <div class="subtitulo">
        Gerenciamento de Pessoas
    </div>

</header>


<main>

    <a href="index.php" class="btn-voltar">
        ← Voltar ao Início
    </a>


    <?php if (isset($_GET['sucesso'])): ?>

        <div class="alerta alerta-sucesso">
            Pessoa cadastrada com sucesso!
        </div>

    <?php endif; ?>


    <?php if (isset($_GET['editado'])): ?>

        <div class="alerta alerta-sucesso">
            Pessoa atualizada com sucesso!
        </div>

    <?php endif; ?>


    <?php if (isset($_GET['deletado'])): ?>

        <div class="alerta alerta-sucesso">
            Pessoa excluída com sucesso!
        </div>

    <?php endif; ?>


    <?php if (!empty($erro)): ?>

        <div class="alerta alerta-erro">
            <?= htmlspecialchars($erro) ?>
        </div>

    <?php endif; ?>


    <section class="card">

        <div class="titulo-secao">

            <div class="titulo-icone">
                👥
            </div>

            <div>

                <h2>
                    <?= $pessoaEdicao
                        ? "Editar Pessoa"
                        : "Cadastrar Nova Pessoa"
                    ?>
                </h2>

                <p>
                    <?= $pessoaEdicao
                        ? "Altere os dados da pessoa selecionada."
                        : "Insira os dados cadastrais da pessoa."
                    ?>
                </p>

            </div>

        </div>


        <form action="pessoa.php" method="POST">

            <input
                type="hidden"
                name="acao"
                value="<?= $pessoaEdicao ? "editar" : "cadastrar" ?>"
            >


            <?php if ($pessoaEdicao): ?>

                <input
                    type="hidden"
                    name="Id"
                    value="<?= (int)$pessoaEdicao["Id"] ?>"
                >

            <?php endif; ?>


            <div class="form-grid">

                <div class="form-grupo">

                    <label>
                        Nome Completo *
                    </label>

                    <input
                        type="text"
                        name="Nome"
                        placeholder="Ex: Maria da Silva"
                        required
                        value="<?= htmlspecialchars(
                            $pessoaEdicao["Nome"] ?? ""
                        ) ?>"
                    >

                </div>


                <div class="form-grupo">

                    <label>
                        CPF
                    </label>

                    <input
                        type="text"
                        name="Cpf"
                        placeholder="000.000.000-00"
                        value="<?= htmlspecialchars(
                            $pessoaEdicao["Cpf"] ?? ""
                        ) ?>"
                    >

                </div>


                <div class="form-grupo">

                    <label>
                        Telefone
                    </label>

                    <input
                        type="text"
                        name="Telefone"
                        placeholder="(00) 00000-0000"
                        value="<?= htmlspecialchars(
                            $pessoaEdicao["Telefone"] ?? ""
                        ) ?>"
                    >

                </div>


                <div class="form-grupo">

                    <label>
                        Endereço
                    </label>

                    <input
                        type="text"
                        name="Endereco"
                        placeholder="Rua, Número, Bairro"
                        value="<?= htmlspecialchars(
                            $pessoaEdicao["Endereco"] ?? ""
                        ) ?>"
                    >

                </div>

            </div>


            <div
                style="
                    display: flex;
                    gap: 10px;
                    align-items: center;
                "
            >

                <button
                    type="submit"
                    class="botao"
                >
                    <?= $pessoaEdicao
                        ? "Atualizar Pessoa"
                        : "Salvar Pessoa"
                    ?>
                </button>


                <?php if ($pessoaEdicao): ?>

                    <a
                        href="pessoa.php"
                        class="btn-cancelar"
                    >
                        Cancelar
                    </a>

                <?php endif; ?>

            </div>

        </form>

    </section>


    <section class="card">

        <div class="cabecalho-tabela">

            <div
                class="titulo-secao"
                style="margin-bottom: 0;"
            >

                <div class="titulo-icone">
                    📋
                </div>

                <div>

                    <h2>
                        Pessoas Cadastradas
                    </h2>

                    <p>
                        Lista de pessoas cadastradas na base de dados.
                    </p>

                </div>

            </div>


            <form
                method="GET"
                class="pesquisa-box"
            >

                <input
                    type="text"
                    name="busca"
                    placeholder="Pesquisar..."
                    value="<?= htmlspecialchars($busca) ?>"
                >


                <button
                    type="submit"
                    class="btn-acao btn-editar"
                >
                    Buscar
                </button>


                <?php if ($busca !== ""): ?>

                    <a
                        href="pessoa.php"
                        class="btn-acao btn-cancelar"
                        style="padding: 8px;"
                    >
                        Limpar
                    </a>

                <?php endif; ?>

            </form>

        </div>


        <div class="tabela-container">

            <table>

                <thead>

                    <tr>

                        <th>#</th>

                        <th>Nome</th>

                        <th>CPF</th>

                        <th>Telefone</th>

                        <th>Endereço</th>

                        <th>Ações</th>

                    </tr>

                </thead>


                <tbody>

                    <?php if (count($pessoas) > 0): ?>

                        <?php $linha = 1; ?>


                        <?php foreach ($pessoas as $p): ?>

                            <tr>

                                <td>
                                    <?= $linha++ ?>
                                </td>


                                <td>

                                    <strong>
                                        <?= htmlspecialchars(
                                            $p['Nome']
                                        ) ?>
                                    </strong>

                                </td>


                                <td>
                                    <?= htmlspecialchars(
                                        $p['Cpf'] ?? '-'
                                    ) ?>
                                </td>


                                <td>
                                    <?= htmlspecialchars(
                                        $p['Telefone'] ?? '-'
                                    ) ?>
                                </td>


                                <td>
                                    <?= htmlspecialchars(
                                        $p['Endereco'] ?? '-'
                                    ) ?>
                                </td>


                                <td class="acoes-col">

                                    <a
                                        href="pessoa.php?editar=<?= (int)$p['Id'] ?>"
                                        class="btn-acao btn-editar"
                                    >
                                        Editar
                                    </a>


                                    <a
                                        href="pessoa.php?excluir=<?= (int)$p['Id'] ?>"
                                        class="btn-acao btn-excluir"
                                        onclick="return confirm('Deseja realmente excluir esta pessoa?')"
                                    >
                                        Excluir
                                    </a>

                                </td>

                            </tr>

                        <?php endforeach; ?>


                    <?php else: ?>

                        <tr>

                            <td
                                colspan="6"
                                style="
                                    text-align: center;
                                    color: #78909c;
                                "
                            >
                                Nenhuma pessoa encontrada.
                            </td>

                        </tr>

                    <?php endif; ?>

                </tbody>

            </table>

        </div>

    </section>

</main>


<footer>

    Amar V © <?= date("Y") ?>

</footer>


</body>

</html>