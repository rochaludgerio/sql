<?php
require_once "conexao.php";

$mensagem = "";

// REGISTRAR APLICAÇÃO DE VACINA
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['acao']) && $_POST['acao'] === 'cadastrar') {
    $pacienteId = (int)($_POST['paciente_id'] ?? 0);
    $regraVacinalId = (int)($_POST['regra_vacinal_id'] ?? 0);
    $dataAplicacao = $_POST['data_aplicacao'] ?? null;
    $lote = trim($_POST['lote'] ?? '');

    // Busca o nome do paciente
    $stmtP = $pdo->prepare("SELECT Nome FROM paciente WHERE Id = ?");
    $stmtP->execute([$pacienteId]);
    $paciente = $stmtP->fetch();

    // Busca o nome da vacina na tabela vacina
    $stmtV = $pdo->prepare("SELECT Nome FROM vacina WHERE Id = ?");
    $stmtV->execute([$regraVacinalId]);
    $vacina = $stmtV->fetch();

    if ($paciente && $vacina && !empty($dataAplicacao)) {
        $stmt = $pdo->prepare("
            INSERT INTO historico_vacinal 
            (PacienteId, NomePaciente, RegraVacinalId, NomeVacina, DataAplicacao, Lote, DataRegistro) 
            VALUES (?, ?, ?, ?, ?, ?, NOW())
        ");
        $stmt->execute([
            $pacienteId, 
            $paciente['Nome'], 
            $regraVacinalId, 
            $vacina['Nome'], 
            $dataAplicacao, 
            $lote ?: null
        ]);

        header("Location: historico_vacinal.php?sucesso=1");
        exit;
    } else {
        $mensagem = "Selecione o paciente, a vacina e a data de aplicação.";
    }
}

// EXCLUIR UM ÚNICO REGISTRO
if (isset($_GET['excluir'])) {
    $idExcluir = (int)$_GET['excluir'];
    $stmt = $pdo->prepare("DELETE FROM historico_vacinal WHERE Id = ?");
    $stmt->execute([$idExcluir]);
    header("Location: historico_vacinal.php?deletado=1");
    exit;
}

// EXCLUIR TODO O HISTÓRICO VACINAL
if (isset($_POST['acao']) && $_POST['acao'] === 'limpar_tudo') {
    $pdo->query("DELETE FROM historico_vacinal");
    header("Location: historico_vacinal.php?limpado_tudo=1");
    exit;
}

// CONSULTA DIRETA NA TABELA HISTORICO_VACINAL
$stmt = $pdo->query("
    SELECT Id, PacienteId, NomePaciente, RegraVacinalId, NomeVacina, DataAplicacao, Lote 
    FROM historico_vacinal 
    ORDER BY Id DESC
");
$historicos = $stmt->fetchAll();

$pacientes = $pdo->query("SELECT Id, Nome FROM paciente ORDER BY Nome ASC")->fetchAll();
$vacinas = $pdo->query("SELECT Id, Nome FROM vacina ORDER BY Nome ASC")->fetchAll();
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Histórico Vacinal - Amar V</title>
    <link rel="stylesheet" href="css/estilo.css">
    <style>
        .tabela-container { overflow-x: auto; margin-top: 20px; }
        table { width: 100%; border-collapse: collapse; margin-top: 10px; }
        th, td { padding: 12px 15px; text-align: left; border-bottom: 1px solid #e0e9eb; }
        th { background-color: #0b6e69; color: white; font-size: 14px; }
        tr:hover { background-color: #f5fbfa; }
        .form-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 15px; margin-bottom: 15px; }
        .form-grupo { display: flex; flex-direction: column; gap: 5px; }
        .form-grupo label { font-weight: bold; font-size: 13px; color: #193f40; }
        .form-grupo input, .form-grupo select { padding: 10px; border: 1px solid #c2d6d4; border-radius: 8px; font-size: 14px; }
        .btn-acao { display: inline-block; padding: 6px 12px; border-radius: 6px; text-decoration: none; font-size: 12px; font-weight: bold; color: white; border: none; cursor: pointer; }
        .btn-excluir { background-color: #d9534f; }
        .btn-limpar-tudo { background-color: #c9302c; color: white; border: none; padding: 10px 16px; border-radius: 8px; font-weight: bold; cursor: pointer; }
        .btn-voltar { background-color: #607d8b; color: white; padding: 10px 18px; border-radius: 8px; text-decoration: none; font-weight: bold; display: inline-block; margin-bottom: 20px; }
        .alerta { padding: 12px 16px; border-radius: 8px; margin-bottom: 20px; font-weight: bold; }
        .alerta-sucesso { background-color: #e8f6eb; color: #28783a; border: 1px solid #c9e8ce; }
        .alerta-erro { background-color: #fde8e8; color: #c53030; border: 1px solid #f8b4b4; }
        .cabecalho-tabela { display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 10px; }
    </style>
</head>
<body>

<header>
    <div class="logo">AMAR V</div>
    <div class="subtitulo">Registro de Aplicações de Vacina</div>
</header>

<main>
    <a href="index.php" class="btn-voltar">← Voltar ao Início</a>

    <?php if (isset($_GET['sucesso'])): ?>
        <div class="alerta alerta-sucesso">Registro de vacina salvo com sucesso!</div>
    <?php endif; ?>

    <?php if (isset($_GET['deletado'])): ?>
        <div class="alerta alerta-sucesso">Registro excluído com sucesso!</div>
    <?php endif; ?>

    <?php if (isset($_GET['limpado_tudo'])): ?>
        <div class="alerta alerta-sucesso">Todo o histórico de aplicações foi excluído com sucesso!</div>
    <?php endif; ?>

    <?php if (!empty($mensagem)): ?>
        <div class="alerta alerta-erro"><?= htmlspecialchars($mensagem) ?></div>
    <?php endif; ?>

    <section class="card">
        <div class="titulo-secao">
            <div class="titulo-icone">📖</div>
            <div>
                <h2>Registrar Vacina Aplicada</h2>
                <p>Vinculação da vacina aplicada a um paciente registrado.</p>
            </div>
        </div>

        <form action="historico_vacinal.php" method="POST">
            <input type="hidden" name="acao" value="cadastrar">
            
            <div class="form-grid">
                <div class="form-grupo">
                    <label>Paciente *</label>
                    <select name="paciente_id" required>
                        <option value="">-- Selecione o Paciente --</option>
                        <?php foreach ($pacientes as $p): ?>
                            <option value="<?= $p['Id'] ?>"><?= htmlspecialchars($p['Nome']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="form-grupo">
                    <label>Vacina Aplicada *</label>
                    <select name="regra_vacinal_id" required>
                        <option value="">-- Selecione a Vacina --</option>
                        <?php foreach ($vacinas as $v): ?>
                            <option value="<?= $v['Id'] ?>"><?= htmlspecialchars($v['Nome']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="form-grupo">
                    <label>Data de Aplicação *</label>
                    <input type="date" name="data_aplicacao" required>
                </div>

                <div class="form-grupo">
                    <label>Lote da Vacina</label>
                    <input type="text" name="lote" placeholder="Ex: AB12345">
                </div>
            </div>

            <button type="submit" class="botao">Salvar Registro</button>
        </form>
    </section>

    <section class="card">
        <div class="cabecalho-tabela">
            <div class="titulo-secao" style="margin-bottom: 0;">
                <div class="titulo-icone">📋</div>
                <div>
                    <h2>Histórico Geral de Aplicações</h2>
                    <p>Lista de vacinas administradas.</p>
                </div>
            </div>

            <?php if (count($historicos) > 0): ?>
                <form action="historico_vacinal.php" method="POST" onsubmit="return confirm('ATENÇÃO: Deseja realmente excluir TODO o histórico vacinal? Esta ação não poderá ser desfeita!');">
                    <input type="hidden" name="acao" value="limpar_tudo">
                    <button type="submit" class="btn-limpar-tudo">🗑️ Apagar Todo Histórico</button>
                </form>
            <?php endif; ?>
        </div>

        <div class="tabela-container">
            <table>
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Paciente</th>
                        <th>Vacina</th>
                        <th>Data de Aplicação</th>
                        <th>Lote</th>
                        <th>Ações</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (count($historicos) > 0): ?>
                        <?php $linha = 1; ?>
                        <?php foreach ($historicos as $item): ?>
                            <tr>
                                <td><?= $linha++ ?></td>
                                <td><strong><?= htmlspecialchars($item['NomePaciente'] ?? 'Não informado') ?></strong></td>
                                <td><?= htmlspecialchars($item['NomeVacina'] ?? 'Não informada') ?></td>
                                <td>
                                    <?php 
                                        if (!empty($item['DataAplicacao']) && $item['DataAplicacao'] !== '0001-01-01 00:00:00') {
                                            echo date('d/m/Y', strtotime($item['DataAplicacao']));
                                        } else {
                                            echo 'Não informada';
                                        }
                                    ?>
                                </td>
                                <td><?= htmlspecialchars($item['Lote'] ?? '-') ?></td>
                                <td>
                                    <a href="historico_vacinal.php?excluir=<?= $item['Id'] ?>" class="btn-acao btn-excluir" onclick="return confirm('Deseja realmente excluir este histórico?')">Excluir</a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="6" style="text-align: center; color: #78909c;">Nenhum registro de vacina encontrado.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </section>
</main>

<footer>
    Amar V © <?= date("Y") ?>
</footer>

</body>
</html>