<<?php
require_once "conexao.php";

$erro = "";

/*
|--------------------------------------------------------------------------
| CADASTRAR / EDITAR ADMINISTRADOR
|--------------------------------------------------------------------------
*/
if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $acao = $_POST["acao"] ?? "";

    $id = (int)($_POST["Id"] ?? 0);

    // No sistema Amar V existe somente o nível Administrador
    $nivelAcesso = "Administrador";

    if ($id <= 0) {

        $erro = "Selecione um usuário válido.";

    } else {

        try {

            /*
            |--------------------------------------------------------------------------
            | VERIFICAR SE O USUÁRIO EXISTE
            |--------------------------------------------------------------------------
            */
            $stmt = $pdo->prepare("
                SELECT
                    u.Id,
                    u.Login,
                    u.Perfil,
                    u.Status,
                    u.Ativo,
                    p.Nome,
                    p.Cpf,
                    p.Telefone
                FROM usuario_do_sistema u
                INNER JOIN pessoa p
                    ON p.Id = u.Id
                WHERE u.Id = :Id
                LIMIT 1
            ");

            $stmt->execute([
                ":Id" => $id
            ]);

            $usuario = $stmt->fetch(PDO::FETCH_ASSOC);

            if (!$usuario) {

                $erro = "O usuário selecionado não existe.";

            } else {

                /*
                |--------------------------------------------------------------------------
                | VERIFICAR SE JÁ É ADMINISTRADOR
                |--------------------------------------------------------------------------
                */
                $stmt = $pdo->prepare("
                    SELECT Id
                    FROM administrador_do_sistema
                    WHERE Id = :Id
                    LIMIT 1
                ");

                $stmt->execute([
                    ":Id" => $id
                ]);

                $administradorExistente = $stmt->fetch(PDO::FETCH_ASSOC);


                /*
                |--------------------------------------------------------------------------
                | CADASTRAR
                |--------------------------------------------------------------------------
                */
                if ($acao === "cadastrar") {

                    if ($administradorExistente) {

                        $erro = "Este usuário já está cadastrado como administrador.";

                    } else {

                        $sql = "
                            INSERT INTO administrador_do_sistema
                            (
                                Id,
                                NivelAcesso
                            )
                            VALUES
                            (
                                :Id,
                                :NivelAcesso
                            )
                        ";

                        $stmt = $pdo->prepare($sql);

                        $stmt->execute([
                            ":Id" => $id,
                            ":NivelAcesso" => $nivelAcesso
                        ]);

                        header(
                            "Location: administrador_do_sistema.php?sucesso=1"
                        );

                        exit;
                    }
                }


                /*
                |--------------------------------------------------------------------------
                | EDITAR
                |--------------------------------------------------------------------------
                */
                if ($acao === "editar") {

                    if (!$administradorExistente) {

                        $erro = "Administrador não encontrado.";

                    } else {

                        $sql = "
                            UPDATE administrador_do_sistema
                            SET NivelAcesso = :NivelAcesso
                            WHERE Id = :Id
                        ";

                        $stmt = $pdo->prepare($sql);

                        $stmt->execute([
                            ":NivelAcesso" => $nivelAcesso,
                            ":Id" => $id
                        ]);

                        header(
                            "Location: administrador_do_sistema.php?editado=1"
                        );

                        exit;
                    }
                }
            }

        } catch (PDOException $e) {

            $erro = "Erro ao salvar administrador: " . $e->getMessage();
        }
    }
}


/*
|--------------------------------------------------------------------------
| EXCLUIR ADMINISTRADOR
|--------------------------------------------------------------------------
| Exclui somente o vínculo de administrador.
| O usuário continua existindo.
| A pessoa também continua existindo.
|--------------------------------------------------------------------------
*/
if (isset($_GET["excluir"])) {

    $id = (int)$_GET["excluir"];

    if ($id > 0) {

        try {

            $stmt = $pdo->prepare("
                DELETE FROM administrador_do_sistema
                WHERE Id = :Id
            ");

            $stmt->execute([
                ":Id" => $id
            ]);

            header(
                "Location: administrador_do_sistema.php?deletado=1"
            );

            exit;

        } catch (PDOException $e) {

            $erro = "Não foi possível excluir o administrador: "
                  . $e->getMessage();
        }
    }
}


/*
|--------------------------------------------------------------------------
| BUSCAR ADMINISTRADOR PARA EDIÇÃO
|--------------------------------------------------------------------------
*/
$administradorEdicao = null;

if (isset($_GET["editar"])) {

    $id = (int)$_GET["editar"];

    if ($id > 0) {

        $stmt = $pdo->prepare("
            SELECT
                a.Id,
                a.NivelAcesso,

                u.Login,
                u.Perfil,
                u.Status,
                u.Ativo,

                p.Nome,
                p.Cpf,
                p.Telefone,
                p.Endereco

            FROM administrador_do_sistema a

            INNER JOIN usuario_do_sistema u
                ON u.Id = a.Id

            INNER JOIN pessoa p
                ON p.Id = a.Id

            WHERE a.Id = :Id

            LIMIT 1
        ");

        $stmt->execute([
            ":Id" => $id
        ]);

        $administradorEdicao =
            $stmt->fetch(PDO::FETCH_ASSOC);
    }
}


/*
|--------------------------------------------------------------------------
| PESQUISA DE ADMINISTRADORES
|--------------------------------------------------------------------------
*/
$busca = trim($_GET["busca"] ?? "");

if ($busca !== "") {

    $stmt = $pdo->prepare("
        SELECT

            a.Id,
            a.NivelAcesso,

            p.Nome,
            p.Cpf,
            p.Telefone,

            u.Login,
            u.Perfil,
            u.Status,
            u.Ativo

        FROM administrador_do_sistema a

        INNER JOIN usuario_do_sistema u
            ON u.Id = a.Id

        INNER JOIN pessoa p
            ON p.Id = a.Id

        WHERE
            p.Nome LIKE :busca
            OR p.Cpf LIKE :busca
            OR p.Telefone LIKE :busca
            OR u.Login LIKE :busca

        ORDER BY p.Nome ASC
    ");

    $stmt->execute([
        ":busca" => "%$busca%"
    ]);

    $administradores =
        $stmt->fetchAll(PDO::FETCH_ASSOC);

} else {

    $stmt = $pdo->query("
        SELECT

            a.Id,
            a.NivelAcesso,

            p.Nome,
            p.Cpf,
            p.Telefone,

            u.Login,
            u.Perfil,
            u.Status,
            u.Ativo

        FROM administrador_do_sistema a

        INNER JOIN usuario_do_sistema u
            ON u.Id = a.Id

        INNER JOIN pessoa p
            ON p.Id = a.Id

        ORDER BY p.Nome ASC
    ");

    $administradores =
        $stmt->fetchAll(PDO::FETCH_ASSOC);
}


/*
|--------------------------------------------------------------------------
| USUÁRIOS DISPONÍVEIS PARA VIRAR ADMINISTRADORES
|--------------------------------------------------------------------------
| Somente usuários que ainda não são administradores.
|--------------------------------------------------------------------------
*/
$stmt = $pdo->query("
    SELECT

        u.Id,
        u.Login,
        u.Perfil,
        u.Status,
        u.Ativo,

        p.Nome,
        p.Cpf,
        p.Telefone

    FROM usuario_do_sistema u

    INNER JOIN pessoa p
        ON p.Id = u.Id

    LEFT JOIN administrador_do_sistema a
        ON a.Id = u.Id

    WHERE
        a.Id IS NULL

    ORDER BY p.Nome ASC
");

$usuariosDisponiveis =
    $stmt->fetchAll(PDO::FETCH_ASSOC);

?>
<!DOCTYPE html>
<html lang="pt-BR">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>
        Administradores do Sistema - Amar V
    </title>

    <link
        rel="stylesheet"
        href="css/estilo.css"
    >

    <style>

        .tabela-container {
            overflow-x: auto;
            margin-top: 20px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 10px;
        }

        th,
        td {
            padding: 12px 15px;
            text-align: left;
            border-bottom: 1px solid #e0e9eb;
        }

        th {
            background-color: #0b6e69;
            color: white;
            font-size: 14px;
        }

        tr:hover {
            background-color: #f5fbfa;
        }

        .form-grid {
            display: grid;
            grid-template-columns:
                repeat(auto-fit, minmax(200px, 1fr));

            gap: 15px;

            margin-bottom: 15px;
        }

        .form-grupo {
            display: flex;
            flex-direction: column;
            gap: 5px;
        }

        .form-grupo label {
            font-weight: bold;
            font-size: 13px;
            color: #193f40;
        }

        .form-grupo input,
        .form-grupo select {

            padding: 10px;

            border: 1px solid #c2d6d4;

            border-radius: 8px;

            font-size: 14px;

            background-color: white;
        }

        .btn-acao {

            display: inline-block;

            padding: 6px 12px;

            border-radius: 6px;

            text-decoration: none;

            font-size: 12px;

            font-weight: bold;

            color: white;

            border: none;

            cursor: pointer;
        }

        .btn-editar {
            background-color: #0b6e69;
        }

        .btn-excluir {
            background-color: #d9534f;
        }

        .btn-cancelar {

            background-color: #607d8b;

            color: white;

            padding: 10px 18px;

            border-radius: 8px;

            text-decoration: none;

            font-weight: bold;

            display: inline-block;
        }

        .btn-voltar {

            background-color: #607d8b;

            color: white;

            padding: 10px 18px;

            border-radius: 8px;

            text-decoration: none;

            font-weight: bold;

            display: inline-block;

            margin-bottom: 20px;
        }

        .alerta {

            padding: 12px 16px;

            border-radius: 8px;

            margin-bottom: 20px;

            font-weight: bold;
        }

        .alerta-sucesso {

            background-color: #e8f6eb;

            color: #28783a;

            border: 1px solid #c9e8ce;
        }

        .alerta-erro {

            background-color: #fde8e8;

            color: #c53030;

            border: 1px solid #f8b4b4;
        }

        .cabecalho-tabela {

            display: flex;

            justify-content: space-between;

            align-items: center;

            flex-wrap: wrap;

            gap: 10px;
        }

        .pesquisa-box {

            display: flex;

            gap: 10px;

            width: 100%;

            max-width: 400px;
        }

        .pesquisa-box input {

            flex: 1;

            padding: 8px 12px;

            border: 1px solid #c2d6d4;

            border-radius: 6px;

            font-size: 14px;
        }

        .acoes-col {

            white-space: nowrap;

            display: flex;

            gap: 6px;
        }

        .usuario-info {

            margin-top: 6px;

            font-size: 12px;

            color: #607d8b;
        }

    </style>

</head>


<body>


<header>

    <div class="logo">
        AMAR V
    </div>

    <div class="subtitulo">
        Gerenciamento de Administradores
    </div>

</header>


<main>


    <a
        href="index.php"
        class="btn-voltar"
    >
        ← Voltar ao Início
    </a>


    <?php if (isset($_GET["sucesso"])): ?>

        <div class="alerta alerta-sucesso">

            Administrador cadastrado com sucesso!

        </div>

    <?php endif; ?>


    <?php if (isset($_GET["editado"])): ?>

        <div class="alerta alerta-sucesso">

            Administrador atualizado com sucesso!

        </div>

    <?php endif; ?>


    <?php if (isset($_GET["deletado"])): ?>

        <div class="alerta alerta-sucesso">

            Administrador removido com sucesso!

        </div>

    <?php endif; ?>


    <?php if (!empty($erro)): ?>

        <div class="alerta alerta-erro">

            <?= htmlspecialchars($erro) ?>

        </div>

    <?php endif; ?>


    <!-- =========================================================
         CADASTRO
         ========================================================= -->

    <section class="card">


        <div class="titulo-secao">


            <div class="titulo-icone">
                🛡️
            </div>


            <div>

                <h2>

                    <?= $administradorEdicao

                        ? "Editar Administrador"

                        : "Cadastrar Novo Administrador"

                    ?>

                </h2>


                <p>

                    <?= $administradorEdicao

                        ? "Altere os dados do administrador."

                        : "Selecione um usuário existente para torná-lo administrador."

                    ?>

                </p>

            </div>

        </div>


        <form
            action="administrador_do_sistema.php"
            method="POST"
        >


            <input
                type="hidden"
                name="acao"
                value="<?=

                    $administradorEdicao

                    ? "editar"

                    : "cadastrar"

                ?>"
            >


            <div class="form-grid">


                <!-- USUÁRIO -->


                <div class="form-grupo">


                    <label>
                        Usuário *
                    </label>


                    <?php if ($administradorEdicao): ?>


                        <input
                            type="hidden"
                            name="Id"
                            value="<?=

                                (int)$administradorEdicao["Id"]

                            ?>"
                        >


                        <input
                            type="text"
                            value="<?=

                                htmlspecialchars(
                                    $administradorEdicao["Nome"]
                                )

                            ?>"
                            readonly
                        >


                        <div class="usuario-info">

                            Login:

                            <strong>
                                <?=

                                    htmlspecialchars(
                                        $administradorEdicao["Login"]
                                    )

                                ?>
                            </strong>

                            |

                            CPF:

                            <?=

                                htmlspecialchars(
                                    $administradorEdicao["Cpf"] ?? "-"
                                )

                            ?>

                        </div>


                    <?php else: ?>


                        <select
                            name="Id"
                            required
                        >


                            <option value="">

                                -- Selecione um usuário --

                            </option>


                            <?php foreach (
                                $usuariosDisponiveis
                                as $usuario
                            ): ?>


                                <option
                                    value="<?=

                                        (int)$usuario["Id"]

                                    ?>"
                                >

                                    <?=

                                        htmlspecialchars(
                                            $usuario["Nome"]
                                        )

                                    ?>

                                    -

                                    Login:

                                    <?=

                                        htmlspecialchars(
                                            $usuario["Login"]
                                        )

                                    ?>


                                </option>


                            <?php endforeach; ?>


                        </select>


                        <div class="usuario-info">

                            O usuário precisa estar previamente
                            cadastrado em

                            <strong>
                                usuario_sistema.php
                            </strong>.

                        </div>


                    <?php endif; ?>


                </div>


                <!-- NÍVEL DE ACESSO -->


                <div class="form-grupo">


                    <label>
                        Nível de Acesso *
                    </label>


                    <select
                        name="NivelAcesso"
                        required
                    >

                        <option
                            value="Administrador"
                            selected
                        >
                            Administrador
                        </option>

                    </select>


                </div>


            </div>


            <div
                style="
                    display:flex;
                    gap:10px;
                    align-items:center;
                "
            >


                <button
                    type="submit"
                    class="botao"
                >

                    <?= $administradorEdicao

                        ? "Atualizar Administrador"

                        : "Salvar Administrador"

                    ?>

                </button>


                <?php if ($administradorEdicao): ?>


                    <a
                        href="administrador_do_sistema.php"
                        class="btn-cancelar"
                    >
                        Cancelar
                    </a>


                <?php endif; ?>


            </div>


        </form>


    </section>


    <!-- =========================================================
         LISTA
         ========================================================= -->

    <section class="card">


        <div class="cabecalho-tabela">


            <div
                class="titulo-secao"
                style="margin-bottom:0;"
            >


                <div class="titulo-icone">
                    📋
                </div>


                <div>

                    <h2>
                        Administradores Cadastrados
                    </h2>

                    <p>
                        Usuários com permissão administrativa.
                    </p>

                </div>


            </div>


            <form
                method="GET"
                class="pesquisa-box"
            >


                <input
                    type="text"
                    name="busca"
                    placeholder="Pesquisar..."
                    value="<?=

                        htmlspecialchars($busca)

                    ?>"
                >


                <button
                    type="submit"
                    class="btn-acao btn-editar"
                >
                    Buscar
                </button>


                <?php if ($busca !== ""): ?>


                    <a
                        href="administrador_do_sistema.php"
                        class="btn-acao btn-cancelar"
                        style="padding:8px;"
                    >
                        Limpar
                    </a>


                <?php endif; ?>


            </form>


        </div>


        <div class="tabela-container">


            <table>


                <thead>

                    <tr>

                        <th>#</th>

                        <th>Nome</th>

                        <th>CPF</th>

                        <th>Login</th>

                        <th>Perfil</th>

                        <th>Nível</th>

                        <th>Status</th>

                        <th>Ações</th>

                    </tr>

                </thead>


                <tbody>


                    <?php if (
                        count($administradores) > 0
                    ): ?>


                        <?php $linha = 1; ?>


                        <?php foreach (
                            $administradores
                            as $admin
                        ): ?>


                            <tr>


                                <td>
                                    <?= $linha++ ?>
                                </td>


                                <td>

                                    <strong>

                                        <?=

                                            htmlspecialchars(
                                                $admin["Nome"]
                                            )

                                        ?>

                                    </strong>

                                </td>


                                <td>

                                    <?=

                                        htmlspecialchars(
                                            $admin["Cpf"] ?? "-"
                                        )

                                    ?>

                                </td>


                                <td>

                                    <?=

                                        htmlspecialchars(
                                            $admin["Login"]
                                        )

                                    ?>

                                </td>


                                <td>

                                    <?=

                                        htmlspecialchars(
                                            $admin["Perfil"] ?? "-"
                                        )

                                    ?>

                                </td>


                                <td>

                                    <?=

                                        htmlspecialchars(
                                            $admin["NivelAcesso"]
                                        )

                                    ?>

                                </td>


                                <td>

                                    <?=

                                        htmlspecialchars(
                                            $admin["Status"] ?? "-"
                                        )

                                    ?>

                                </td>


                                <td class="acoes-col">


                                    <a
                                        href="administrador_do_sistema.php?editar=<?=

                                            (int)$admin["Id"]

                                        ?>"
                                        class="btn-acao btn-editar"
                                    >
                                        Editar
                                    </a>


                                    <a
                                        href="administrador_do_sistema.php?excluir=<?=

                                            (int)$admin["Id"]

                                        ?>"
                                        class="btn-acao btn-excluir"
                                        onclick="return confirm('Deseja realmente remover este usuário dos administradores? O usuário continuará cadastrado no sistema.')"
                                    >
                                        Remover
                                    </a>


                                </td>


                            </tr>


                        <?php endforeach; ?>


                    <?php else: ?>


                        <tr>


                            <td
                                colspan="8"
                                style="
                                    text-align:center;
                                    color:#78909c;
                                "
                            >

                                Nenhum administrador encontrado.

                            </td>


                        </tr>


                    <?php endif; ?>


                </tbody>


            </table>


        </div>


    </section>


</main>


<footer>

    Amar V © <?= date("Y") ?>

</footer>


</body>

</html>