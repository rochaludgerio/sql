<?php
require_once "conexao.php";

$mensagem = "";

// --- PROCESSAR CADASTRO DE NOVA VACINA ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['acao']) && $_POST['acao'] === 'cadastrar') {
    $nome = trim($_POST['nome'] ?? '');
    $fabricante = trim($_POST['fabricante'] ?? '');
    $tipoVacina = trim($_POST['tipo_vacina'] ?? '');
    $quantidadeDoses = (int)($_POST['quantidade_doses'] ?? 0);
    $tipoCalendario = trim($_POST['tipo_calendario'] ?? '');

    if (!empty($nome)) {
        $stmt = $pdo->prepare("INSERT INTO vacina (Nome, Fabricante, TipoVacina, QuantidadeDoses, TipoCalendario) VALUES (?, ?, ?, ?, ?)");
        $stmt->execute([$nome, $fabricante ?: null, $tipoVacina ?: null, $quantidadeDoses, $tipoCalendario ?: null]);
        header("Location: vacina.php?sucesso=1");
        exit;
    } else {
        $mensagem = "O nome da vacina é obrigatório.";
    }
}

// --- PROCESSAR EXCLUSÃO DE VACINA ---
if (isset($_GET['excluir'])) {
    $idExcluir = (int)$_GET['excluir'];
    $stmt = $pdo->prepare("DELETE FROM vacina WHERE Id = ?");
    $stmt->execute([$idExcluir]);
    header("Location: vacina.php?deletado=1");
    exit;
}

// --- CONSULTA COM FILTRO DE BUSCA ---
$busca = trim($_GET['busca'] ?? '');
if (!empty($busca)) {
    $stmt = $pdo->prepare("SELECT * FROM vacina WHERE Nome LIKE ? OR TipoCalendario LIKE ? ORDER BY Id DESC");
    $stmt->execute(["%$busca%", "%$busca%"]);
    $vacinas = $stmt->fetchAll();
} else {
    $stmt = $pdo->query("SELECT * FROM vacina ORDER BY Id DESC");
    $vacinas = $stmt->fetchAll();
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Vacinas - Amar V</title>
    <link rel="stylesheet" href="css/estilo.css">
    <style>
        .tabela-container {
            overflow-x: auto;
            margin-top: 20px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 10px;
        }
        th, td {
            padding: 12px 15px;
            text-align: left;
            border-bottom: 1px solid #e0e9eb;
        }
        th {
            background-color: #0b6e69;
            color: white;
            font-size: 14px;
        }
        tr:hover {
            background-color: #f5fbfa;
        }
        .form-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
            margin-bottom: 15px;
        }
        .form-grupo {
            display: flex;
            flex-direction: column;
            gap: 5px;
        }
        .form-grupo label {
            font-weight: bold;
            font-size: 13px;
            color: #193f40;
        }
        .form-grupo input, .form-grupo select {
            padding: 10px;
            border: 1px solid #c2d6d4;
            border-radius: 8px;
            font-size: 14px;
        }
        .btn-acao {
            display: inline-block;
            padding: 6px 12px;
            border-radius: 6px;
            text-decoration: none;
            font-size: 12px;
            font-weight: bold;
            color: white;
            cursor: pointer;
            border: none;
        }
        .btn-editar { background-color: #0d8179; }
        .btn-excluir { background-color: #d9534f; }
        .btn-voltar {
            background-color: #607d8b;
            color: white;
            padding: 10px 18px;
            border-radius: 8px;
            text-decoration: none;
            font-weight: bold;
            display: inline-block;
            margin-bottom: 20px;
        }
        .alerta {
            padding: 12px 16px;
            border-radius: 8px;
            margin-bottom: 20px;
            font-weight: bold;
        }
        .alerta-sucesso { background-color: #e8f6eb; color: #28783a; border: 1px solid #c9e8ce; }
        .alerta-erro { background-color: #fde8e8; color: #c53030; border: 1px solid #f8b4b4; }
    </style>
</head>
<body>

<header>
    <div class="logo">AMAR V</div>
    <div class="subtitulo">Gestão do Cadastro de Vacinas</div>
</header>

<main>
    <a href="index.php" class="btn-voltar">← Voltar ao Inicio</a>

    <?php if (isset($_GET['sucesso'])): ?>
        <div class="alerta alerta-sucesso">Vacina cadastrada com sucesso!</div>
    <?php endif; ?>

    <?php if (isset($_GET['deletado'])): ?>
        <div class="alerta alerta-sucesso">Vacina excluída com sucesso!</div>
    <?php endif; ?>

    <?php if (!empty($mensagem)): ?>
        <div class="alerta alerta-erro"><?= htmlspecialchars($mensagem) ?></div>
    <?php endif; ?>

    <!-- NOVO CADASTRO -->
    <section class="card">
        <div class="titulo-secao">
            <div class="titulo-icone">💉</div>
            <div>
                <h2>Cadastrar Nova Vacina</h2>
                <p>Preencha os campos abaixo para registrar uma nova vacina no banco de dados.</p>
            </div>
        </div>

        <form action="vacina.php" method="POST">
            <input type="hidden" name="acao" value="cadastrar">
            
            <div class="form-grid">
                <div class="form-grupo">
                    <label>Nome da Vacina *</label>
                    <input type="text" name="nome" required placeholder="Ex: Tríplice Viral">
                </div>

                <div class="form-grupo">
                    <label>Fabricante</label>
                    <input type="text" name="fabricante" placeholder="Ex: Fiocruz">
                </div>

                <div class="form-grupo">
                    <label>Tipo de Vacina</label>
                    <input type="text" name="tipo_vacina" placeholder="Ex: Viral Atenuada">
                </div>

                <div class="form-grupo">
                    <label>Quantidade de Doses</label>
                    <input type="number" name="quantidade_doses" value="0" min="0">
                </div>

                <div class="form-grupo">
                    <label>Tipo de Calendário</label>
                    <select name="tipo_calendario">
                        <option value="SUS">SUS</option>
                        <option value="Privado">Privado</option>
                    </select>
                </div>
            </div>

            <button type="submit" class="botao">Salvar Vacina</button>
        </form>
    </section>

    <!-- LISTAGEM -->
    <section class="card">
        <div class="titulo-secao">
            <div class="titulo-icone">📋</div>
            <div>
                <h2>Vacinas Cadastradas</h2>
                <p>Lista total de vacinas disponíveis na base de dados.</p>
            </div>
        </div>

        <form method="GET" action="vacina.php" style="margin-bottom: 20px;">
            <div style="display: flex; gap: 10px;">
                <input type="text" name="busca" value="<?= htmlspecialchars($busca) ?>" placeholder="Buscar vacina por nome ou tipo..." style="flex: 1; padding: 10px; border-radius: 8px; border: 1px solid #c2d6d4;">
                <button type="submit" class="botao" style="margin-top: 0;">Buscar</button>
            </div>
        </form>

        <div class="tabela-container">
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Nome</th>
                        <th>Fabricante</th>
                        <th>Tipo</th>
                        <th>Doses</th>
                        <th>Calendário</th>
                        <th>Ações</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (count($vacinas) > 0): ?>
                        <?php foreach ($vacinas as $vacina): ?>
                            <tr>
                                <td><?= $vacina['Id'] ?></td>
                                <td><strong><?= htmlspecialchars($vacina['Nome']) ?></strong></td>
                                <td><?= htmlspecialchars($vacina['Fabricante'] ?? '-') ?></td>
                                <td><?= htmlspecialchars($vacina['TipoVacina'] ?? '-') ?></td>
                                <td><?= $vacina['QuantidadeDoses'] ?></td>
                                <td>
                                    <span style="padding: 4px 8px; border-radius: 4px; font-weight: bold; background-color: <?= $vacina['TipoCalendario'] === 'SUS' ? '#e8f6eb' : '#eaf5f4' ?>; color: <?= $vacina['TipoCalendario'] === 'SUS' ? '#28783a' : '#0b6e69' ?>;">
                                        <?= htmlspecialchars($vacina['TipoCalendario'] ?? 'N/A') ?>
                                    </span>
                                </td>
                                <td>
                                    <a href="vacina_editar.php?id=<?= $vacina['Id'] ?>" class="btn-acao btn-editar">Editar</a>
                                    <a href="vacina.php?excluir=<?= $vacina['Id'] ?>" class="btn-acao btn-excluir" onclick="return confirm('Deseja realmente excluir esta vacina?')">Excluir</a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="7" style="text-align: center; color: #78909c;">Nenhuma vacina encontrada.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </section>
</main>

<footer>
    Amar V © <?= date("Y") ?>
</footer>

</body>
</html>