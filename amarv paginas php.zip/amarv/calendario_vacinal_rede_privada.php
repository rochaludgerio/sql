<?php

require_once "conexao.php";

$mensagem = "";
$erro = "";


/* =========================================================
   EXCLUIR
   ========================================================= */

if (isset($_GET["excluir"])) {

    $id = (int) $_GET["excluir"];

    try {

        $stmt = $pdo->prepare(
            "DELETE FROM calendario_vacinal_rede_privada WHERE Id = ?"
        );

        $stmt->execute([$id]);

        header(
            "Location: calendario_vacinal_rede_privada.php?sucesso=excluido"
        );

        exit;

    } catch (PDOException $e) {

        $erro = "Não foi possível excluir o calendário da rede privada: "
              . $e->getMessage();
    }
}


/* =========================================================
   EDITAR
   ========================================================= */

$calendarioEditar = null;

if (isset($_GET["editar"])) {

    $id = (int) $_GET["editar"];

    $stmt = $pdo->prepare(
        "SELECT * FROM calendario_vacinal_rede_privada WHERE Id = ?"
    );

    $stmt->execute([$id]);

    $calendarioEditar = $stmt->fetch();

    if (!$calendarioEditar) {

        $erro = "Calendário da rede privada não encontrado.";
    }
}


/* =========================================================
   SALVAR
   ========================================================= */

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $id = !empty($_POST["Id"])
        ? (int) $_POST["Id"]
        : null;

    $Nome = trim($_POST["Nome"] ?? "");

    $Descricao = trim($_POST["Descricao"] ?? "");


    if ($Nome === "") {

        $erro = "Informe o nome do calendário da rede privada.";

    } else {

        try {

            if ($id) {

                $stmt = $pdo->prepare("
                    UPDATE calendario_vacinal_rede_privada
                    SET
                        Nome = ?,
                        Descricao = ?
                    WHERE Id = ?
                ");

                $stmt->execute([
                    $Nome,
                    $Descricao !== "" ? $Descricao : null,
                    $id
                ]);

                header(
                    "Location: calendario_vacinal_rede_privada.php?sucesso=alterado"
                );

                exit;

            } else {

                $stmt = $pdo->prepare("
                    INSERT INTO calendario_vacinal_rede_privada
                    (
                        Nome,
                        Descricao
                    )
                    VALUES
                    (
                        ?,
                        ?
                    )
                ");

                $stmt->execute([
                    $Nome,
                    $Descricao !== "" ? $Descricao : null
                ]);

                header(
                    "Location: calendario_vacinal_rede_privada.php?sucesso=cadastrado"
                );

                exit;
            }

        } catch (PDOException $e) {

            $erro = "Erro ao salvar o calendário da rede privada: "
                  . $e->getMessage();
        }
    }
}


/* =========================================================
   MENSAGENS
   ========================================================= */

if (isset($_GET["sucesso"])) {

    switch ($_GET["sucesso"]) {

        case "cadastrado":
            $mensagem = "Calendário da rede privada cadastrado com sucesso.";
            break;

        case "alterado":
            $mensagem = "Calendário da rede privada alterado com sucesso.";
            break;

        case "excluido":
            $mensagem = "Calendário da rede privada excluído com sucesso.";
            break;
    }
}


/* =========================================================
   LISTAR
   ========================================================= */

$stmt = $pdo->query("
    SELECT
        Id,
        Nome,
        Descricao
    FROM calendario_vacinal_rede_privada
    ORDER BY Nome ASC
");

$calendarios = $stmt->fetchAll();

?>
<!DOCTYPE html>

<html lang="pt-BR">

<head>

    <meta charset="UTF-8">

    <meta name="viewport"
          content="width=device-width, initial-scale=1.0">

    <title>Amar V - Rede Privada</title>

    <link rel="stylesheet"
          href="css/estilo.css">

    <style>

        .formulario {
            display: grid;
            grid-template-columns: 1fr;
            gap: 15px;
        }

        .campo {
            display: flex;
            flex-direction: column;
        }

        .campo label {
            font-weight: bold;
            margin-bottom: 6px;
        }

        .campo input,
        .campo textarea {
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 6px;
            font-size: 14px;
            width: 100%;
            box-sizing: border-box;
        }

        .campo textarea {
            min-height: 120px;
            resize: vertical;
        }

        .botoes {
            display: flex;
            gap: 10px;
            margin-top: 10px;
        }

        .botao-form {
            padding: 11px 20px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            text-decoration: none;
            display: inline-block;
        }

        .botao-salvar {
            background: #0B3C49;
            color: white;
        }

        .botao-cancelar {
            background: #777;
            color: white;
        }

        .tabela-container {
            overflow-x: auto;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 15px;
        }

        th,
        td {
            padding: 10px;
            border-bottom: 1px solid #ddd;
            text-align: left;
            vertical-align: top;
        }

        th {
            background: #0B3C49;
            color: white;
        }

        .acoes {
            white-space: nowrap;
        }

        .botao-editar {
            background: #4fb3bf;
            color: white;
            padding: 7px 10px;
            border-radius: 5px;
            text-decoration: none;
        }

        .botao-excluir {
            background: #b33a3a;
            color: white;
            padding: 7px 10px;
            border-radius: 5px;
            text-decoration: none;
        }

        .mensagem {
            padding: 12px;
            margin-bottom: 15px;
            border-radius: 6px;
            background: #dff0d8;
            color: #245b2a;
        }

        .erro {
            padding: 12px;
            margin-bottom: 15px;
            border-radius: 6px;
            background: #f8d7da;
            color: #842029;
        }

        .descricao {
            max-width: 600px;
            white-space: pre-wrap;
        }

    </style>

</head>

<body>


<header>

    <div class="logo">
        AMAR V
    </div>

    <div class="subtitulo">
        Servidor de Sincronização e Administração
    </div>

</header>


<main>


    <section class="card destaque">

        <h1>
            🏢 Calendário Vacinal - Rede Privada
        </h1>

        <p>
            Cadastro e gerenciamento das informações
            de vacinação da rede privada.
        </p>

    </section>


    <?php if ($mensagem): ?>

        <div class="mensagem">
            <?= htmlspecialchars($mensagem) ?>
        </div>

    <?php endif; ?>


    <?php if ($erro): ?>

        <div class="erro">
            <?= htmlspecialchars($erro) ?>
        </div>

    <?php endif; ?>


    <section class="card">

        <h2>

            <?= $calendarioEditar
                ? "✏️ Editar Calendário da Rede Privada"
                : "➕ Novo Calendário da Rede Privada"
            ?>

        </h2>


        <form method="POST"
              class="formulario">


            <input
                type="hidden"
                name="Id"
                value="<?= htmlspecialchars(
                    $calendarioEditar["Id"] ?? ""
                ) ?>"
            >


            <div class="campo">

                <label>
                    Nome do Calendário *
                </label>

                <input
                    type="text"
                    name="Nome"
                    required
                    maxlength="255"
                    value="<?= htmlspecialchars(
                        $calendarioEditar["Nome"] ?? ""
                    ) ?>"
                >

            </div>


            <div class="campo">

                <label>
                    Descrição
                </label>

                <textarea
                    name="Descricao"
                    placeholder="Informe a descrição do calendário da rede privada..."
                ><?= htmlspecialchars(
                    $calendarioEditar["Descricao"] ?? ""
                ) ?></textarea>

            </div>


            <div class="botoes">

                <button
                    type="submit"
                    class="botao-form botao-salvar"
                >

                    <?= $calendarioEditar
                        ? "Salvar Alterações"
                        : "Cadastrar Calendário"
                    ?>

                </button>


                <?php if ($calendarioEditar): ?>

                    <a
                        href="calendario_vacinal_rede_privada.php"
                        class="botao-form botao-cancelar"
                    >

                        Cancelar

                    </a>

                <?php endif; ?>

            </div>


        </form>

    </section>


    <section class="card">

        <h2>
            📋 Calendários da Rede Privada
        </h2>


        <div class="tabela-container">

            <table>

                <thead>

                    <tr>

                        <th>ID</th>
                        <th>Nome</th>
                        <th>Descrição</th>
                        <th>Ações</th>

                    </tr>

                </thead>


                <tbody>

                <?php if (count($calendarios) > 0): ?>

                    <?php foreach ($calendarios as $calendario): ?>

                        <tr>

                            <td>
                                <?= htmlspecialchars(
                                    $calendario["Id"]
                                ) ?>
                            </td>

                            <td>

                                <strong>
                                    <?= htmlspecialchars(
                                        $calendario["Nome"]
                                    ) ?>
                                </strong>

                            </td>

                            <td class="descricao">

                                <?= htmlspecialchars(
                                    $calendario["Descricao"] ?? ""
                                ) ?>

                            </td>

                            <td class="acoes">

                                <a
                                    href="calendario_vacinal_rede_privada.php?editar=<?= urlencode(
                                        $calendario["Id"]
                                    ) ?>"
                                    class="botao-editar"
                                >
                                    Editar
                                </a>


                                <a
                                    href="calendario_vacinal_rede_privada.php?excluir=<?= urlencode(
                                        $calendario["Id"]
                                    ) ?>"
                                    class="botao-excluir"
                                    onclick="return confirm('Tem certeza que deseja excluir este calendário da rede privada?');"
                                >
                                    Excluir
                                </a>

                            </td>

                        </tr>

                    <?php endforeach; ?>

                <?php else: ?>

                    <tr>

                        <td colspan="4">
                            Nenhum calendário da rede privada cadastrado.
                        </td>

                    </tr>

                <?php endif; ?>

                </tbody>

            </table>

        </div>

    </section>


    <section class="card">

        <a
            href="index.php"
            class="botao-form botao-cancelar"
        >
            ← Voltar ao painel
        </a>

    </section>


</main>


<footer>

    Amar V © <?= date("Y") ?>

</footer>


</body>

</html>