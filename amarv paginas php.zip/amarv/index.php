<?php

date_default_timezone_set('America/Sao_Paulo');

$pasta = "C:/Users/jesui/Downloads/AmarV/";

$arquivos = [];

if (is_dir($pasta)) {
    $arquivos = glob($pasta . "*.json");
}

$totalArquivos = count($arquivos);

$ultimaSincronizacao = "Nenhuma sincronização realizada";

if ($totalArquivos > 0) {

    usort($arquivos, function ($a, $b) {
        return filemtime($b) - filemtime($a);
    });

    $ultimaSincronizacao =
        date("d/m/Y H:i:s", filemtime($arquivos[0]));
}

?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Amar V - Servidor</title>
    <link rel="stylesheet" href="css/estilo.css">
</head>
<body>

<!-- ================================================= -->
<!-- CABEÇALHO -->
<!-- ================================================= -->

<header>

    <div class="logo">
        AMAR V
    </div>

    <div class="subtitulo">
        Servidor de Sincronização e Administração
    </div>

</header>


<!-- ================================================= -->
<!-- CONTEÚDO PRINCIPAL -->
<!-- ================================================= -->

<main>


    <!-- ================================================= -->
    <!-- STATUS DO SERVIDOR -->
    <!-- ================================================= -->

    <section class="card destaque">

        <h1>
            Servidor Amar V
        </h1>

        <p>
            Sistema de Apoio à Regularização Vacinal
        </p>

        <div class="status">

            <span class="bolinha"></span>

            <strong>
                SERVIDOR ONLINE
            </strong>

        </div>

    </section>



    <!-- ================================================= -->
    <!-- INFORMAÇÕES -->
    <!-- ================================================= -->

    <section class="cards">


        <div class="card pequeno">

            <div class="icone-info">
                📂
            </div>

            <h2>
                Arquivos recebidos
            </h2>

            <div class="numero">
                <?= $totalArquivos ?>
            </div>

        </div>



        <div class="card pequeno">

            <div class="icone-info">
                🔄
            </div>

            <h2>
                Última sincronização
            </h2>

            <div class="data">
                <?= $ultimaSincronizacao ?>
            </div>

        </div>


    </section>



    <!-- ================================================= -->
    <!-- CADASTROS -->
    <!-- ================================================= -->

    <section class="card">

        <div class="titulo-secao">

            <div class="titulo-icone">
                📋
            </div>

            <div>

                <h2>
                    Cadastros
                </h2>

                <p>
                    Cadastre e gerencie as informações
                    utilizadas pelo sistema Amar V.
                </p>

            </div>

        </div>



        <div class="menu-cadastros">


            <!-- PESSOA -->

            <a href="pessoa.php"
               class="item-menu">

                <div class="item-icone">
                    👤
                </div>

                <div class="item-texto">

                    <strong>
                        Pessoas
                    </strong>

                    <span>
                        Cadastro de pessoas
                    </span>

                </div>

            </a>



            <!-- PACIENTE -->

            <a href="paciente.php"
               class="item-menu">

                <div class="item-icone">
                    🧑‍⚕️
                </div>

                <div class="item-texto">

                    <strong>
                        Pacientes
                    </strong>

                    <span>
                        Cadastro de pacientes
                    </span>

                </div>

            </a>



            <!-- CONDIÇÃO CLÍNICA -->

            <a href="condicao_clinica.php"
               class="item-menu">

                <div class="item-icone">
                    🩺
                </div>

                <div class="item-texto">

                    <strong>
                        Condições Clínicas
                    </strong>

                    <span>
                        Condições de saúde
                    </span>

                </div>

            </a>



            <!-- VACINA -->

            <a href="vacina.php"
               class="item-menu">

                <div class="item-icone">
                    💉
                </div>

                <div class="item-texto">

                    <strong>
                        Vacinas
                    </strong>

                    <span>
                        Cadastro de vacinas
                    </span>

                </div>

            </a>



            <!-- DOSE -->

            <a href="dose.php"
               class="item-menu">

                <div class="item-icone">
                    💊
                </div>

                <div class="item-texto">

                    <strong>
                        Doses
                    </strong>

                    <span>
                        Doses das vacinas
                    </span>

                </div>

            </a>



            <!-- REGRA VACINAL -->

            <a href="regra_vacinal.php"
               class="item-menu">

                <div class="item-icone">
                    📋
                </div>

                <div class="item-texto">

                    <strong>
                        Regras Vacinais
                    </strong>

                    <span>
                        Regras por idade e calendário
                    </span>

                </div>

            </a>



            <!-- CALENDÁRIO VACINAL -->

            <a href="calendario_vacinal.php"
               class="item-menu">

                <div class="item-icone">
                    📅
                </div>

                <div class="item-texto">

                    <strong>
                        Calendário Vacinal
                    </strong>

                    <span>
                        Calendário geral
                    </span>

                </div>

            </a>



            <!-- CALENDÁRIO SUS -->

            <a href="calendario_vacinal_sus.php"
               class="item-menu">

                <div class="item-icone">
                    🏥
                </div>

                <div class="item-texto">

                    <strong>
                        Calendário SUS
                    </strong>

                    <span>
                        Vacinação pelo SUS
                    </span>

                </div>

            </a>



            <!-- REDE PRIVADA -->

            <a href="calendario_vacinal_rede_privada.php"
               class="item-menu">

                <div class="item-icone">
                    🏢
                </div>

                <div class="item-texto">

                    <strong>
                        Rede Privada
                    </strong>

                    <span>
                        Calendário particular
                    </span>

                </div>

            </a>



            <!-- HISTÓRICO -->

            <a href="historico_vacinal.php"
               class="item-menu">

                <div class="item-icone">
                    📖
                </div>

                <div class="item-texto">

                    <strong>
                        Histórico Vacinal
                    </strong>

                    <span>
                        Histórico de vacinação
                    </span>

                </div>

            </a>

            
            <!-- USUÁRIO DO SISTEMA -->

            <a href="usuario_do_sistema.php"
               class="item-menu">

                <div class="item-icone">
                    👨‍💼
                </div>

                <div class="item-texto">

                    <strong>
                        Usuários
                    </strong>

                    <span>
                        Cadastro de usuários
                    </span>

                </div>

            </a>



            <!-- ADMINISTRADOR -->

            <a href="administrador_do_sistema.php"
               class="item-menu">

                <div class="item-icone">
                    🔐
                </div>

                <div class="item-texto">

                    <strong>
                        Administradores
                    </strong>

                    <span>
                        Administração do sistema
                    </span>

                </div>

            </a>


        </div>

    </section>



    <!-- ================================================= -->
    <!-- GERENCIAMENTO DE DADOS -->
    <!-- ================================================= -->

    <section class="card">

        <div class="titulo-secao">

            <div class="titulo-icone">
                🔄
            </div>

            <div>

                <h2>
                    Gerenciamento de Dados
                </h2>

                <p>
                    Sincronização, backup e restauração
                    dos dados do Amar V.
                </p>

            </div>

        </div>



        <div class="menu-dados">


            <!-- ================================================= -->
            <!-- SINCRONIZAÇÃO -->
            <!-- ================================================= -->

            <a href="sincronizacao.php"
               class="opcao-dados">

                <div class="icone-dados">
                    🔄
                </div>

                <h3>
                    Sincronização
                </h3>

                <p>
                    Envie ou recupere os dados entre
                    o aplicativo e o servidor.
                </p>

                <span class="botao">
                    Acessar
                </span>

            </a>



            <!-- ================================================= -->
            <!-- BACKUP -->
            <!-- ================================================= -->

            <a href="backup.php"
               class="opcao-dados">

                <div class="icone-dados">
                    💾
                </div>

                <h3>
                    Backup e Restauração
                </h3>

                <p>
                    Faça cópias de segurança e restaure
                    os dados quando necessário.
                </p>

                <span class="botao">
                    Gerenciar
                </span>

            </a>



            <!-- ================================================= -->
            <!-- ARQUIVOS -->
            <!-- ================================================= -->

            <a href="arquivos.php"
               class="opcao-dados">

                <div class="icone-dados">
                    📂
                </div>

                <h3>
                    Arquivos Recebidos
                </h3>

                <p>
                    Consulte os arquivos enviados pelo
                    aplicativo Amar V.
                </p>

                <span class="botao">
                    Ver arquivos
                </span>

            </a>


        </div>

    </section>



    <!-- ================================================= -->
    <!-- SOBRE -->
    <!-- ================================================= -->

    <section class="card">

        <h2>
            ℹ️ Sobre o servidor
        </h2>

        <p>
            Este servidor recebe os dados enviados
            pelo aplicativo Amar V durante a
            sincronização manual.
        </p>

        <p>
            Os arquivos recebidos são armazenados
            automaticamente na pasta de Downloads
            do computador.
        </p>

        <p>
            Os cadastros realizados neste painel
            poderão ser armazenados diretamente
            no banco de dados MySQL do Amar V.
        </p>

    </section>


</main>



<!-- ================================================= -->
<!-- RODAPÉ -->
<!-- ================================================= -->

<footer>

    Amar V © <?= date("Y") ?>

</footer>


</body>
</html>