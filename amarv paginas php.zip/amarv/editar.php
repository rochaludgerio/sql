<?php

date_default_timezone_set('America/Sao_Paulo');

$pasta = "C:/Users/jesui/Downloads/AmarV/";

// =====================================================
// SENHA PARA EDITAR
// =====================================================

$senhaCorreta = "123456";


// =====================================================
// VERIFICAR ARQUIVO
// =====================================================

if (!isset($_GET['arquivo'])) {

    die("Arquivo não informado.");
}

$nomeArquivo = basename($_GET['arquivo']);

$caminhoArquivo = $pasta . $nomeArquivo;


// =====================================================
// VERIFICAR SE O ARQUIVO EXISTE
// =====================================================

if (!file_exists($caminhoArquivo)) {

    die("Arquivo não encontrado.");
}


// =====================================================
// VARIÁVEIS
// =====================================================

$erro = "";
$sucesso = "";


// =====================================================
// VERIFICAR SENHA
// =====================================================

$autorizado = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    if (isset($_POST['senha'])) {

        if ($_POST['senha'] === $senhaCorreta) {

            $autorizado = true;

        } else {

            $erro = "Senha incorreta.";
        }
    }
}


// =====================================================
// SALVAR ALTERAÇÃO
// =====================================================

if (
    $_SERVER['REQUEST_METHOD'] === 'POST' &&
    isset($_POST['salvar']) &&
    isset($_POST['conteudo'])
) {

    if ($_POST['senha'] === $senhaCorreta) {

        $conteudo = $_POST['conteudo'];

        // Verificar se o conteúdo continua sendo JSON válido

        json_decode($conteudo);

        if (json_last_error() !== JSON_ERROR_NONE) {

            $erro =
                "O conteúdo não é um JSON válido. " .
                "Corrija antes de salvar.";

            $autorizado = true;

        } else {

            if (
                file_put_contents(
                    $caminhoArquivo,
                    $conteudo
                ) !== false
            ) {

                $sucesso =
                    "Arquivo salvo com sucesso.";

                $autorizado = true;

            } else {

                $erro =
                    "Não foi possível salvar o arquivo.";

                $autorizado = true;
            }
        }
    }
}


// =====================================================
// LER ARQUIVO
// =====================================================

$conteudoArquivo = "";

if ($autorizado) {

    $conteudoArquivo =
        file_get_contents($caminhoArquivo);
}

?>

<!DOCTYPE html>
<html lang="pt-BR">

<head>

    <meta charset="UTF-8">

    <meta name="viewport"
          content="width=device-width, initial-scale=1.0">

    <title>Amar V - Editar Backup</title>

    <link rel="stylesheet"
          href="css/estilo.css">

    <style>

        .editor {

            width: 100%;

            min-height: 500px;

            font-family: Consolas, monospace;

            font-size: 14px;

            padding: 15px;

            border: 1px solid #ccc;

            border-radius: 8px;

            box-sizing: border-box;

            resize: vertical;

        }

        .senha {

            width: 100%;

            max-width: 400px;

            padding: 12px;

            font-size: 18px;

            margin-bottom: 15px;

            box-sizing: border-box;

        }

        .mensagem {

            padding: 12px;

            margin-bottom: 15px;

            border-radius: 6px;

        }

        .erro {

            background-color: #ffdede;

            color: #a00000;

        }

        .sucesso {

            background-color: #defade;

            color: #006600;

        }

    </style>

</head>


<body>


<header>

    <div class="logo">
        AMAR V
    </div>

    <div class="subtitulo">
        Editar Backup
    </div>

</header>


<main>

    <section class="card">

        <h1>
            Editar arquivo
        </h1>

        <p>
            <?= htmlspecialchars($nomeArquivo) ?>
        </p>


        <?php if ($erro != ""): ?>

            <div class="mensagem erro">

                <?= htmlspecialchars($erro) ?>

            </div>

        <?php endif; ?>


        <?php if ($sucesso != ""): ?>

            <div class="mensagem sucesso">

                <?= htmlspecialchars($sucesso) ?>

            </div>

        <?php endif; ?>


        <?php if (!$autorizado): ?>


            <!-- =========================================
                 TELA DE SENHA
                 ========================================= -->

            <form method="POST">

                <h2>
                    🔐 Digite a senha
                </h2>

                <p>
                    É necessário informar a senha
                    para editar este backup.
                </p>

                <input
                    type="password"
                    name="senha"
                    class="senha"
                    placeholder="Digite a senha"
                    required
                >

                <br>

                <button
                    type="submit"
                    class="botao"
                >
                    Entrar
                </button>

            </form>


        <?php else: ?>


            <!-- =========================================
                 EDITOR
                 ========================================= -->

            <h2>
                Conteúdo do backup
            </h2>

            <p>
                Faça as alterações necessárias
                e clique em Salvar.
            </p>


            <form method="POST">

                <input
                    type="hidden"
                    name="senha"
                    value="<?= htmlspecialchars($_POST['senha']) ?>"
                >

                <textarea
                    name="conteudo"
                    class="editor"
                    required
                ><?= htmlspecialchars($conteudoArquivo) ?></textarea>


                <br><br>


                <button
                    type="submit"
                    name="salvar"
                    value="1"
                    class="botao"
                >
                    💾 Salvar alterações
                </button>


                <a
                    href="arquivos.php"
                    class="botao"
                >
                    Voltar
                </a>

            </form>


        <?php endif; ?>

    </section>

</main>


<footer>

    Amar V © <?= date("Y") ?>

</footer>


</body>

</html>

