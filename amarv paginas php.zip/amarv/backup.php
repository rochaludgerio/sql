<?php
require_once "conexao.php";

$mensagem = "";
$erro = "";

/* =========================
   EXCLUIR BACKUP
========================= */
if (isset($_GET["excluir"])) {

    $id = (int) $_GET["excluir"];

    try {

        $stmt = $pdo->prepare("
            SELECT LocalArquivo
            FROM backup
            WHERE Id = ?
        ");

        $stmt->execute([$id]);
        $backup = $stmt->fetch();

        /*
         * Remove o registro do banco.
         *
         * O arquivo físico não é apagado automaticamente,
         * evitando apagar um backup que ainda possa ser
         * utilizado pelo sistema.
         */
        $stmt = $pdo->prepare("
            DELETE FROM backup
            WHERE Id = ?
        ");

        $stmt->execute([$id]);

        header("Location: backup.php?sucesso=excluido");
        exit;

    } catch (PDOException $e) {

        $erro = "Erro ao excluir o backup: " . $e->getMessage();
    }
}


/* =========================
   EDITAR BACKUP
========================= */
$backupEditar = null;

if (isset($_GET["editar"])) {

    $id = (int) $_GET["editar"];

    try {

        $stmt = $pdo->prepare("
            SELECT
                Id,
                DataBackup,
                Status,
                LocalArquivo
            FROM backup
            WHERE Id = ?
        ");

        $stmt->execute([$id]);

        $backupEditar = $stmt->fetch();

        if (!$backupEditar) {
            $erro = "Backup não encontrado.";
        }

    } catch (PDOException $e) {

        $erro = "Erro ao carregar o backup: " . $e->getMessage();
    }
}


/* =========================
   SALVAR
========================= */
if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $id = isset($_POST["Id"])
        ? (int) $_POST["Id"]
        : 0;

    $dataBackup = trim(
        $_POST["DataBackup"] ?? ""
    );

    $status = trim(
        $_POST["Status"] ?? ""
    );

    $localArquivo = trim(
        $_POST["LocalArquivo"] ?? ""
    );


    if ($status === "") {

        $erro = "Informe o status do backup.";

    } else {

        try {

            /*
             * EDITAR
             */
            if ($id > 0) {

                $stmt = $pdo->prepare("
                    UPDATE backup
                    SET
                        DataBackup = ?,
                        Status = ?,
                        LocalArquivo = ?
                    WHERE Id = ?
                ");

                $stmt->execute([
                    $dataBackup !== ""
                        ? $dataBackup
                        : null,

                    $status,

                    $localArquivo !== ""
                        ? $localArquivo
                        : null,

                    $id
                ]);

                header(
                    "Location: backup.php?sucesso=alterado"
                );

                exit;

            }


            /*
             * NOVO BACKUP
             */
            if ($dataBackup === "") {

                $dataBackup = date(
                    "Y-m-d H:i:s"
                );
            }


            $stmt = $pdo->prepare("
                INSERT INTO backup
                (
                    DataBackup,
                    Status,
                    LocalArquivo
                )
                VALUES (?, ?, ?)
            ");

            $stmt->execute([
                $dataBackup,
                $status,
                $localArquivo !== ""
                    ? $localArquivo
                    : null
            ]);


            header(
                "Location: backup.php?sucesso=incluido"
            );

            exit;

        } catch (PDOException $e) {

            $erro =
                "Erro ao salvar o backup: "
                . $e->getMessage();
        }
    }
}


/* =========================
   MENSAGENS
========================= */
if (isset($_GET["sucesso"])) {

    switch ($_GET["sucesso"]) {

        case "incluido":

            $mensagem =
                "Backup registrado com sucesso.";

            break;

        case "alterado":

            $mensagem =
                "Backup alterado com sucesso.";

            break;

        case "excluido":

            $mensagem =
                "Backup excluído com sucesso.";

            break;
    }
}


/* =========================
   LISTAR BACKUPS
========================= */
try {

    $stmt = $pdo->query("
        SELECT
            Id,
            DataBackup,
            Status,
            LocalArquivo
        FROM backup
        ORDER BY DataBackup DESC, Id DESC
    ");

    $backups = $stmt->fetchAll();

} catch (PDOException $e) {

    $backups = [];

    $erro =
        "Erro ao carregar os backups: "
        . $e->getMessage();
}

?>
<!DOCTYPE html>

<html lang="pt-BR">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>Backup - Amar V</title>

    <link
        rel="stylesheet"
        href="css/estilo.css"
    >

    <style>

        .formulario {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 15px;
        }

        .campo {
            display: flex;
            flex-direction: column;
        }

        .campo label {
            font-weight: bold;
            margin-bottom: 6px;
        }

        .campo input,
        .campo select {
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 6px;
            font-size: 15px;
        }

        .campo-completo {
            grid-column: 1 / -1;
        }

        .botoes {
            margin-top: 20px;
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
        }

        .btn {
            display: inline-block;
            padding: 10px 16px;
            border: none;
            border-radius: 6px;
            text-decoration: none;
            cursor: pointer;
            font-size: 14px;
            font-weight: bold;
        }

        .btn-salvar {
            background: #0B3C49;
            color: white;
        }

        .btn-salvar:hover {
            background: #082f39;
        }

        .btn-voltar {
            background: #777;
            color: white;
        }

        .btn-voltar:hover {
            background: #555;
        }

        .btn-editar {
            background: #4fb3bf;
            color: white;
        }

        .btn-excluir {
            background: #c0392b;
            color: white;
        }

        .mensagem {
            background: #d4edda;
            color: #155724;
            padding: 12px;
            border-radius: 6px;
            margin-bottom: 15px;
        }

        .erro {
            background: #f8d7da;
            color: #721c24;
            padding: 12px;
            border-radius: 6px;
            margin-bottom: 15px;
        }

        .tabela-container {
            overflow-x: auto;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 15px;
        }

        table th {
            background: #0B3C49;
            color: white;
            padding: 12px;
            text-align: left;
        }

        table td {
            padding: 10px;
            border-bottom: 1px solid #ddd;
        }

        table tr:hover {
            background: #f5f5f5;
        }

        .acoes {
            display: flex;
            gap: 6px;
            flex-wrap: wrap;
        }

        .status-sucesso {
            color: #198754;
            font-weight: bold;
        }

        .status-erro {
            color: #dc3545;
            font-weight: bold;
        }

        .status-outro {
            color: #856404;
            font-weight: bold;
        }

        .arquivo {
            word-break: break-all;
            max-width: 350px;
        }

        @media (max-width: 700px) {

            .formulario {
                grid-template-columns: 1fr;
            }

            .campo-completo {
                grid-column: auto;
            }
        }

    </style>

</head>

<body>


<header>

    <div class="logo">
        AMAR V
    </div>

    <div class="subtitulo">
        Servidor de Sincronização e Administração
    </div>

</header>


<main>


    <!-- =========================
         TÍTULO
    ========================== -->

    <section class="card destaque">

        <h2>
            💾 Backup
        </h2>

        <p>
            Cadastro e gerenciamento dos backups
            realizados pelo sistema Amar V.
        </p>

    </section>


    <!-- =========================
         MENSAGEM
    ========================== -->

    <?php if ($mensagem): ?>

        <div class="mensagem">

            <?= htmlspecialchars($mensagem) ?>

        </div>

    <?php endif; ?>


    <?php if ($erro): ?>

        <div class="erro">

            <?= htmlspecialchars($erro) ?>

        </div>

    <?php endif; ?>


    <!-- =========================
         FORMULÁRIO
    ========================== -->

    <section class="card">

        <h3>

            <?=
                $backupEditar
                ? "✏️ Editar Backup"
                : "➕ Registrar Backup"
            ?>

        </h3>


        <form method="post">


            <?php if ($backupEditar): ?>

                <input
                    type="hidden"
                    name="Id"
                    value="<?=
                        (int) $backupEditar["Id"]
                    ?>"
                >

            <?php endif; ?>


            <div class="formulario">


                <!-- DATA -->

                <div class="campo">

                    <label for="DataBackup">

                        Data do Backup

                    </label>

                    <input
                        type="datetime-local"
                        id="DataBackup"
                        name="DataBackup"
                        value="<?php

                            if ($backupEditar) {

                                echo date(
                                    "Y-m-d\TH:i",
                                    strtotime(
                                        $backupEditar["DataBackup"]
                                    )
                                );

                            } else {

                                echo date(
                                    "Y-m-d\TH:i"
                                );
                            }

                        ?>"
                    >

                </div>


                <!-- STATUS -->

                <div class="campo">

                    <label for="Status">

                        Status

                    </label>

                    <select
                        id="Status"
                        name="Status"
                        required
                    >

                        <option value="">
                            Selecione
                        </option>


                        <option
                            value="Realizado"
                            <?= (
                                $backupEditar &&
                                $backupEditar["Status"]
                                === "Realizado"
                            )
                            ? "selected"
                            : ""
                            ?>
                        >
                            Realizado
                        </option>


                        <option
                            value="Concluido"
                            <?= (
                                $backupEditar &&
                                $backupEditar["Status"]
                                === "Concluido"
                            )
                            ? "selected"
                            : ""
                            ?>
                        >
                            Concluído
                        </option>


                        <option
                            value="Pendente"
                            <?= (
                                $backupEditar &&
                                $backupEditar["Status"]
                                === "Pendente"
                            )
                            ? "selected"
                            : ""
                            ?>
                        >
                            Pendente
                        </option>


                        <option
                            value="Erro"
                            <?= (
                                $backupEditar &&
                                $backupEditar["Status"]
                                === "Erro"
                            )
                            ? "selected"
                            : ""
                            ?>
                        >
                            Erro
                        </option>

                    </select>

                </div>


                <!-- LOCAL DO ARQUIVO -->

                <div class="campo campo-completo">

                    <label for="LocalArquivo">

                        Local do Arquivo

                    </label>

                    <input
                        type="text"
                        id="LocalArquivo"
                        name="LocalArquivo"
                        maxlength="500"
                        placeholder="Ex.: C:/xampp/htdocs/amarv/backups/backup_2026.sql"
                        value="<?=
                            $backupEditar
                            ? htmlspecialchars(
                                $backupEditar[
                                    "LocalArquivo"
                                ]
                            )
                            : ""
                        ?>"
                    >

                </div>


            </div>


            <div class="botoes">


                <button
                    type="submit"
                    class="btn btn-salvar"
                >

                    💾

                    <?= $backupEditar
                        ? "Atualizar"
                        : "Registrar"
                    ?>

                </button>


                <?php if ($backupEditar): ?>

                    <a
                        href="backup.php"
                        class="btn btn-voltar"
                    >
                        Cancelar
                    </a>

                <?php endif; ?>


            </div>


        </form>

    </section>


    <!-- =========================
         LISTAGEM
    ========================== -->

    <section class="card">

        <h3>
            📋 Histórico de Backups
        </h3>


        <div class="tabela-container">

            <table>

                <thead>

                    <tr>

                        <th>
                            ID
                        </th>

                        <th>
                            Data do Backup
                        </th>

                        <th>
                            Status
                        </th>

                        <th>
                            Local do Arquivo
                        </th>

                        <th>
                            Ações
                        </th>

                    </tr>

                </thead>


                <tbody>


                    <?php if (count($backups) > 0): ?>


                        <?php foreach ($backups as $backup): ?>


                            <?php

                            $status =
                                $backup["Status"];

                            $classeStatus =
                                "status-outro";


                            if (
                                strtolower($status)
                                === "realizado" ||
                                strtolower($status)
                                === "concluido" ||
                                strtolower($status)
                                === "concluído"
                            ) {

                                $classeStatus =
                                    "status-sucesso";

                            } elseif (
                                strtolower($status)
                                === "erro"
                            ) {

                                $classeStatus =
                                    "status-erro";
                            }

                            ?>


                            <tr>


                                <td>

                                    <?= (int)
                                        $backup["Id"]
                                    ?>

                                </td>


                                <td>

                                    <?php

                                    if (
                                        !empty(
                                            $backup[
                                                "DataBackup"
                                            ]
                                        )
                                    ) {

                                        echo date(
                                            "d/m/Y H:i:s",
                                            strtotime(
                                                $backup[
                                                    "DataBackup"
                                                ]
                                            )
                                        );

                                    } else {

                                        echo "-";
                                    }

                                    ?>

                                </td>


                                <td>

                                    <span
                                        class="<?= $classeStatus ?>"
                                    >

                                        <?= htmlspecialchars(
                                            $status
                                        ) ?>

                                    </span>

                                </td>


                                <td class="arquivo">

                                    <?php if (
                                        !empty(
                                            $backup[
                                                "LocalArquivo"
                                            ]
                                        )
                                    ): ?>

                                        <?= htmlspecialchars(
                                            $backup[
                                                "LocalArquivo"
                                            ]
                                        ) ?>

                                    <?php else: ?>

                                        <em>
                                            Não informado
                                        </em>

                                    <?php endif; ?>

                                </td>


                                <td>

                                    <div class="acoes">


                                        <a
                                            href="backup.php?editar=<?= (int) $backup["Id"] ?>"
                                            class="btn btn-editar"
                                        >

                                            ✏️ Editar

                                        </a>


                                        <a
                                            href="backup.php?excluir=<?= (int) $backup["Id"] ?>"
                                            class="btn btn-excluir"
                                            onclick="return confirm('Tem certeza que deseja excluir este registro de backup?');"
                                        >

                                            🗑️ Excluir

                                        </a>


                                    </div>

                                </td>


                            </tr>


                        <?php endforeach; ?>


                    <?php else: ?>


                        <tr>

                            <td colspan="5">

                                Nenhum backup encontrado.

                            </td>

                        </tr>


                    <?php endif; ?>


                </tbody>

            </table>

        </div>

    </section>


    <!-- =========================
         VOLTAR
    ========================== -->

    <section class="card">

        <a
            href="index.php"
            class="btn btn-voltar"
        >

            ← Voltar ao Painel

        </a>

    </section>


</main>


<footer>

    Amar V © <?= date("Y") ?>

</footer>


</body>

</html>