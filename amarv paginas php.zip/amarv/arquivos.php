<?php

date_default_timezone_set('America/Sao_Paulo');

$pasta = "C:/Users/jesui/Downloads/AmarV/";

$arquivos = [];

if (is_dir($pasta)) {

    $arquivos = glob($pasta . "*.json");

    usort($arquivos, function ($a, $b) {
        return filemtime($b) - filemtime($a);
    });
}

?>

<!DOCTYPE html>
<html lang="pt-BR">

<head>

    <meta charset="UTF-8">

    <meta name="viewport"
          content="width=device-width, initial-scale=1.0">

    <title>Amar V - Arquivos</title>

    <link rel="stylesheet"
          href="css/estilo.css">

</head>

<body>

<header>

    <div class="logo">
        AMAR V
    </div>

    <div class="subtitulo">
        Arquivos de Sincronização
    </div>

</header>


<main>

    <section class="card">

        <h1>
            Arquivos recebidos
        </h1>

        <p>
            Arquivos enviados pelo aplicativo Amar V.
        </p>

    </section>


    <section class="card">

        <?php if (count($arquivos) == 0): ?>

            <p>
                Nenhum arquivo de sincronização foi recebido.
            </p>

        <?php else: ?>

            <table>

                <thead>

                    <tr>

                        <th>
                            Arquivo
                        </th>

                        <th>
                            Data
                        </th>

                        <th>
                            Tamanho
                        </th>

                        <th>
                            Ação
                        </th>

                    </tr>

                </thead>

                <tbody>

                <?php foreach ($arquivos as $arquivo): ?>

                    <?php

                    $nome = basename($arquivo);

                    $data = date(
                        "d/m/Y H:i:s",
                        filemtime($arquivo)
                    );

                    $tamanho = filesize($arquivo);

                    ?>

                    <tr>

                        <td>
                            <?= htmlspecialchars($nome) ?>
                        </td>

                        <td>
                            <?= $data ?>
                        </td>

                        <td>
                            <?= number_format(
                                $tamanho / 1024,
                                2
                            ) ?> KB
                        </td>

                        <td>

                            <!-- VISUALIZAR -->

                            <a
                                class="botao"
                                href="visualizar.php?arquivo=<?= urlencode($nome) ?>"
                            >
                                Visualizar
                            </a>


                            <!-- BAIXAR -->

                            <a
                                class="botao"
                                href="baixar.php?arquivo=<?= urlencode($nome) ?>"
                            >
                                Baixar
                            </a>


                            <!-- EDITAR -->

                            <a
                                class="botao"
                                href="editar.php?arquivo=<?= urlencode($nome) ?>"
                            >
                                Editar
                            </a>


                            <!-- EXCLUIR -->

                            <a
                                class="botao"
                                href="excluir.php?arquivo=<?= urlencode($nome) ?>"
                                onclick="return confirm('Tem certeza que deseja excluir este arquivo?');"
                            >
                                Excluir
                            </a>

                        </td>

                    </tr>

                <?php endforeach; ?>

                </tbody>

            </table>

        <?php endif; ?>

        <br>

        <a
            href="index.php"
            class="botao"
        >
            Voltar
        </a>

    </section>

</main>


<footer>

    Amar V © <?= date("Y") ?>

</footer>

</body>

</html>