<?php
require_once "conexao.php";

$id = (int)($_GET['id'] ?? 0);

$stmt = $pdo->prepare("SELECT * FROM vacina WHERE Id = ?");
$stmt->execute([$id]);
$vacina = $stmt->fetch();

if (!$vacina) {
    header("Location: vacina.php");
    exit;
}

$mensagem = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome = trim($_POST['nome'] ?? '');
    $fabricante = trim($_POST['fabricante'] ?? '');
    $tipoVacina = trim($_POST['tipo_vacina'] ?? '');
    $quantidadeDoses = (int)($_POST['quantidade_doses'] ?? 0);
    $tipoCalendario = trim($_POST['tipo_calendario'] ?? '');

    if (!empty($nome)) {
        $stmtUpdate = $pdo->prepare("UPDATE vacina SET Nome = ?, Fabricante = ?, TipoVacina = ?, QuantidadeDoses = ?, TipoCalendario = ? WHERE Id = ?");
        $stmtUpdate->execute([$nome, $fabricante ?: null, $tipoVacina ?: null, $quantidadeDoses, $tipoCalendario ?: null, $id]);
        
        header("Location: vacina.php?sucesso=1");
        exit;
    } else {
        $mensagem = "O nome da vacina é obrigatório.";
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Vacina - Amar V</title>
    <link rel="stylesheet" href="css/estilo.css">
    <style>
        .form-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
            margin-bottom: 15px;
        }
        .form-grupo {
            display: flex;
            flex-direction: column;
            gap: 5px;
        }
        .form-grupo label {
            font-weight: bold;
            font-size: 13px;
            color: #193f40;
        }
        .form-grupo input, .form-grupo select {
            padding: 10px;
            border: 1px solid #c2d6d4;
            border-radius: 8px;
            font-size: 14px;
        }
        .btn-voltar {
            background-color: #607d8b;
            color: white;
            padding: 10px 18px;
            border-radius: 8px;
            text-decoration: none;
            font-weight: bold;
            display: inline-block;
            margin-bottom: 20px;
        }
    </style>
</head>
<body>

<header>
    <div class="logo">AMAR V</div>
    <div class="subtitulo">Edição de Registros</div>
</header>

<main>
    <a href="vacina.php" class="btn-voltar">← Voltar para Lista</a>

    <section class="card">
        <div class="titulo-secao">
            <div class="titulo-icone">✏️</div>
            <div>
                <h2>Editar Vacina #<?= $vacina['Id'] ?></h2>
                <p>Atualize os dados da vacina selecionada.</p>
            </div>
        </div>

        <form action="vacina_editar.php?id=<?= $vacina['Id'] ?>" method="POST">
            <div class="form-grid">
                <div class="form-grupo">
                    <label>Nome da Vacina *</label>
                    <input type="text" name="nome" value="<?= htmlspecialchars($vacina['Nome']) ?>" required>
                </div>

                <div class="form-grupo">
                    <label>Fabricante</label>
                    <input type="text" name="fabricante" value="<?= htmlspecialchars($vacina['Fabricante'] ?? '') ?>">
                </div>

                <div class="form-grupo">
                    <label>Tipo de Vacina</label>
                    <input type="text" name="tipo_vacina" value="<?= htmlspecialchars($vacina['TipoVacina'] ?? '') ?>">
                </div>

                <div class="form-grupo">
                    <label>Quantidade de Doses</label>
                    <input type="number" name="quantidade_doses" value="<?= $vacina['QuantidadeDoses'] ?>" min="0">
                </div>

                <div class="form-grupo">
                    <label>Tipo de Calendário</label>
                    <select name="tipo_calendario">
                        <option value="SUS" <?= $vacina['TipoCalendario'] === 'SUS' ? 'selected' : '' ?>>SUS</option>
                        <option value="Privado" <?= $vacina['TipoCalendario'] === 'Privado' ? 'selected' : '' ?>>Privado</option>
                    </select>
                </div>
            </div>

            <button type="submit" class="botao">Atualizar Vacina</button>
        </form>
    </section>
</main>

<footer>
    Amar V © <?= date("Y") ?>
</footer>

</body>
</html>