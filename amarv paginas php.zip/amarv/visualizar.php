<?php

$pasta = "C:/Users/jesui/Downloads/AmarV/";

if (!isset($_GET["arquivo"])) {
    die("Nenhum arquivo informado.");
}

$nomeArquivo = basename($_GET["arquivo"]);

$caminho = $pasta . $nomeArquivo;

if (!file_exists($caminho)) {
    die("Arquivo não encontrado.");
}

$conteudo = file_get_contents($caminho);

$dados = json_decode($conteudo, true);

?>

<!DOCTYPE html>
<html lang="pt-BR">

<head>

    <meta charset="UTF-8">

    <meta name="viewport"
          content="width=device-width, initial-scale=1.0">

    <title>Amar V - Visualizar</title>

    <link rel="stylesheet"
          href="css/estilo.css">

</head>

<body>

<header>

    <div class="logo">
        AMAR V
    </div>

    <div class="subtitulo">
        Visualização da Sincronização
    </div>

</header>


<main>

    <section class="card">

        <h1>
            Arquivo recebido
        </h1>

        <p>
            <strong>Arquivo:</strong>
            <?= htmlspecialchars($nomeArquivo) ?>
        </p>

    </section>


    <section class="card">

        <h2>
            Dados recebidos
        </h2>

        <?php if ($dados !== null): ?>

            <pre class="json"><?= htmlspecialchars(
                json_encode(
                    $dados,
                    JSON_PRETTY_PRINT |
                    JSON_UNESCAPED_UNICODE
                )
            ) ?></pre>

        <?php else: ?>

            <p>
                O arquivo não contém um JSON válido.
            </p>

            <pre class="json"><?= htmlspecialchars($conteudo) ?></pre>

        <?php endif; ?>

    </section>


    <section class="card">

        <a href="arquivos.php"
           class="botao">

            Voltar aos arquivos

        </a>

    </section>

</main>


<footer>

    Amar V © <?= date("Y") ?>

</footer>

</body>

</html>