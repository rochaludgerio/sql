<?php

header('Content-Type: application/json; charset=utf-8');

$pdo = null;

try {

    // =========================================================
    // CONFIGURAÇÃO DO MYSQL
    // =========================================================

    $host = "localhost";
    $banco = "amarv";
    $usuario = "root";
    $senha = "";

    $pdo = new PDO(
        "mysql:host=$host;dbname=$banco;charset=utf8mb4",
        $usuario,
        $senha,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false
        ]
    );

    // =========================================================
    // RECEBER JSON
    // =========================================================

    $json = file_get_contents("php://input");

    if ($json === false || trim($json) === '') {
        throw new Exception(
            "Nenhum dado foi recebido pelo servidor."
        );
    }

    // =========================================================
    // DECODIFICAR JSON
    // =========================================================

    $dados = json_decode($json, true);

    if (
        json_last_error() !== JSON_ERROR_NONE ||
        !is_array($dados)
    ) {
        throw new Exception(
            "JSON inválido: " . json_last_error_msg()
        );
    }

    // =========================================================
    // MAPA JSON => MYSQL
    // =========================================================

    $tabelas = [

        "pessoa"                       => "pessoa",

        "pacientes"                    => "paciente",

        "usuarioDoSistema"             => "usuario_do_sistema",

        "administradorDoSistema"       => "administrador_do_sistema",

        "sessoes"                      => "sessao",

        "condicoesClinicas"            => "condicao_clinica",

        "vacinas"                      => "vacina",

        "doses"                        => "dose",

        "calendariosVacinais"          => "calendario_vacinal",

        "calendariosSUS"               => "calendario_vacinal_sus",

        "calendariosRedePrivada"       => "calendario_vacinal_rede_privada",

        "regrasVacinais"               => "regra_vacinal",

        "historicoVacinal"             => "historico_vacinal",

        "analisesEsquemaVacinal"       => "analise_esquema_vacinal",

        "relatorios"                   => "relatorio",

        "relatoriosVacinaisPaciente"   => "relatorio_vacinal_paciente",

        "relatoriosPacientesAtrasados" => "relatorio_pacientes_atrasados",

        "relatoriosPacientesRegulares" => "relatorio_pacientes_regulares"
    ];

    // =========================================================
    // FOREIGN KEYS
    // =========================================================

    $pdo->exec("SET FOREIGN_KEY_CHECKS = 0");

    $pdo->beginTransaction();

    // =========================================================
    // CONTADORES
    // =========================================================

    $totalRegistros = 0;
    $totalTabelas = 0;
    $totalIgnorados = 0;
    $totalInseridos = 0;
    $totalAtualizados = 0;

    // =========================================================
    // CACHE DAS ESTRUTURAS
    // =========================================================

    $estruturaTabelas = [];

    // =========================================================
    // CACHE DOS IDS ANTES DA SINCRONIZAÇÃO
    // =========================================================

    $idsAntes = [];

    // =========================================================
    // PROCESSAR TABELAS
    // =========================================================

    foreach ($tabelas as $chaveJson => $tabela) {

        // -----------------------------------------------------
        // Verificar se o JSON possui a chave
        // -----------------------------------------------------

        if (!array_key_exists($chaveJson, $dados)) {
            continue;
        }

        if (!is_array($dados[$chaveJson])) {
            continue;
        }

        // -----------------------------------------------------
        // Ignorar tabela vazia
        // -----------------------------------------------------

        if (count($dados[$chaveJson]) === 0) {
            continue;
        }

        // -----------------------------------------------------
        // Verificar existência da tabela
        // -----------------------------------------------------

        $stmtExiste = $pdo->prepare("
            SELECT COUNT(*)
            FROM information_schema.tables
            WHERE table_schema = ?
              AND table_name = ?
        ");

        $stmtExiste->execute([
            $banco,
            $tabela
        ]);

        if ((int)$stmtExiste->fetchColumn() === 0) {

            throw new Exception(
                "A tabela '$tabela' não existe no banco '$banco'."
            );
        }

        // -----------------------------------------------------
        // Ler estrutura da tabela
        // -----------------------------------------------------

        if (!isset($estruturaTabelas[$tabela])) {

            $stmtColunas = $pdo->query(
                "SHOW COLUMNS FROM `$tabela`"
            );

            $colunas = [];

            while ($coluna = $stmtColunas->fetch()) {

                $nomeOriginal = $coluna["Field"];

                $colunas[
                    strtolower($nomeOriginal)
                ] = [
                    "nome" => $nomeOriginal,
                    "extra" => $coluna["Extra"],
                    "nulo" => $coluna["Null"],
                    "tipo" => $coluna["Type"],
                    "chave" => $coluna["Key"]
                ];
            }

            $estruturaTabelas[$tabela] = $colunas;
        }

        $estrutura = $estruturaTabelas[$tabela];

        // -----------------------------------------------------
        // Guardar IDs existentes para saber se atualizou
        // -----------------------------------------------------

        $idsAntes[$tabela] = [];

        if (isset($estrutura["id"])) {

            $stmtIds = $pdo->query(
                "SELECT `Id` FROM `$tabela`"
            );

            while ($linha = $stmtIds->fetch()) {

                $idsAntes[$tabela][
                    (string)$linha["Id"]
                ] = true;
            }
        }

        // =====================================================
        // PROCESSAR REGISTROS
        // =====================================================

        foreach ($dados[$chaveJson] as $registro) {

            if (
                !is_array($registro) ||
                count($registro) === 0
            ) {

                $totalIgnorados++;
                continue;
            }

            // -------------------------------------------------
            // Converter chaves para minúsculas apenas para
            // facilitar a identificação.
            // -------------------------------------------------

            $registroLower =
                array_change_key_case(
                    $registro,
                    CASE_LOWER
                );

            // -------------------------------------------------
            // CAMPOS
            // -------------------------------------------------

            $campos = [];
            $valores = [];

            $idRegistro = null;

            foreach ($registro as $campoJson => $valor) {

                $campoLower = strtolower($campoJson);

                // -------------------------------------------------
                // Campo não existe no MySQL
                // -------------------------------------------------

                if (
                    !isset($estrutura[$campoLower])
                ) {
                    continue;
                }

                $colunaReal =
                    $estrutura[$campoLower]["nome"];

                // -------------------------------------------------
                // ID
                // -------------------------------------------------

                if ($campoLower === "id") {

                    if (
                        $valor !== null &&
                        $valor !== '' &&
                        (int)$valor > 0
                    ) {

                        $idRegistro = (int)$valor;

                        /*
                         * Só colocamos o Id no INSERT.
                         * No UPDATE ele não será alterado.
                         */
                    }

                    continue;
                }

                // -------------------------------------------------
                // Datas .NET inválidas
                // -------------------------------------------------

                if (
                    is_string($valor) &&
                    (
                        strpos(
                            $valor,
                            "0001-01-01"
                        ) !== false
                        ||
                        strpos(
                            $valor,
                            "0001-01-01T00:00:00"
                        ) !== false
                    )
                ) {

                    $valor = null;
                }

                // -------------------------------------------------
                // Booleanos
                // -------------------------------------------------

                if (is_bool($valor)) {
                    $valor = $valor ? 1 : 0;
                }

                $campos[] =
                    "`$colunaReal`";

                $valores[] =
                    $valor;
            }

            // -------------------------------------------------
            // Se não houver campos válidos
            // -------------------------------------------------

            if (count($campos) === 0) {

                $totalIgnorados++;
                continue;
            }

            // =================================================
            // MONTAR INSERT
            // =================================================

            $camposInsert = $campos;
            $valoresInsert = $valores;

            // -------------------------------------------------
            // Adicionar Id somente quando o MAUI enviou um Id
            // válido e a tabela possui coluna Id.
            // -------------------------------------------------

            if (
                $idRegistro !== null &&
                isset($estrutura["id"])
            ) {

                array_unshift(
                    $camposInsert,
                    "`" .
                    $estrutura["id"]["nome"] .
                    "`"
                );

                array_unshift(
                    $valoresInsert,
                    $idRegistro
                );
            }

            // -------------------------------------------------
            // MARCADORES
            // -------------------------------------------------

            $marcadores = implode(
                ", ",
                array_fill(
                    0,
                    count($valoresInsert),
                    "?"
                )
            );

            $listaCampos =
                implode(
                    ", ",
                    $camposInsert
                );

            // =================================================
            // MONTAR ON DUPLICATE KEY UPDATE
            // =================================================

            $updates = [];

            foreach ($campos as $campo) {

                $updates[] =
                    "$campo = VALUES($campo)";
            }

            // -------------------------------------------------
            // Caso não exista nenhum campo para atualizar
            // -------------------------------------------------

            if (count($updates) === 0) {

                $updates[] =
                    "1 = 1";
            }

            $sql = "
                INSERT INTO `$tabela`
                (
                    $listaCampos
                )
                VALUES
                (
                    $marcadores
                )
                ON DUPLICATE KEY UPDATE
                    " .
                    implode(
                        ", ",
                        $updates
                    );

            // =================================================
            // EXECUTAR
            // =================================================

            try {

                $stmt = $pdo->prepare($sql);

                $stmt->execute(
                    $valoresInsert
                );

                $linhasAfetadas =
                    $stmt->rowCount();

                // -------------------------------------------------
                // rowCount:
                //
                // 1 = INSERT
                // 2 = UPDATE
                // 0 = já estava exatamente igual
                // -------------------------------------------------

                if ($linhasAfetadas === 1) {

                    $totalInseridos++;

                } elseif ($linhasAfetadas === 2) {

                    $totalAtualizados++;
                }

                $totalRegistros++;

            } catch (PDOException $erro) {

                throw new Exception(
                    "Erro ao sincronizar a tabela " .
                    "'$tabela'. " .
                    "Registro: " .
                    json_encode(
                        $registro,
                        JSON_UNESCAPED_UNICODE
                    ) .
                    ". Detalhes: " .
                    $erro->getMessage()
                );
            }
        }

        $totalTabelas++;
    }

    // =========================================================
    // COMMIT
    // =========================================================

    $pdo->commit();

    // =========================================================
    // REATIVAR FOREIGN KEYS
    // =========================================================

    $pdo->exec(
        "SET FOREIGN_KEY_CHECKS = 1"
    );

    // =========================================================
    // CRIAR BACKUP JSON DA SINCRONIZAÇÃO
    // =========================================================

    $arquivo =
        "AmarV_" .
        date("Y-m-d_H-i-s") .
        ".json";

    $pastaBackup =
        __DIR__ .
        DIRECTORY_SEPARATOR .
        "../backups";

    if (!is_dir($pastaBackup)) {

        if (
            !mkdir(
                $pastaBackup,
                0777,
                true
            )
        ) {

            throw new Exception(
                "Falha ao criar pasta de armazenamento de backups."
            );
        }
    }

    $caminhoBackup =
        $pastaBackup .
        DIRECTORY_SEPARATOR .
        $arquivo;

    if (
        file_put_contents(
            $caminhoBackup,
            $json
        ) === false
    ) {

        /*
         * Neste ponto o banco já foi sincronizado.
         * Portanto não retornamos erro de banco.
         */
        error_log(
            "Amar V: banco sincronizado, mas não foi possível criar backup JSON."
        );
    }

    // =========================================================
    // REGISTRAR SINCRONIZAÇÃO
    // =========================================================

    try {

        $stmtSync = $pdo->prepare("
            INSERT INTO `sincronizacao`
            (
                `DataSincronizacao`,
                `Status`,
                `QuantidadeRegistros`
            )
            VALUES
            (
                NOW(),
                ?,
                ?
            )
        ");

        $stmtSync->execute([
            "Sincronizado",
            $totalRegistros
        ]);

    } catch (Throwable $erroSync) {

        error_log(
            "Erro ao registrar sincronização Amar V: " .
            $erroSync->getMessage()
        );
    }

    // =========================================================
    // RESPOSTA
    // =========================================================

    echo json_encode(
        [
            "sucesso" => true,

            "mensagem" =>
                "Sincronização realizada com sucesso.",

            "arquivo" =>
                $arquivo,

            "quantidadeRegistros" =>
                $totalRegistros,

            "quantidadeTabelas" =>
                $totalTabelas,

            "quantidadeIgnorados" =>
                $totalIgnorados,

            "quantidadeAtualizados" =>
                $totalAtualizados,

            "quantidadeInseridos" =>
                $totalInseridos
        ],
        JSON_UNESCAPED_UNICODE |
        JSON_PRETTY_PRINT
    );

} catch (Throwable $e) {

    // =========================================================
    // ROLLBACK
    // =========================================================

    if (
        $pdo !== null &&
        $pdo instanceof PDO &&
        $pdo->inTransaction()
    ) {

        $pdo->rollBack();
    }

    // =========================================================
    // REATIVAR FOREIGN KEYS
    // =========================================================

    if (
        $pdo !== null &&
        $pdo instanceof PDO
    ) {

        try {

            $pdo->exec(
                "SET FOREIGN_KEY_CHECKS = 1"
            );

        } catch (Throwable $ignorar) {
        }
    }

    // =========================================================
    // ERRO
    // =========================================================

    http_response_code(500);

    echo json_encode(
        [
            "sucesso" => false,

            "mensagem" =>
                "Erro durante a sincronização.",

            "erro" =>
                $e->getMessage()
        ],
        JSON_UNESCAPED_UNICODE |
        JSON_PRETTY_PRINT
    );
}
?>