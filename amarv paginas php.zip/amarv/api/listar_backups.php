<?php

header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    echo json_encode([
        "sucesso" => false,
        "mensagem" => "Apenas requisições GET são permitidas."
    ]);
    exit;
}

$pasta = "C:/Users/jesui/Downloads/AmarV/";

if (!is_dir($pasta)) {
    echo json_encode([
        "sucesso" => false,
        "mensagem" => "A pasta de backup não existe."
    ]);
    exit;
}

$arquivos = [];

$lista = scandir($pasta);

foreach ($lista as $arquivo) {

    if ($arquivo === "." || $arquivo === "..") {
        continue;
    }

    $caminho = $pasta . $arquivo;

    if (!is_file($caminho)) {
        continue;
    }

    $extensao = strtolower(pathinfo($arquivo, PATHINFO_EXTENSION));

    if ($extensao !== "json") {
        continue;
    }

    $arquivos[] = [
        "nome" => $arquivo,
        "tamanho" => filesize($caminho),
        "data" => date(
            "d/m/Y H:i:s",
            filemtime($caminho)
        )
    ];
}

// Mais recentes primeiro
usort($arquivos, function ($a, $b) {

    $dataA = DateTime::createFromFormat(
        "d/m/Y H:i:s",
        $a["data"]
    );

    $dataB = DateTime::createFromFormat(
        "d/m/Y H:i:s",
        $b["data"]
    );

    return $dataB <=> $dataA;
});

echo json_encode([
    "sucesso" => true,
    "arquivos" => $arquivos
], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);

