<?php

header('Content-Type: application/json; charset=utf-8');

try {

    // ============================================================
    // CONFIGURAÇÃO DO BANCO
    // ============================================================

    $host = "localhost";
    $banco = "amarv";
    $usuario = "root";
    $senha = "";

    $pdo = new PDO(
        "mysql:host=$host;dbname=$banco;charset=utf8mb4",
        $usuario,
        $senha,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
        ]
    );

    // ============================================================
    // TABELAS DO SISTEMA
    //
    // IMPORTANTE:
    // usuario_sistema NÃO EXISTE MAIS.
    // A tabela correta é usuario_do_sistema.
    // ============================================================

    $tabelas = [

        "pessoa" => "pessoa",

        "pacientes" => "paciente",

        "usuarioDoSistema" => "usuario_do_sistema",

        "administradorDoSistema" => "administrador_do_sistema",

        "sessoes" => "sessao",

        "condicoesClinicas" => "condicao_clinica",

        "vacinas" => "vacina",

        "doses" => "dose",

        "calendariosVacinais" => "calendario_vacinal",

        "calendariosSUS" => "calendario_vacinal_sus",

        "calendariosRedePrivada" => "calendario_vacinal_rede_privada",

        "regrasVacinais" => "regra_vacinal",

        "historicoVacinal" => "historico_vacinal",

        "analisesEsquemaVacinal" => "analise_esquema_vacinal",

        "relatorios" => "relatorio",

        "relatoriosVacinaisPaciente" => "relatorio_vacinal_paciente",

        "relatoriosPacientesAtrasados" => "relatorio_pacientes_atrasados",

        "relatoriosPacientesRegulares" => "relatorio_pacientes_regulares",

        "sincronizacoes" => "sincronizacao",

        "backups" => "backup"
    ];

    // ============================================================
    // BUSCAR DADOS
    // ============================================================

    $dados = [];

    foreach ($tabelas as $chave => $tabela) {

        // Verifica se a tabela realmente existe
        $sqlExiste = "
            SELECT COUNT(*)
            FROM information_schema.tables
            WHERE table_schema = :banco
              AND table_name = :tabela
        ";

        $stmtExiste = $pdo->prepare($sqlExiste);

        $stmtExiste->execute([
            ':banco' => $banco,
            ':tabela' => $tabela
        ]);

        $existe = (int)$stmtExiste->fetchColumn();

        // Se a tabela não existir, retorna lista vazia
        // em vez de interromper toda a recuperação.
        if ($existe === 0) {

            $dados[$chave] = [];

            continue;
        }

        // Busca os registros
        $sql = "SELECT * FROM `$tabela`";

        $stmt = $pdo->query($sql);

        $dados[$chave] = $stmt->fetchAll();
    }

    // ============================================================
    // RESPOSTA
    // ============================================================

    echo json_encode(
        [
            "sucesso" => true,

            "mensagem" => "Dados enviados pelo servidor.",

            "dados" => $dados
        ],
        JSON_UNESCAPED_UNICODE
    );

}
catch (PDOException $e) {

    http_response_code(500);

    echo json_encode(
        [
            "sucesso" => false,

            "mensagem" => "Erro ao acessar o banco de dados.",

            "erro" => $e->getMessage()
        ],
        JSON_UNESCAPED_UNICODE
    );

}
catch (Exception $e) {

    http_response_code(500);

    echo json_encode(
        [
            "sucesso" => false,

            "mensagem" => "Erro durante a recuperação dos dados.",

            "erro" => $e->getMessage()
        ],
        JSON_UNESCAPED_UNICODE
    );
}

?>