<?php

header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    echo json_encode([
        "sucesso" => false,
        "mensagem" => "Apenas requisições GET são permitidas."
    ]);
    exit;
}

$pasta = "C:/Users/jesui/Downloads/AmarV/";

if (!is_dir($pasta)) {
    echo json_encode([
        "sucesso" => false,
        "mensagem" => "A pasta de backup não existe."
    ]);
    exit;
}


// =====================================================
// LISTAR OS BACKUPS
// =====================================================

if (!isset($_GET['arquivo']) || trim($_GET['arquivo']) === '') {

    $arquivos = glob($pasta . "AmarV_Backup_*.json");

    if (!$arquivos || count($arquivos) === 0) {

        echo json_encode([
            "sucesso" => false,
            "mensagem" => "Nenhum backup encontrado no servidor."
        ]);

        exit;
    }


    // Ordenar do mais recente para o mais antigo

    usort($arquivos, function ($a, $b) {

        return filemtime($b) - filemtime($a);

    });


    $lista = [];


    foreach ($arquivos as $arquivo) {

        $lista[] = [
            "arquivo" => basename($arquivo),
            "data" => date(
                "d/m/Y H:i:s",
                filemtime($arquivo)
            ),
            "tamanho" => filesize($arquivo)
        ];
    }


    echo json_encode([

        "sucesso" => true,

        "mensagem" =>
            "Backups encontrados.",

        "backups" => $lista

    ], JSON_UNESCAPED_UNICODE);

    exit;
}



// =====================================================
// RESTAURAR UM BACKUP ESCOLHIDO
// =====================================================

$nomeArquivo = basename(
    trim($_GET['arquivo'])
);


// Verificar extensão

if (
    !str_ends_with(
        strtolower($nomeArquivo),
        ".json"
    )
) {

    echo json_encode([
        "sucesso" => false,
        "mensagem" => "Arquivo de backup inválido."
    ]);

    exit;
}


// Verificar padrão do backup

if (
    !preg_match(
        '/^AmarV_Backup_.*\.json$/i',
        $nomeArquivo
    )
) {

    echo json_encode([
        "sucesso" => false,
        "mensagem" => "Arquivo de backup não permitido."
    ]);

    exit;
}


$caminhoArquivo =
    $pasta . $nomeArquivo;


// Verificar existência

if (!file_exists($caminhoArquivo)) {

    echo json_encode([
        "sucesso" => false,
        "mensagem" =>
            "O backup selecionado não foi encontrado no servidor."
    ]);

    exit;
}


// Ler arquivo

$dadosArquivo =
    file_get_contents($caminhoArquivo);


if ($dadosArquivo === false) {

    echo json_encode([
        "sucesso" => false,
        "mensagem" =>
            "Não foi possível ler o backup selecionado."
    ]);

    exit;
}


// Converter JSON

$dados =
    json_decode(
        $dadosArquivo,
        true
    );


if ($dados === null) {

    echo json_encode([
        "sucesso" => false,
        "mensagem" =>
            "O arquivo de backup contém um JSON inválido."
    ]);

    exit;
}


// =====================================================
// RETORNO
// =====================================================

echo json_encode([

    "sucesso" => true,

    "mensagem" =>
        "Backup encontrado com sucesso.",

    "arquivo" =>
        $nomeArquivo,

    "dados" =>
        $dados

], JSON_UNESCAPED_UNICODE);

?>