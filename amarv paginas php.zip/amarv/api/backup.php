<?php

date_default_timezone_set('America/Sao_Paulo');

header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {

    echo json_encode([
        "sucesso" => false,
        "mensagem" => "Apenas requisições POST são permitidas."
    ]);

    exit;
}

$dados = file_get_contents("php://input");

if (empty($dados)) {

    echo json_encode([
        "sucesso" => false,
        "mensagem" => "Nenhum dado de backup foi recebido."
    ]);

    exit;
}

// Pasta de backup no computador
$pasta = "C:/Users/jesui/Downloads/AmarV/";

// Cria a pasta se não existir
if (!is_dir($pasta)) {

    if (!mkdir($pasta, 0777, true)) {

        echo json_encode([
            "sucesso" => false,
            "mensagem" => "Não foi possível criar a pasta de backup."
        ]);

        exit;
    }
}

// Nome do arquivo
$nomeArquivo = "AmarV_Backup_" .
    date("Y-m-d_H-i-s") .
    ".json";

$caminhoArquivo = $pasta . $nomeArquivo;

// Salvar arquivo
if (file_put_contents($caminhoArquivo, $dados) !== false) {

    echo json_encode([
        "sucesso" => true,
        "mensagem" => "Backup realizado com sucesso.",
        "arquivo" => $nomeArquivo
    ]);

} else {

    echo json_encode([
        "sucesso" => false,
        "mensagem" => "Não foi possível salvar o backup."
    ]);
}

?>