<?php
/*
 * usuario_do_sistema.php
 *
 * Gerenciamento de usuários do sistema
 *
 * Tabelas utilizadas:
 *   pessoa
 *   usuario_do_sistema
 *
 * Regra:
 *   - Todo usuário do sistema possui um Id correspondente em pessoa.
 *   - Uma pessoa que já possui registro em usuario_do_sistema
 *     não pode aparecer na lista para criar novo usuário.
 *   - Paciente NÃO é excluído da lista por ser paciente.
 */

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

/*
|--------------------------------------------------------------------------
| CONEXÃO
|--------------------------------------------------------------------------
*/

try {

    if (isset($pdo) && $pdo instanceof PDO) {

        $db = $pdo;

    } elseif (isset($conn) && $conn instanceof PDO) {

        $db = $conn;

    } else {

        $db = new PDO(
            'mysql:host=localhost;dbname=amarv;charset=utf8mb4',
            'root',
            '',
            [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES => false
            ]
        );
    }

    $db->setAttribute(
        PDO::ATTR_ERRMODE,
        PDO::ERRMODE_EXCEPTION
    );

} catch (PDOException $e) {

    die(
        '<div style="
            margin:30px;
            padding:20px;
            border:1px solid #dc3545;
            background:#f8d7da;
            color:#721c24;
            border-radius:8px;
            font-family:Arial,sans-serif;">
            <strong>Erro de conexão com o banco de dados:</strong><br><br>' .
            htmlspecialchars($e->getMessage()) .
        '</div>'
    );
}


/*
|--------------------------------------------------------------------------
| MENSAGENS
|--------------------------------------------------------------------------
*/

$mensagem = '';
$erro = '';


/*
|--------------------------------------------------------------------------
| EXCLUSÃO DE USUÁRIO
|--------------------------------------------------------------------------
*/

if (
    $_SERVER['REQUEST_METHOD'] === 'POST'
    && isset($_POST['acao'])
    && $_POST['acao'] === 'excluir'
) {

    $id = isset($_POST['Id'])
        ? (int) $_POST['Id']
        : 0;

    if ($id <= 0) {

        $erro = 'Usuário inválido para exclusão.';

    } else {

        try {

            /*
             * Verifica se o usuário existe.
             */

            $stmt = $db->prepare("
                SELECT
                    Id,
                    Login
                FROM usuario_do_sistema
                WHERE Id = :id
                LIMIT 1
            ");

            $stmt->execute([
                ':id' => $id
            ]);

            $usuario = $stmt->fetch();

            if (!$usuario) {

                $erro = 'Usuário não encontrado.';

            } else {

                /*
                 * Exclui somente o usuário.
                 *
                 * A pessoa continua cadastrada.
                 */

                $stmt = $db->prepare("
                    DELETE FROM usuario_do_sistema
                    WHERE Id = :id
                ");

                $stmt->execute([
                    ':id' => $id
                ]);

                $mensagem = 'Usuário excluído com sucesso.';
            }

        } catch (PDOException $e) {

            $erro = 'Erro ao excluir usuário: ' . $e->getMessage();
        }
    }
}


/*
|--------------------------------------------------------------------------
| CADASTRAR / EDITAR USUÁRIO
|--------------------------------------------------------------------------
*/

if (
    $_SERVER['REQUEST_METHOD'] === 'POST'
    && isset($_POST['acao'])
    && $_POST['acao'] === 'salvar'
) {

    $id = isset($_POST['Id']) && $_POST['Id'] !== ''
        ? (int) $_POST['Id']
        : 0;

    $login = trim($_POST['Login'] ?? '');
    $senha = $_POST['Senha'] ?? '';
    $perfil = trim($_POST['Perfil'] ?? 'Usuario');
    $status = trim($_POST['Status'] ?? 'Ativo');

    $ativo = isset($_POST['Ativo']) ? 1 : 0;


    /*
     * Validação básica
     */

    if ($id <= 0) {

        $erro = 'Selecione uma pessoa para criar o usuário.';

    } elseif ($login === '') {

        $erro = 'Informe o login do usuário.';

    } else {

        try {

            /*
             * Verifica se a pessoa realmente existe.
             */

            $stmt = $db->prepare("
                SELECT
                    Id,
                    Nome
                FROM pessoa
                WHERE Id = :id
                LIMIT 1
            ");

            $stmt->execute([
                ':id' => $id
            ]);

            $pessoa = $stmt->fetch();


            if (!$pessoa) {

                $erro = 'A pessoa selecionada não existe na tabela pessoa.';

            } else {

                /*
                 * Verifica se existe outro usuário
                 * utilizando o mesmo login.
                 */

                $stmt = $db->prepare("
                    SELECT
                        Id
                    FROM usuario_do_sistema
                    WHERE Login = :login
                      AND Id <> :id
                    LIMIT 1
                ");

                $stmt->execute([
                    ':login' => $login,
                    ':id' => $id
                ]);

                $loginExistente = $stmt->fetch();


                if ($loginExistente) {

                    $erro = 'Este login já está sendo utilizado por outro usuário.';

                } else {

                    /*
                     * Verifica se já existe usuário
                     * para esta pessoa.
                     */

                    $stmt = $db->prepare("
                        SELECT
                            Id
                        FROM usuario_do_sistema
                        WHERE Id = :id
                        LIMIT 1
                    ");

                    $stmt->execute([
                        ':id' => $id
                    ]);

                    $usuarioExistente = $stmt->fetch();


                    /*
                     |--------------------------------------------------------------------------
                     | EDIÇÃO
                     |--------------------------------------------------------------------------
                     */

                    if ($usuarioExistente) {

                        /*
                         * Nova senha informada.
                         */

                        if ($senha !== '') {

                            $senhaHash = password_hash(
                                $senha,
                                PASSWORD_DEFAULT
                            );

                            $stmt = $db->prepare("
                                UPDATE usuario_do_sistema
                                SET
                                    Login = :login,
                                    Senha = :senha,
                                    Perfil = :perfil,
                                    Status = :status,
                                    Ativo = :ativo
                                WHERE Id = :id
                            ");

                            $stmt->execute([
                                ':login' => $login,
                                ':senha' => $senhaHash,
                                ':perfil' => $perfil,
                                ':status' => $status,
                                ':ativo' => $ativo,
                                ':id' => $id
                            ]);

                        } else {

                            /*
                             * Mantém a senha atual.
                             */

                            $stmt = $db->prepare("
                                UPDATE usuario_do_sistema
                                SET
                                    Login = :login,
                                    Perfil = :perfil,
                                    Status = :status,
                                    Ativo = :ativo
                                WHERE Id = :id
                            ");

                            $stmt->execute([
                                ':login' => $login,
                                ':perfil' => $perfil,
                                ':status' => $status,
                                ':ativo' => $ativo,
                                ':id' => $id
                            ]);
                        }

                        $mensagem = 'Usuário atualizado com sucesso.';


                    /*
                     |--------------------------------------------------------------------------
                     | NOVO USUÁRIO
                     |--------------------------------------------------------------------------
                     */

                    } else {

                        if ($senha === '') {

                            $erro = 'Informe uma senha para criar o usuário.';

                        } else {

                            $senhaHash = password_hash(
                                $senha,
                                PASSWORD_DEFAULT
                            );


                            $stmt = $db->prepare("
                                INSERT INTO usuario_do_sistema
                                (
                                    Id,
                                    Login,
                                    Senha,
                                    Perfil,
                                    Status,
                                    Ativo
                                )
                                VALUES
                                (
                                    :id,
                                    :login,
                                    :senha,
                                    :perfil,
                                    :status,
                                    :ativo
                                )
                            ");

                            $stmt->execute([
                                ':id' => $id,
                                ':login' => $login,
                                ':senha' => $senhaHash,
                                ':perfil' => $perfil,
                                ':status' => $status,
                                ':ativo' => $ativo
                            ]);

                            $mensagem = 'Usuário cadastrado com sucesso.';
                        }
                    }
                }
            }

        } catch (PDOException $e) {

            $erro = 'Erro ao salvar usuário: ' . $e->getMessage();
        }
    }
}


/*
|--------------------------------------------------------------------------
| EDITAR
|--------------------------------------------------------------------------
*/

$usuarioEditar = null;

if (
    isset($_GET['editar'])
    && $_GET['editar'] !== ''
) {

    $idEditar = (int) $_GET['editar'];

    if ($idEditar > 0) {

        try {

            /*
             * A consulta começa em usuario_do_sistema.
             *
             * LEFT JOIN permite carregar o usuário mesmo
             * se houver alguma inconsistência em pessoa.
             */

            $stmt = $db->prepare("
                SELECT
                    u.Id,
                    u.Login,
                    u.Perfil,
                    u.Status,
                    u.Ativo,
                    p.Nome,
                    p.Cpf,
                    p.Telefone,
                    p.Endereco
                FROM usuario_do_sistema u
                LEFT JOIN pessoa p
                    ON p.Id = u.Id
                WHERE u.Id = :id
                LIMIT 1
            ");

            $stmt->execute([
                ':id' => $idEditar
            ]);

            $usuarioEditar = $stmt->fetch();

        } catch (PDOException $e) {

            $erro = 'Erro ao carregar usuário: ' . $e->getMessage();
        }
    }
}


/*
|--------------------------------------------------------------------------
| LISTA DE USUÁRIOS
|--------------------------------------------------------------------------
|
| IMPORTANTE:
|
| A consulta começa em usuario_do_sistema.
|
| Assim todos os usuários cadastrados são exibidos.
|
*/

$usuarios = [];

try {

    $sql = "
        SELECT
            u.Id,
            u.Login,
            u.Perfil,
            u.Status,
            u.Ativo,

            COALESCE(p.Nome, u.Login) AS Nome,
            p.Cpf,
            p.Telefone,
            p.Endereco

        FROM usuario_do_sistema u

        LEFT JOIN pessoa p
            ON p.Id = u.Id
    ";

    $params = [];


    /*
     * Pesquisa
     */

    if (
        isset($_GET['busca'])
        && trim($_GET['busca']) !== ''
    ) {

        $busca = trim($_GET['busca']);

        $sql .= "
            WHERE
                p.Nome LIKE :busca
                OR p.Cpf LIKE :busca
                OR p.Telefone LIKE :busca
                OR p.Endereco LIKE :busca
                OR u.Login LIKE :busca
                OR u.Perfil LIKE :busca
                OR u.Status LIKE :busca
        ";

        $params[':busca'] = '%' . $busca . '%';
    }


    $sql .= "
        ORDER BY
            COALESCE(p.Nome, u.Login) ASC
    ";


    $stmt = $db->prepare($sql);

    $stmt->execute($params);

    $usuarios = $stmt->fetchAll();

} catch (PDOException $e) {

    $erro = 'Erro ao listar usuários: ' . $e->getMessage();
}


/*
|--------------------------------------------------------------------------
| PESSOAS DISPONÍVEIS PARA CRIAR USUÁRIO
|--------------------------------------------------------------------------
|
| REGRA:
|
| A pessoa não pode aparecer se já possuir
| registro em usuario_do_sistema.
|
| Paciente NÃO é excluído.
|
*/

$pessoasDisponiveis = [];

try {

    $stmt = $db->prepare("
        SELECT
            p.Id,
            p.Nome,
            p.Cpf,
            p.Telefone,
            p.Endereco
        FROM pessoa p
        LEFT JOIN usuario_do_sistema u
            ON u.Id = p.Id
        WHERE u.Id IS NULL
        ORDER BY p.Nome ASC
    ");

    $stmt->execute();

    $pessoasDisponiveis = $stmt->fetchAll();

} catch (PDOException $e) {

    $erro = 'Erro ao carregar pessoas disponíveis: ' . $e->getMessage();
}


/*
|--------------------------------------------------------------------------
| VALORES DO FORMULÁRIO
|--------------------------------------------------------------------------
*/

$formId = '';
$formNome = '';
$formLogin = '';
$formPerfil = 'Usuario';
$formStatus = 'Ativo';
$formAtivo = 1;


if ($usuarioEditar) {

    $formId = $usuarioEditar['Id'];

    $formNome = $usuarioEditar['Nome'] ?? '';

    $formLogin = $usuarioEditar['Login'] ?? '';

    $formPerfil = $usuarioEditar['Perfil'] ?? 'Usuario';

    $formStatus = $usuarioEditar['Status'] ?? 'Ativo';

    $formAtivo = (int) (
        $usuarioEditar['Ativo'] ?? 0
    );
}

?>

<!DOCTYPE html>

<html lang="pt-BR">

<head>

    <meta charset="UTF-8">

    <meta name="viewport"
          content="width=device-width, initial-scale=1.0">

    <title>Usuários do Sistema</title>

    <style>

        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            padding: 0;
            font-family: Arial, Helvetica, sans-serif;
            background: #f5f6f8;
            color: #333;
        }

        .container {
            width: 100%;
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }

        .titulo {
            font-size: 28px;
            font-weight: bold;
            margin-bottom: 5px;
        }

        .subtitulo {
            color: #666;
            margin-bottom: 20px;
        }

        .mensagem {
            padding: 12px 15px;
            border-radius: 6px;
            margin-bottom: 15px;
            background: #d1e7dd;
            color: #0f5132;
            border: 1px solid #badbcc;
        }

        .erro {
            padding: 12px 15px;
            border-radius: 6px;
            margin-bottom: 15px;
            background: #f8d7da;
            color: #842029;
            border: 1px solid #f5c2c7;
        }

        .card {
            background: #fff;
            border-radius: 8px;
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.08);
        }

        .grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 15px;
        }

        .campo {
            display: flex;
            flex-direction: column;
        }

        .campo label {
            font-weight: bold;
            margin-bottom: 6px;
        }

        .campo input,
        .campo select {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 14px;
        }

        .campo input:focus,
        .campo select:focus {
            outline: none;
            border-color: #777;
        }

        .campo-completo {
            grid-column: 1 / -1;
        }

        .botoes {
            margin-top: 20px;
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
        }

        .btn {
            display: inline-block;
            padding: 10px 18px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            text-decoration: none;
            font-size: 14px;
        }

        .btn-primary {
            background: #0d6efd;
            color: #fff;
        }

        .btn-secondary {
            background: #6c757d;
            color: #fff;
        }

        .btn-danger {
            background: #dc3545;
            color: #fff;
        }

        .btn-success {
            background: #198754;
            color: #fff;
        }

        .btn:hover {
            opacity: 0.9;
        }

        .tabela-container {
            overflow-x: auto;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th,
        td {
            padding: 10px;
            border-bottom: 1px solid #ddd;
            text-align: left;
            vertical-align: middle;
        }

        th {
            background: #f1f1f1;
            font-weight: bold;
        }

        tr:hover {
            background: #fafafa;
        }

        .badge {
            display: inline-block;
            padding: 5px 8px;
            border-radius: 4px;
            font-size: 12px;
            font-weight: bold;
        }

        .badge-ativo {
            background: #d1e7dd;
            color: #0f5132;
        }

        .badge-inativo {
            background: #f8d7da;
            color: #842029;
        }

        .acoes {
            display: flex;
            gap: 5px;
            flex-wrap: wrap;
        }

        .acoes .btn {
            padding: 6px 10px;
            font-size: 12px;
        }

        .busca {
            display: flex;
            gap: 10px;
            margin-bottom: 15px;
        }

        .busca input {
            flex: 1;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        .info {
            padding: 10px 15px;
            background: #e9ecef;
            border-radius: 5px;
            color: #495057;
            margin-bottom: 15px;
        }

        @media (max-width: 768px) {

            .grid {
                grid-template-columns: 1fr;
            }

            .campo-completo {
                grid-column: auto;
            }

            .container {
                padding: 10px;
            }

            th,
            td {
                white-space: nowrap;
            }
        }

    </style>

</head>

<body>

<div class="container">

    <div class="titulo">
        Usuários do Sistema
    </div>

    <div class="subtitulo">
        Cadastro e gerenciamento dos usuários do sistema
    </div>


    <?php if ($mensagem !== ''): ?>

        <div class="mensagem">
            <?= htmlspecialchars($mensagem) ?>
        </div>

    <?php endif; ?>


    <?php if ($erro !== ''): ?>

        <div class="erro">
            <?= htmlspecialchars($erro) ?>
        </div>

    <?php endif; ?>


    <!-- ==========================================================
         FORMULÁRIO
         ========================================================== -->

    <div class="card">

        <h3>
            <?= $usuarioEditar ? 'Editar Usuário' : 'Novo Usuário' ?>
        </h3>

        <form method="POST">

            <input type="hidden"
                   name="acao"
                   value="salvar">

            <input type="hidden"
                   name="Id"
                   value="<?= htmlspecialchars((string)$formId) ?>">


            <div class="grid">

                <!-- Pessoa -->

                <div class="campo campo-completo">

                    <label for="IdPessoa">
                        Pessoa
                    </label>

                    <?php if ($usuarioEditar): ?>

                        <input
                            type="text"
                            value="<?= htmlspecialchars($formNome) ?>"
                            readonly
                        >

                        <small style="margin-top:5px;color:#666;">
                            ID da pessoa:
                            <?= htmlspecialchars((string)$formId) ?>
                        </small>

                    <?php else: ?>

                        <select
                            name="Id"
                            id="IdPessoa"
                            required
                            onchange="atualizarPessoa()"
                        >

                            <option value="">
                                -- Selecione uma pessoa --
                            </option>

                            <?php foreach ($pessoasDisponiveis as $pessoa): ?>

                                <option
                                    value="<?= htmlspecialchars((string)$pessoa['Id']) ?>"
                                    data-nome="<?= htmlspecialchars($pessoa['Nome'] ?? '') ?>"
                                >

                                    <?= htmlspecialchars($pessoa['Nome'] ?? '') ?>

                                    <?php if (!empty($pessoa['Cpf'])): ?>

                                        - CPF:
                                        <?= htmlspecialchars($pessoa['Cpf']) ?>

                                    <?php endif; ?>

                                </option>

                            <?php endforeach; ?>

                        </select>


                        <?php if (count($pessoasDisponiveis) === 0): ?>

                            <small style="margin-top:6px;color:#666;">
                                Todas as pessoas cadastradas já possuem usuário do sistema.
                            </small>

                        <?php endif; ?>

                    <?php endif; ?>

                </div>


                <!-- Login -->

                <div class="campo">

                    <label for="Login">
                        Login
                    </label>

                    <input
                        type="text"
                        id="Login"
                        name="Login"
                        value="<?= htmlspecialchars($formLogin) ?>"
                        required
                    >

                </div>


                <!-- Senha -->

                <div class="campo">

                    <label for="Senha">
                        Senha
                    </label>

                    <input
                        type="password"
                        id="Senha"
                        name="Senha"
                        <?= $usuarioEditar ? '' : 'required' ?>
                        autocomplete="new-password"
                    >

                    <?php if ($usuarioEditar): ?>

                        <small style="margin-top:5px;color:#666;">
                            Deixe em branco para manter a senha atual.
                        </small>

                    <?php endif; ?>

                </div>


                <!-- Perfil -->

                <div class="campo">

                    <label for="Perfil">
                        Perfil
                    </label>

                    <select
                        name="Perfil"
                        id="Perfil"
                    >

                        <option
                            value="Usuario"
                            <?= $formPerfil === 'Usuario' ? 'selected' : '' ?>
                        >
                            Usuario
                        </option>

                        <option
                            value="Administrador"
                            <?= $formPerfil === 'Administrador' ? 'selected' : '' ?>
                        >
                            Administrador
                        </option>

                    </select>

                </div>


                <!-- Status -->

                <div class="campo">

                    <label for="Status">
                        Status
                    </label>

                    <select
                        name="Status"
                        id="Status"
                    >

                        <option
                            value="Ativo"
                            <?= $formStatus === 'Ativo' ? 'selected' : '' ?>
                        >
                            Ativo
                        </option>

                        <option
                            value="Inativo"
                            <?= $formStatus === 'Inativo' ? 'selected' : '' ?>
                        >
                            Inativo
                        </option>

                    </select>

                </div>


                <!-- Ativo -->

                <div class="campo">

                    <label>
                        Situação
                    </label>

                    <label style="
                        display:flex;
                        flex-direction:row;
                        align-items:center;
                        gap:8px;
                        font-weight:normal;
                    ">

                        <input
                            type="checkbox"
                            name="Ativo"
                            value="1"
                            <?= $formAtivo ? 'checked' : '' ?>
                        >

                        Usuário ativo

                    </label>

                </div>

            </div>


            <div class="botoes">

                <button
                    type="submit"
                    class="btn btn-primary"
                >

                    <?= $usuarioEditar
                        ? 'Atualizar Usuário'
                        : 'Cadastrar Usuário' ?>

                </button>


                <?php if ($usuarioEditar): ?>

                    <a
                        href="<?= htmlspecialchars($_SERVER['PHP_SELF']) ?>"
                        class="btn btn-secondary"
                    >

                        Cancelar

                    </a>

                <?php endif; ?>

            </div>

        </form>

    </div>


    <!-- ==========================================================
         LISTAGEM
         ========================================================== -->

    <div class="card">

        <h3>
            Usuários cadastrados
        </h3>


        <div class="info">

            Total de usuários cadastrados:
            <strong><?= count($usuarios) ?></strong>

        </div>


        <form
            method="GET"
            class="busca"
        >

            <input
                type="text"
                name="busca"
                placeholder="Pesquisar por nome, CPF, login, perfil..."
                value="<?= htmlspecialchars($_GET['busca'] ?? '') ?>"
            >

            <button
                type="submit"
                class="btn btn-primary"
            >

                Pesquisar

            </button>


            <?php if (!empty($_GET['busca'])): ?>

                <a
                    href="<?= htmlspecialchars($_SERVER['PHP_SELF']) ?>"
                    class="btn btn-secondary"
                >

                    Limpar

                </a>

            <?php endif; ?>

        </form>


        <div class="tabela-container">

            <table>

                <thead>

                    <tr>

                        <th>ID</th>

                        <th>Pessoa</th>

                        <th>Login</th>

                        <th>Perfil</th>

                        <th>Status</th>

                        <th>Ativo</th>

                        <th>Ações</th>

                    </tr>

                </thead>


                <tbody>

                <?php if (count($usuarios) === 0): ?>

                    <tr>

                        <td
                            colspan="7"
                            style="text-align:center;padding:25px;"
                        >

                            Nenhum usuário encontrado.

                        </td>

                    </tr>

                <?php else: ?>

                    <?php foreach ($usuarios as $usuario): ?>

                        <tr>

                            <td>
                                <?= htmlspecialchars(
                                    (string)$usuario['Id']
                                ) ?>
                            </td>


                            <td>

                                <strong>

                                    <?= htmlspecialchars(
                                        $usuario['Nome']
                                        ?? $usuario['Login']
                                    ) ?>

                                </strong>


                                <?php if (!empty($usuario['Cpf'])): ?>

                                    <br>

                                    <small style="color:#777;">

                                        CPF:
                                        <?= htmlspecialchars(
                                            $usuario['Cpf']
                                        ) ?>

                                    </small>

                                <?php endif; ?>

                            </td>


                            <td>
                                <?= htmlspecialchars(
                                    $usuario['Login']
                                ) ?>
                            </td>


                            <td>
                                <?= htmlspecialchars(
                                    $usuario['Perfil']
                                ) ?>
                            </td>


                            <td>
                                <?= htmlspecialchars(
                                    $usuario['Status']
                                ) ?>
                            </td>


                            <td>

                                <?php if (
                                    (int)$usuario['Ativo'] === 1
                                ): ?>

                                    <span class="badge badge-ativo">
                                        Ativo
                                    </span>

                                <?php else: ?>

                                    <span class="badge badge-inativo">
                                        Inativo
                                    </span>

                                <?php endif; ?>

                            </td>


                            <td>

                                <div class="acoes">

                                    <a
                                        href="?editar=<?= urlencode(
                                            $usuario['Id']
                                        ) ?>"
                                        class="btn btn-success"
                                    >
                                        Editar
                                    </a>


                                    <form
                                        method="POST"
                                        style="display:inline;"
                                        onsubmit="return confirmarExclusao();"
                                    >

                                        <input
                                            type="hidden"
                                            name="acao"
                                            value="excluir"
                                        >

                                        <input
                                            type="hidden"
                                            name="Id"
                                            value="<?= htmlspecialchars(
                                                (string)$usuario['Id']
                                            ) ?>"
                                        >

                                        <button
                                            type="submit"
                                            class="btn btn-danger"
                                        >
                                            Excluir
                                        </button>

                                    </form>

                                </div>

                            </td>

                        </tr>

                    <?php endforeach; ?>

                <?php endif; ?>

                </tbody>

            </table>

        </div>

    </div>

</div>


<script>

function confirmarExclusao()
{
    return confirm(
        'Tem certeza que deseja excluir este usuário?\n\n' +
        'A pessoa continuará cadastrada, mas o acesso ao sistema será removido.'
    );
}


/*
 * Ao selecionar uma pessoa,
 * sugere o login automaticamente.
 */

function atualizarPessoa()
{
    const select = document.getElementById('IdPessoa');

    if (!select) {
        return;
    }

    const option = select.options[select.selectedIndex];

    if (!option) {
        return;
    }

    const nome = option.getAttribute('data-nome');

    const login = document.getElementById('Login');

    if (
        login &&
        login.value.trim() === '' &&
        nome
    ) {

        let sugestao = nome
            .normalize('NFD')
            .replace(/[\u0300-\u036f]/g, '')
            .toLowerCase()
            .trim()
            .replace(/\s+/g, '');

        login.value = sugestao;
    }
}

</script>

</body>

</html>